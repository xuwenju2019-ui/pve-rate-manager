from datetime import datetime,date
import io
import json
from pathlib import Path
import sqlite3
import struct
import tempfile
import unittest
from unittest.mock import patch
from test_manager import m
from test_adaptive import adaptive
from schedule import validate,phase,next_boundary
from traffic import TrafficStore,split_interval
from pcap_analyze import analyze,GeoDB,records
from capture import CaptureService


def frame(source,dest,mac='bc2411d6637d',vlan=False,ipv6=False):
    import ipaddress
    header=bytes.fromhex('001122334455'+mac)+bytes.fromhex('8100000186dd' if vlan and ipv6 else '810000010800' if vlan else '86dd' if ipv6 else '0800')
    if ipv6:ip=b'\x60\x00\x00\x00\x00\x00\x11\x40'+ipaddress.ip_address(source).packed+ipaddress.ip_address(dest).packed
    else:ip=b'\x45\x00\x00\x14'+b'\x00'*4+b'\x40\x11'+b'\x00'*2+ipaddress.ip_address(source).packed+ipaddress.ip_address(dest).packed
    return header+ip


def pcap(items,endian='<',nano=False):
    magic=(b'\x4d\x3c\xb2\xa1' if nano else b'\xd4\xc3\xb2\xa1') if endian=='<' else (b'\xa1\xb2\x3c\x4d' if nano else b'\xa1\xb2\xc3\xd4')
    data=magic+struct.pack(endian+'HHIIII',2,4,0,0,65535,1)
    for index,(packet,length) in enumerate(items):data+=struct.pack(endian+'IIII',100+index,0,len(packet),length)+packet
    return data


def block(kind,data):
    size=len(data)+12;return struct.pack('<II',kind,size)+data+struct.pack('<I',size)


class Schedule31Tests(unittest.TestCase):
    def test_default_migrates_without_changing_boundaries(self):
        r=adaptive();self.assertEqual(r['schedule'],validate())
        self.assertEqual(phase(datetime(2026,11,8,11,30),r),'lunch')
        self.assertEqual(next_boundary(datetime(2026,11,8,23,0),r),'2026-11-09T00:00')

    def test_custom_wrap_midnight_and_complement_ranges(self):
        r=adaptive();r['schedule']=validate({'lunch':{'start':'23:00','end':'01:00'},'evening':{'start':'03:00','end':'04:00'}})
        for time,value in [('00:30','lunch'),('01:00','off_pm'),('03:30','evening'),('04:00','off_am'),('22:00','off_am')]:
            self.assertEqual(phase(datetime.fromisoformat('2026-11-08T'+time),r),value)

    def test_reject_overlap_zero_length_and_touching(self):
        for end,start in [('18:00','17:00'),('11:30','17:00'),('14:00','14:00')]:
            with self.assertRaises(ValueError):validate({'lunch':{'start':'11:30','end':end},'evening':{'start':start,'end':'00:00'}})

    def test_custom_stats_split_at_actual_boundaries(self):
        r=adaptive();r['schedule']=validate({'lunch':{'start':'12:00','end':'14:30'},'evening':{'start':'18:00','end':'23:00'}})
        start=datetime(2026,11,8,11,59,55).timestamp();parts=split_interval(start,start+10,1001,r)
        self.assertEqual([p[1] for p in parts],['off_am','lunch']);self.assertEqual(sum(p[2] for p in parts),1001)


class Duplex31Tests(unittest.TestCase):
    def test_manager_keeps_original_30_database_unchanged(self):
        with tempfile.TemporaryDirectory() as folder:
            state=Path(folder);old=state/'traffic.sqlite3';db=sqlite3.connect(old)
            db.execute('CREATE TABLE daily(day TEXT,key TEXT,vmid INTEGER,nic TEXT,name TEXT,total INTEGER,lunch INTEGER,evening INTEGER,offpeak INTEGER,seconds REAL,gaps INTEGER,PRIMARY KEY(day,key))')
            db.execute('CREATE TABLE baseline(key TEXT PRIMARY KEY,identity TEXT,counter INTEGER,stamp REAL)');db.commit();db.close()
            manager=m.Manager(state,True)
            try:
                self.assertEqual(manager.traffic.path.name,'traffic-3.1.sqlite3')
                with sqlite3.connect(old) as check:self.assertEqual(len(list(check.execute('PRAGMA table_info(daily)'))),11)
                check.close()
                self.assertEqual(len(list(manager.traffic.db.execute('PRAGMA table_info(daily)'))),13)
            finally:manager.traffic.close()

    def test_migrate_30_database_and_download_starts_at_new_baseline(self):
        with tempfile.TemporaryDirectory() as folder:
            file=Path(folder)/'traffic.db';db=sqlite3.connect(file)
            db.execute('CREATE TABLE daily(day TEXT,key TEXT,vmid INTEGER,nic TEXT,name TEXT,total INTEGER,lunch INTEGER,evening INTEGER,offpeak INTEGER,seconds REAL,gaps INTEGER,PRIMARY KEY(day,key))')
            db.execute('CREATE TABLE baseline(key TEXT PRIMARY KEY,identity TEXT,counter INTEGER,stamp REAL)')
            r=adaptive();now=datetime.now().timestamp();today=datetime.now().date().isoformat()
            db.execute('INSERT INTO daily VALUES(?,?,?,?,?,?,?,?,?,?,?)',(today,r['id'],100,'net1','old',500,0,0,500,5,0));db.execute('INSERT INTO baseline VALUES(?,?,?,?)',(r['id'],'tap',500,now));db.commit();db.close()
            store=TrafficStore(file)
            try:
                store.sample(r,'tap',600,now+5,download=9000)
                row=store.report()['rows'][0];self.assertEqual(row['total'],600);self.assertEqual(row['download'],0);self.assertEqual(row['download_seconds'],0)
                store.sample(r,'tap',800,now+10,download=9300)
                row=store.report()['rows'][0];self.assertEqual(row['download'],300);self.assertEqual(store.download_speeds[r['id']],300/5/1024**2)
                points=store.history()['points'];self.assertEqual(sum(p['down_bytes'] for p in points),300)
            finally:store.close()

    def test_duplex_reset_and_midnight_conserve(self):
        with tempfile.TemporaryDirectory() as folder:
            store=TrafficStore(Path(folder)/'traffic.db');r=adaptive();a=datetime(2026,11,8,23,59,55).timestamp()
            try:
                store.sample(r,'tap',100,a,download=100);store.sample(r,'tap',1101,a+10,download=2103)
                rows=store.report(date(2026,11,9))['rows'];self.assertEqual(sum(v['total'] for v in rows),1001);self.assertEqual(sum(v['download'] for v in rows),2003)
                store.sample(r,'new-tap',0,a+15,download=0)
                self.assertEqual(sum(v['download'] for v in store.report(date(2026,11,9))['rows']),2003)
            finally:store.close()


class Pcap31Tests(unittest.TestCase):
    def setUp(self):
        self.geo=GeoDB('network,country,region,isp\n8.8.8.0/24,CN,四川省,中国电信\n1.1.1.0/24,CN,贵州省,中国移动\n9.9.9.0/24,US,,Other\n2001:4860::/32,CN,四川,电信\n')

    def test_uplink_only_denominators_and_ranking(self):
        raw=pcap([(frame('10.0.0.2','8.8.8.8'),100),(frame('10.0.0.2','1.1.1.1'),200),(frame('10.0.0.2','9.9.9.9'),100),(frame('10.0.0.2','10.0.0.3'),100),(frame('8.8.8.8','10.0.0.2'),900)])
        r=analyze(raw,'四川','电信',self.geo,ips=['10.0.0.2'])
        self.assertEqual(r['bytes'],500);self.assertEqual(r['packets'],4)
        self.assertAlmostEqual(r['out_province_percent'],200/300*100);self.assertEqual(r['region_coverage'],60)
        self.assertAlmostEqual(r['cross_isp_percent'],200/300*100);self.assertEqual(r['peers'][0]['ip'],'1.1.1.1')
        self.assertEqual(sum(x['bytes'] for x in r['regions']),500)

    def test_original_length_not_saved_head_length(self):
        r=analyze(pcap([(frame('10.0.0.2','8.8.8.8'),1500)]),'四川','电信',self.geo,ips=['10.0.0.2'])
        self.assertEqual(r['bytes'],1500);self.assertEqual(r['truncated_packets'],1)

    def test_endian_precision_vlan_ipv6(self):
        for e in ('<','>'):
            for nano in (False,True):
                raw=pcap([(frame('2001:4860::1','2001:4860::2',ipv6=True,vlan=True),100)],e,nano)
                r=analyze(raw,'四川','电信',self.geo,ips=['2001:4860::1'])
                self.assertEqual(r['bytes'],100);self.assertEqual(r['out_province_percent'],0)

    def test_pcapng_and_refuse_multi_interface(self):
        section=block(0x0a0d0d0a,struct.pack('<IHHq',0x1a2b3c4d,1,0,-1));interface=block(1,struct.pack('<HHI',1,0,65535))
        packet=frame('10.0.0.2','8.8.8.8');padded=packet+b'\0'*((-len(packet))%4)
        item=block(6,struct.pack('<IIIII',0,0,1000000,len(packet),100)+padded)
        self.assertEqual(analyze(section+interface+item,'四川','电信',self.geo,ips=['10.0.0.2'])['bytes'],100)
        second=block(6,struct.pack('<IIIII',1,0,2000000,len(packet),100)+padded)
        with self.assertRaisesRegex(ValueError,'单一接口'):list(records(section+interface+interface+item+second))

    def test_unknown_does_not_invent_region_or_isp(self):
        r=analyze(pcap([(frame('10.0.0.2','8.8.8.8'),100)]),'四川','电信',ips=['10.0.0.2'])
        self.assertIsNone(r['out_province_percent']);self.assertIsNone(r['cross_isp_percent']);self.assertEqual(r['region_coverage'],0)

    def test_no_direction_and_corrupt_capture_refused(self):
        with self.assertRaises(ValueError):analyze(b'bad','四川','电信')
        raw=pcap([(frame('10.0.0.2','8.8.8.8'),100)])
        with self.assertRaises(ValueError):analyze(raw[:-1],'四川','电信',ips=['10.0.0.2'])

    def test_trusted_tap_ingress_does_not_drop_bridged_guest_macs(self):
        r=analyze(pcap([(frame('10.0.0.2','8.8.8.8',mac='aabbccddeeff'),100)]),'四川','电信',self.geo,uplink_only=True)
        self.assertEqual(r['bytes'],100)

    def test_longest_prefix_and_ipv6_database(self):
        db=GeoDB('network,country,region,isp\n8.0.0.0/8,CN,四川,电信\n8.8.8.0/24,CN,贵州,移动\n')
        self.assertEqual(db.lookup('8.8.8.8')['region'],'贵州');self.assertEqual(db.lookup('8.8.9.9')['region'],'四川')
        self.assertEqual(self.geo.lookup('2001:4860::2')['isp'],'电信')


class Capture31Tests(unittest.TestCase):
    def test_capture_command_targets_one_tap_and_only_guest_upload(self):
        import sys
        from types import SimpleNamespace
        from unittest.mock import Mock
        with tempfile.TemporaryDirectory() as folder:
            backend=Mock();backend.snapshot.return_value={'net1':'virtio=BC:24:11:D6:63:7D,bridge=vmbr1'}
            service=CaptureService(Path(folder),backend,True);service.demo=False;service.cache=Path(folder)/'captures'
            exists=Path.exists
            def target_exists(p):return True if str(p).endswith('tap100i1') else exists(p)
            with patch.dict(sys.modules,{'pwd':SimpleNamespace(getpwnam=lambda name:SimpleNamespace(pw_uid=65534,pw_gid=65534))}),patch.object(Path,'exists',target_exists),patch('capture.os.chown',create=True),patch('capture.shutil.which',return_value='/usr/bin/tcpdump'),patch('capture.shutil.disk_usage',return_value=SimpleNamespace(free=1024**3)),patch('capture.subprocess.Popen') as popen,patch('capture.threading.Thread'):
                job=service.start({'vmid':100,'nic':'net1','duration':60,'province':'四川','isp':'电信'})
            argv=popen.call_args.args[0]
            self.assertEqual(argv[argv.index('-i')+1],'tap100i1');self.assertEqual(argv[argv.index('-Q')+1],'in')
            self.assertNotIn('vmbr1',argv);self.assertNotIn('any',argv);self.assertNotIn('shell',popen.call_args.kwargs)
            self.assertNotIn('preexec_fn',popen.call_args.kwargs);self.assertEqual(len(job['id']),32)

    def test_raw_capture_retention_preserves_recent_report(self):
        import time
        from capture import save_json
        with tempfile.TemporaryDirectory() as folder:
            service=CaptureService(Path(folder),None,True);service.prepare();key='a'*32;target=service.cache/key;target.mkdir()
            (target/'sample.pcap').write_bytes(b'sample');save_json(target/'report.json',{'bytes':10})
            job={'id':key,'status':'done','created':time.time()-2*86400,'duration':60};save_json(target/'meta.json',job);service.jobs[key]=job
            service.prune();self.assertFalse((target/'sample.pcap').exists());self.assertTrue((target/'report.json').exists())

    def test_csv_chunk_order_validation_and_atomic_replacement(self):
        import base64
        with tempfile.TemporaryDirectory() as folder:
            service=CaptureService(Path(folder),None,True);started=service.geo_begin();text='network,country,region,isp\n8.8.8.0/24,CN,四川,电信\n'.encode()
            with self.assertRaises(ValueError):service.geo_chunk({'id':started['id'],'offset':2,'data':base64.b64encode(text).decode()})
            service.geo_chunk({'id':started['id'],'offset':0,'data':base64.b64encode(text).decode()});service.geo_commit(started)
            self.assertTrue(service.geo_status()['available']);self.assertEqual(service.geo_lookup({'ips':['8.8.8.8']})['results']['8.8.8.8']['region'],'四川')

    def test_report_path_traversal_refused(self):
        with tempfile.TemporaryDirectory() as folder:
            service=CaptureService(Path(folder),None,True)
            with self.assertRaises(ValueError):service.report({'id':'../../etc/passwd'})


if __name__=='__main__':unittest.main()
