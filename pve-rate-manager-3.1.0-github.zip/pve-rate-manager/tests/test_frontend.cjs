'use strict';
// Dependency-free contract tests, not a replacement for browser acceptance.
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
const hook=fs.readFileSync(path.join(root,'pve-hook.js'),'utf8');
const app=fs.readFileSync(path.join(root,'web/app.js'),'utf8');
new vm.Script(hook);new vm.Script(app);

function entryTest() {
 const tasks=[],components={},created=[];
 const parent={add:()=>{},items:{indexOf:()=>0},insert:(idx,c)=>{
  created.push(c);const b={...c,setDisabled(value){this.disabled=value;}};
  components[c.id]=b;return b;
 }};
 const user={ownerCt:parent};
 const Ext={onReady:f=>f(),getCmp:id=>id==='userinfo'?user:components[id],
  ComponentQuery:{query:()=>[]},Msg:{alert:()=>{}},create:(kind,c)=>{
   created.push(c);const w={...c,show(){return this;},toFront(){},close(){this.closed=true;}};
   components[c.id]=w;return w;
  }};
 const Proxmox={UserName:'root@pam'};
 const window={Proxmox,innerWidth:1280,innerHeight:800,
  setInterval:f=>{tasks.push(f);return tasks.length;},clearInterval:()=>{}};
 vm.runInNewContext(hook,{window,Ext,Proxmox,console});tasks[0]();
 const button=components['pve-rate-manager-button'];assert.ok(button);
 assert.equal(button.text,'网卡限速');assert.equal(button.baseCls,'x-btn');
 assert.equal(button.ui,'default');assert.equal(button.cls,undefined);
 tasks[1]();assert.equal(button.disabled,false);
 button.handler();const win=components['pve-rate-manager-window'];assert.ok(win);
 assert.equal(win.items[0].autoEl.src,'/pve2/js/rate-manager/index.html?v=3.1.0');
 Proxmox.UserName=null;tasks[1]();assert.equal(button.disabled,true);assert.equal(win.closed,true);
 console.log('PASS: native blue entry, iframe version, login/logout handling');
}

async function apiTest() {
 const src=app.slice(app.indexOf('function pveToken()'),app.indexOf('function gb('));
 const calls=[];
 const context=vm.createContext({window:{parent:{Proxmox:{CSRFPreventionToken:'native-token'}}},
  fetch:async(url,options)=>{calls.push({url,options});return {ok:true,json:async()=>({data:JSON.stringify({ok:true})})};}});
 vm.runInContext(src,context);
 const result=await context.api('toggle',{revision:2,enabled:false});assert.ok(result.ok);
 assert.equal(calls[0].url,'/api2/json/rate-manager/toggle');
 assert.equal(calls[0].options.credentials,'same-origin');
 assert.equal(calls[0].options.headers.CSRFPreventionToken,'native-token');
 assert.deepEqual(JSON.parse(JSON.parse(calls[0].options.body).payload),{revision:2,enabled:false});
 const html=fs.readFileSync(path.join(root,'web/index.html'),'utf8');
 assert.ok(html.includes('自定义高峰时间'));assert.ok(html.includes('stats-body'));assert.ok(html.includes('name="am_min"'));assert.ok(html.includes('app.js?v=3.1.0'));
 console.log('PASS: native CSRF, payload/response, adaptive fields, stats and asset versions');
}

entryTest();apiTest().catch(e=>{console.error(e);process.exitCode=1;});
