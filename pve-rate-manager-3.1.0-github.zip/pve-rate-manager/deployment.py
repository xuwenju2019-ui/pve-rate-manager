#!/usr/bin/python3
"""Fixed-path installer snapshots; never snapshots VM disk or PVE VM config."""
import argparse
import json
import os
from pathlib import Path
import shutil
import time

BACKUPS = Path('/var/lib/pve-rate-manager/install-backups')
RULES = Path('/var/lib/pve-rate-manager/rules.json')
TARGETS = [Path(p) for p in [
    '/usr/share/perl5/PVE/API2.pm',
    '/usr/share/pve-manager/js/pvemanagerlib.js',
    '/usr/share/pve-manager/index.html.tpl',
    '/usr/share/perl5/PVE/API2/RateManager.pm',
    '/etc/systemd/system/pve-rate-manager.service',
    '/opt/pve-rate-manager/manager.py',
    '/opt/pve-rate-manager/adaptive.py',
    '/opt/pve-rate-manager/traffic.py',
    '/opt/pve-rate-manager/schedule.py',
    '/opt/pve-rate-manager/capture.py',
    '/opt/pve-rate-manager/capture_runner.py',
    '/opt/pve-rate-manager/pcap_analyze.py',
    '/opt/pve-rate-manager/storage.py',
    '/opt/pve-rate-manager/integration.py',
    '/opt/pve-rate-manager/deployment.py',
    '/opt/pve-rate-manager/pve-hook.js',
    '/usr/share/pve-manager/js/rate-manager/index.html',
    '/usr/share/pve-manager/js/rate-manager/app.js',
    '/usr/share/pve-manager/js/rate-manager/pcap-worker.js',
    '/usr/share/pve-manager/js/rate-manager/style.css',
]]


def snapshot():
    folder=BACKUPS/str(time.time_ns())
    folder.mkdir(parents=True,mode=0o700)
    entries=[]
    for i,p in enumerate(TARGETS):
        present=p.exists()
        entries.append({'present':present,'path':str(p)})
        if present:shutil.copy2(p,folder/(str(i)+'.bin'))
    (folder/'manifest.json').write_text(json.dumps(entries,indent=2),encoding='utf-8')
    if RULES.exists():shutil.copy2(RULES,folder/'rules-reference.json')
    return folder


def restore(folder):
    folder=folder.resolve()
    if folder.parent!=BACKUPS.resolve():
        raise ValueError('Backup must be a direct child of the installer backup directory')
    entries=json.loads((folder/'manifest.json').read_text(encoding='utf-8'))
    if len(entries)!=len(TARGETS):raise ValueError('Backup manifest version mismatch')
    # Validate every source and path before changing any destination.
    for i,(p,entry) in enumerate(zip(TARGETS,entries)):
        if entry['path']!=str(p):raise ValueError('Unexpected backup target')
        if entry['present'] and not (folder/(str(i)+'.bin')).is_file():
            raise ValueError('Incomplete installer backup')
    for i,(p,entry) in enumerate(zip(TARGETS,entries)):
        if entry['present']:
            p.parent.mkdir(parents=True,exist_ok=True)
            tmp=p.with_name(p.name+'.restore.tmp')
            shutil.copy2(folder/(str(i)+'.bin'),tmp)
            os.replace(tmp,p)
        else:
            p.unlink(missing_ok=True)
    # Rules are reference-only: never overwrite rules changed by an administrator.


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['snapshot','restore'])
    parser.add_argument('folder',nargs='?',type=Path)
    args=parser.parse_args()
    if os.geteuid()!=0:raise RuntimeError('Run as root')
    os.umask(0o077)
    if args.action=='snapshot':print(snapshot())
    elif args.folder:restore(args.folder)
    else:parser.error('restore needs a backup folder')


if __name__=='__main__':main()
