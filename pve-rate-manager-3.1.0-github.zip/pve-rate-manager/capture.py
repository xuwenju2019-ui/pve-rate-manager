"""Local-node, upstream-only capture jobs. Capture and parsing never run in scheduler loop."""
import base64
from datetime import datetime
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import sys
import threading
import time
import uuid
from adaptive import nic_mac
from pcap_analyze import GeoDB,MAX_FILE

ROOT=Path(__file__).resolve().parent


def safe_id(value):
    if not isinstance(value,str) or not re.fullmatch(r'[0-9a-f]{32}',value):raise ValueError('任务 ID 无效')
    return value


def save_json(path,data):
    temp=path.with_name('.'+uuid.uuid4().hex+'.tmp')
    fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0),0o600)
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump(data,f,ensure_ascii=False)
        os.replace(temp,path)
    finally:temp.unlink(missing_ok=True)


def read_json(path):
    fd=os.open(path,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0))
    with os.fdopen(fd,'r',encoding='utf-8') as f:
        info=os.fstat(f.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size>2*1024*1024:raise ValueError('任务元数据或报告大小异常')
        raw=f.read(2*1024*1024+1)
        if len(raw)>2*1024*1024:raise ValueError('报告大小异常')
        return json.loads(raw)


class CaptureService:
    def __init__(self,state,backend,demo=False):
        self.state=Path(state);self.backend=backend;self.demo=demo;self.lock=threading.RLock();self.jobs={};self.proc=None;self.cancelled=set();self.upload=None
        self.cache=self.state/'capture-cache' if demo else Path('/var/cache/pve-rate-manager-capture')

    def prepare(self):
        self.cache.mkdir(parents=True,exist_ok=True,mode=0o711)
        if not self.demo:os.chmod(self.cache,0o711)
        for folder in self.cache.iterdir():
            if not folder.is_dir() or folder.is_symlink() or not re.fullmatch(r'[0-9a-f]{32}',folder.name):continue
            if folder.name in self.jobs:continue
            try:
                job=read_json(folder/'meta.json')
                if job.get('id')!=folder.name:continue
                if job['status'] in ('running','analyzing'):
                    job.update(status='failed',error='后台曾重启，此任务中断，请重新采集');save_json(folder/'meta.json',job)
                self.jobs[job['id']]=job
            except (ValueError,OSError,KeyError):continue
        self.prune()

    def prune(self):
        now=time.time();finished=sorted((j for j in self.jobs.values() if j['status'] not in ('running','analyzing')),key=lambda j:j['created'],reverse=True)
        for i,job in enumerate(finished):
            folder=self.cache/job['id']
            if now-job['created']>86400:(folder/'sample.pcap').unlink(missing_ok=True)
            if now-job['created']>7*86400 or i>=50:
                if folder.resolve().parent!=self.cache.resolve():raise RuntimeError('任务清理路径异常')
                if folder.is_symlink():raise RuntimeError('任务目录不能是符号链接')
                shutil.rmtree(folder);self.jobs.pop(job['id'],None)

    def maintenance(self):
        with self.lock:
            if self.cache.exists():self.prepare()

    def status(self):
        with self.lock:
            self.prepare();result=[]
            for j in sorted(self.jobs.values(),key=lambda x:x['created'],reverse=True):
                value={k:v for k,v in j.items() if k not in ('mac',)}
                value['elapsed']=min(j['duration'],int(time.time()-j['created'])) if j['status']=='running' else j.get('elapsed',0)
                file=self.cache/j['id']/'sample.pcap';value['size']=file.stat().st_size if file.exists() else 0
                result.append(value)
            return {'jobs':result,'available':bool(shutil.which('tcpdump')),'limits':{'file_bytes':MAX_FILE,'total_bytes':500*1024*1024,'days':7,'raw_hours':24}}

    def start(self,body):
        with self.lock:
            self.prepare()
            if any(j['status'] in ('running','analyzing') for j in self.jobs.values()):raise ValueError('当前节点已有采集或分析任务，请等待完成')
            if self.demo:raise ValueError('离线后台不采集真实网卡，请使用 Web 交互预览')
            vmid=body.get('vmid');nic=body.get('nic');duration=body.get('duration')
            if type(vmid) is not int or not 100<=vmid<=999999999 or not isinstance(nic,str) or not re.fullmatch(r'net(?:[0-9]|[12][0-9]|3[01])',nic):raise ValueError('虚拟机或网卡无效')
            if type(duration) is not int or duration not in (30,60,120):raise ValueError('请选择 30、60 或 120 秒')
            province=str(body.get('province','')).strip();isp=str(body.get('isp','')).strip()
            if not province or not isp or len(province)>30 or len(isp)>80:raise ValueError('请填写线路省份和运营商')
            executable=shutil.which('tcpdump')
            if not executable:raise ValueError('宿主机尚未安装 tcpdump；请先在 Shell 执行 apt install tcpdump')
            config=self.backend.snapshot(vmid,nic);mac=nic_mac(config[nic]);tap=f'tap{vmid}i{int(nic[3:])}'
            if not (Path('/sys/class/net')/tap).exists():raise ValueError('目标 TAP 不存在，请先启动虚拟机并检查网卡')
            usage=sum(p.stat().st_size for p in self.cache.glob('*/sample.pcap') if p.is_file())
            if usage+MAX_FILE>500*1024*1024:raise ValueError('抓包存储已达到 500 MiB 预算，请等待旧样本到期清理')
            if shutil.disk_usage(self.cache).free<MAX_FILE+256*1024*1024:raise ValueError('宿主机剩余磁盘空间不足，未开始抓包')
            import pwd
            account=pwd.getpwnam('nobody');jobid=uuid.uuid4().hex;folder=self.cache/jobid;folder.mkdir(mode=0o700);os.chown(folder,account.pw_uid,account.pw_gid)
            job={'id':jobid,'vmid':vmid,'nic':nic,'mac':mac,'province':province,'isp':isp,'duration':duration,'status':'running','created':time.time(),'started':datetime.now().isoformat(timespec='seconds')}
            self.jobs[jobid]=job;save_json(folder/'meta.json',job)
            # Inbound on the host TAP is outbound from the guest. Direction is captured here, rather than inferred from bridged guest MACs.
            argv=[executable,'-i',tap,'-Q','in','-nn','-s','128','-B','1024','-U','-Z','nobody','-w',str(folder/'sample.pcap'),'(','ip','or','ip6','or','vlan',')']
            try:
                self.proc=subprocess.Popen([sys.executable,str(ROOT/'capture_runner.py'),*argv],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
            except Exception:
                job.update(status='failed',error='无法启动 tcpdump');save_json(folder/'meta.json',job);raise
            threading.Thread(target=self.monitor,args=(job,self.proc,account),daemon=True).start()
            return {'id':jobid}

    @staticmethod
    def capture_limits():
        import resource
        resource.setrlimit(resource.RLIMIT_FSIZE,(MAX_FILE,MAX_FILE))
        resource.setrlimit(resource.RLIMIT_CORE,(0,0))

    def monitor(self,job,proc,account):
        folder=self.cache/job['id'];file=folder/'sample.pcap'
        try:
            deadline=time.monotonic()+job['duration'];limit_hit=False
            while proc.poll() is None:
                if job['id'] in self.cancelled or time.monotonic()>=deadline:break
                if file.exists() and file.stat().st_size>=MAX_FILE-256:limit_hit=True;break
                time.sleep(.25)
            if proc.poll() is None:proc.send_signal(signal.SIGINT)
            try:_,stderr=proc.communicate(timeout=8)
            except subprocess.TimeoutExpired:proc.kill();_,stderr=proc.communicate()
            job['elapsed']=min(job['duration'],int(time.time()-job['created']))
            if job['id'] in self.cancelled:
                job['status']='cancelled';return
            if proc.returncode not in (0,-signal.SIGINT,-signal.SIGXFSZ):raise RuntimeError(stderr.decode(errors='replace')[:500] or '抓包进程失败')
            if not file.exists() or file.stat().st_size<24:raise RuntimeError('未生成有效抓包，请检查网卡')
            job['status']='analyzing';save_json(folder/'meta.json',job)
            cfg={'allow_truncated_tail':True,'uplink_only':True,'mac':job['mac'],'province':job['province'],'isp':job['isp'],'geo':str(self.cache/'geo.csv')}
            cfgfile=folder/'config.json';save_json(cfgfile,cfg);os.chmod(cfgfile,0o644)
            output=folder/'report.json'
            result=subprocess.run([sys.executable,str(ROOT/'pcap_analyze.py'),'--uid',str(account.pw_uid),'--gid',str(account.pw_gid),str(file),str(cfgfile),str(output)],capture_output=True,text=True,timeout=45)
            if result.returncode:raise RuntimeError('分析失败：'+result.stderr[-600:])
            report=read_json(output);report['source']=f'VM {job["vmid"]} / {job["nic"]}'
            # Drop counts are diagnostic sample quality, never silently treated as lossless capture.
            match=re.search(r'(\d+) packets dropped by kernel',stderr.decode(errors='replace'))
            report['dropped_packets']=int(match[1]) if match else None
            if report['dropped_packets']:report['warning']+=' 采集内核丢包 '+str(report['dropped_packets'])+' 个。'
            if limit_hit or proc.returncode==-signal.SIGXFSZ:report['warning']+=' 达到单文件上限，提前停止采集。'
            save_json(output,report);job['status']='done'
        except Exception as e:job.update(status='failed',error=str(e)[:900])
        finally:
            with self.lock:
                save_json(folder/'meta.json',job)
                if self.proc is proc:self.proc=None
                self.cancelled.discard(job['id'])

    def cancel(self,body):
        key=safe_id(body.get('id'))
        with self.lock:
            if key not in self.jobs:raise ValueError('任务不存在')
            self.cancelled.add(key)
            return {'ok':True}

    def report(self,body):
        key=safe_id(body.get('id'))
        with self.lock:
            self.prepare()
            if key not in self.jobs or self.jobs[key]['status']!='done':raise ValueError('报告尚未完成或已经过期')
            return read_json(self.cache/key/'report.json')

    def geo_status(self):
        file=self.cache/'geo-meta.json'
        if not file.exists():return {'available':False,'records':0}
        return json.loads(file.read_text(encoding='utf-8'))

    def geo_begin(self):
        with self.lock:
            self.prepare();self.upload={'id':uuid.uuid4().hex,'size':0,'created':time.time()}
            (self.cache/'geo-upload.tmp').write_bytes(b'');return {'id':self.upload['id']}

    def geo_chunk(self,body):
        with self.lock:
            if not self.upload or body.get('id')!=self.upload['id'] or time.time()-self.upload['created']>600:raise ValueError('上传已过期，请重新选择文件')
            if body.get('offset')!=self.upload['size']:raise ValueError('分片顺序错误，请重新上传')
            data=base64.b64decode(body.get('data',''),validate=True)
            if not data or len(data)>12000 or self.upload['size']+len(data)>8*1024*1024:raise ValueError('归属库上传大小超限')
            with (self.cache/'geo-upload.tmp').open('ab') as f:f.write(data)
            self.upload['size']+=len(data);return {'ok':True}

    def geo_commit(self,body):
        with self.lock:
            if not self.upload or body.get('id')!=self.upload['id']:raise ValueError('上传不存在')
            file=self.cache/'geo-upload.tmp';db=GeoDB(file.read_text(encoding='utf-8'))
            if not db.count:raise ValueError('归属库没有记录')
            os.replace(file,self.cache/'geo.csv');os.chmod(self.cache/'geo.csv',0o644)
            value={'available':True,'records':db.count,'updated':datetime.now().isoformat(timespec='seconds')}
            save_json(self.cache/'geo-meta.json',value);self.upload=None;return value

    def geo_lookup(self,body):
        ips=body.get('ips')
        if not isinstance(ips,list) or len(ips)>400:raise ValueError('每批最多查询 400 个 IP')
        file=self.cache/'geo.csv';db=GeoDB(file.read_text(encoding='utf-8') if file.exists() else '')
        return {'results':{ip:db.lookup(ip) for ip in ips}}
