"""Daily upload accounting, seven local calendar days; raw bytes never packets."""
from datetime import datetime,timedelta
from pathlib import Path
import json
import sqlite3
import threading
import time
from adaptive import phase


def split_interval(start,end,total):
    if end<=start:return []
    points=[start,end]
    day=datetime.fromtimestamp(start).date()
    while day<=datetime.fromtimestamp(end).date():
        for h,m in [(0,0),(11,30),(14,0),(17,0)]:
            t=datetime.combine(day,datetime.min.time()).replace(hour=h,minute=m).timestamp()
            if start<t<end:points.append(t)
        day+=timedelta(days=1)
    points=sorted(set(points));out=[];left=total
    for index,(a,b) in enumerate(zip(points,points[1:])):
        count=left if index==len(points)-2 else int(total*(b-a)/(end-start))
        left-=count;now=datetime.fromtimestamp((a+b)/2)
        out.append((now.date().isoformat(),phase(now),count,b-a))
    return out


class TrafficStore:
    def __init__(self,path):
        self.lock=threading.RLock();self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
        self.db=sqlite3.connect(str(path),check_same_thread=False)
        self.db.execute('PRAGMA journal_mode=DELETE')
        self.db.execute('PRAGMA max_page_count=8192') # normally 32 MiB at 4096-byte pages
        self.db.execute('CREATE TABLE IF NOT EXISTS daily(day TEXT, key TEXT, vmid INTEGER, nic TEXT, name TEXT, total INTEGER, lunch INTEGER, evening INTEGER, offpeak INTEGER, seconds REAL, gaps INTEGER, PRIMARY KEY(day,key))')
        self.db.execute('CREATE TABLE IF NOT EXISTS baseline(key TEXT PRIMARY KEY, identity TEXT, counter INTEGER, stamp REAL)')
        self.db.commit();self.pending={};self.baselines={row[0]:row[1:] for row in self.db.execute('SELECT key,identity,counter,stamp FROM baseline')}
        self.speeds={};self.unavailable={};self.error=None;self.last_flush=time.monotonic()

    def row(self,day,r):
        key=(day,r['id'])
        if key not in self.pending:
            old=self.db.execute('SELECT * FROM daily WHERE day=? AND key=?',key).fetchone()
            self.pending[key]=list(old) if old else [day,r['id'],r['vmid'],r['nic'],r['name'],0,0,0,0,0.,0]
        self.pending[key][4]=r['name']
        return self.pending[key]

    def sample(self,r,identity,counter,stamp=None):
        stamp=time.time() if stamp is None else stamp
        with self.lock:
            key=r['id'];old=self.baselines.get(key);today=datetime.fromtimestamp(stamp).date().isoformat()
            self.unavailable.pop(key,None)
            self.row(today,r)
            if old:
                oldid,previous,start=old;duration=stamp-start
                if oldid==identity and counter>=previous and 0<duration<=86400*7:
                    count=counter-previous;self.speeds[key]=count/duration/1024/1024
                    for day,p,n,seconds in split_interval(start,stamp,count):
                        row=self.row(day,r);row[5]+=n;row[6 if p=='lunch' else 7 if p=='evening' else 8]+=n;row[9]+=seconds
                        if duration>20:row[10]+=1
                else:self.row(today,r)[10]+=1;self.speeds.pop(key,None)
            else:self.row(today,r)[10]+=1
            self.baselines[key]=(identity,counter,stamp)
            if time.monotonic()-self.last_flush>=60:self.flush()

    def missing(self,r,reason='网卡不可用'):
        with self.lock:
            self.speeds.pop(r['id'],None)
            self.unavailable[r['id']]=str(reason)[:300]
            if len(self.unavailable)>128:self.unavailable={r['id']:str(reason)[:300]}

    def flush(self,today=None):
        with self.lock:
            cutoff=((today or datetime.now().date())-timedelta(days=6)).isoformat()
            try:
                with self.db:
                    self.db.execute('DELETE FROM daily WHERE day<?',(cutoff,))
                    for row in self.pending.values():
                        if row[0]>=cutoff:self.db.execute('INSERT OR REPLACE INTO daily VALUES(?,?,?,?,?,?,?,?,?,?,?)',row)
                    for key,(identity,counter,stamp) in self.baselines.items():
                        self.db.execute('INSERT OR REPLACE INTO baseline VALUES(?,?,?,?)',(key,identity,counter,stamp))
                    self.db.execute('DELETE FROM baseline WHERE key NOT IN (SELECT DISTINCT key FROM daily)')
                self.pending={k:v for k,v in self.pending.items() if k[0]>=cutoff}
                retained={r[0] for r in self.db.execute('SELECT DISTINCT key FROM daily')}
                self.baselines={k:v for k,v in self.baselines.items() if k in retained}
                self.error=None;self.last_flush=time.monotonic()
            except sqlite3.Error as e:
                self.error='流量统计保存失败：'+str(e)
                # Bound RAM if disk is full; discarded samples are explicitly flagged.
                if len(self.pending)>1024:self.pending.clear()
                self.last_flush=time.monotonic()

    def report(self,today=None):
        with self.lock:
            day=today or datetime.now().date();cutoff=(day-timedelta(days=6)).isoformat()
            rows={(r[0],r[1]):list(r) for r in self.db.execute('SELECT * FROM daily WHERE day>=? AND day<=? ORDER BY day DESC',(cutoff,day.isoformat()))}
            rows.update({k:v for k,v in self.pending.items() if cutoff<=k[0]<=day.isoformat()})
            keys=['day','key','vmid','nic','name','total','lunch','evening','offpeak','seconds','gaps']
            return {'days':7,'unit':'bytes','rows':[dict(zip(keys,v)) for k,v in sorted(rows.items(),reverse=True)],
                    'speeds':dict(self.speeds),'error':self.error,
                    'unavailable':dict(self.unavailable),
                    'definition':'所选虚拟网卡流控前发送的字节；包含协议、重传及可能被流控丢弃的数据，不等同平台有效流量或出口账单'}

    def close(self):
        self.flush();self.db.close()
