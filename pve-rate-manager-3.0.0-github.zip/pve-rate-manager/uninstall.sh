#!/bin/bash
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo '请以 root 执行。'; exit 1; }
systemctl disable --now pve-rate-manager.service
/usr/bin/python3 /opt/pve-rate-manager/manager.py release-all
/usr/bin/python3 /opt/pve-rate-manager/integration.py remove
systemctl restart pvedaemon.service pveproxy.service
rm -f -- /etc/systemd/system/pve-rate-manager.service /usr/share/perl5/PVE/API2/RateManager.pm
rm -f -- /usr/share/pve-manager/js/rate-manager/index.html /usr/share/pve-manager/js/rate-manager/app.js /usr/share/pve-manager/js/rate-manager/style.css
rm -f -- /opt/pve-rate-manager/adaptive.py /opt/pve-rate-manager/traffic.py /opt/pve-rate-manager/storage.py /opt/pve-rate-manager/manager.py /opt/pve-rate-manager/integration.py /opt/pve-rate-manager/deployment.py /opt/pve-rate-manager/pve-hook.js
systemctl daemon-reload
echo '已卸载 PVE 入口、停止后台并解除全部规则网卡限速；请强制刷新 PVE 页面。'
echo '规则和备份保留在 /var/lib/pve-rate-manager；再次安装会继续使用这些规则。'
