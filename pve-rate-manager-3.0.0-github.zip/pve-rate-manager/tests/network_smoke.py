#!/usr/bin/python3
"""Optional real-kernel test in TWO fresh network namespaces; no PVE VM touched."""
import argparse
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import threading
import time

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from adaptive import Shaper

SIZE=4*1024*1024
PORT=19875


def run(c,**kw):return subprocess.run(c,check=True,**kw)


def client(direction):
    start=time.monotonic()
    with socket.create_connection(('192.0.2.1',PORT),timeout=30) as s:
        s.settimeout(30);s.sendall(direction.encode())
        if direction=='U':s.sendall(b'x'*SIZE);s.shutdown(socket.SHUT_WR)
        while s.recv(65536):pass
    print(time.monotonic()-start)


def worker(host,guest):
    # Refuse to shape anything unless actually inside the freshly created test namespace.
    if not host.startswith('prm-smoke-') or os.stat('/proc/self/ns/net').st_ino!=os.stat('/run/netns/'+host).st_ino:
        raise RuntimeError('Refusing to run outside the dedicated test namespace')
    ready=threading.Event();errors=[]
    def server():
        try:
            with socket.socket() as listener:
                listener.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
                listener.bind(('192.0.2.1',PORT));listener.listen();listener.settimeout(60);ready.set()
                for _ in range(3):
                    conn,_=listener.accept()
                    with conn:
                        if conn.recv(1)==b'D':conn.sendall(b'x'*SIZE)
                        else:
                            count=0
                            while True:
                                data=conn.recv(65536)
                                if not data:break
                                count+=len(data)
                            if count!=SIZE:raise RuntimeError('Upload byte count mismatch')
                            conn.sendall(b'OK')
        except Exception as e:errors.append(str(e));ready.set()
    threading.Thread(target=server,daemon=True).start();ready.wait(5)
    if errors:raise RuntimeError(errors)
    r={'vmid':999999,'nic':'net31','id':'f'*32};s=Shaper()
    def transfer(direction):
        p=run(['/usr/sbin/ip','netns','exec',guest,sys.executable,__file__,'--client',direction],capture_output=True,text=True)
        return float(p.stdout.strip())
    try:
        s.apply(r,.5)
        limited=transfer('U');download=transfer('D')
        s.release(r);unlimited=transfer('U')
        if errors:raise RuntimeError(errors)
        if not(limited>4 and download<limited*.6 and unlimited<limited*.6):
            raise RuntimeError('Unexpected throughput; inspect printed timings: '+str((limited,download,unlimited)))
        print(json.dumps({'limited_upload_seconds':limited,'unlimited_download_seconds':download,'released_upload_seconds':unlimited,'result':'PASS'}))
    finally:s.release(r)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run',action='store_true');p.add_argument('--worker',nargs=2);p.add_argument('--client',choices=['U','D'])
    a=p.parse_args()
    if a.client:return client(a.client)
    if a.worker:return worker(*a.worker)
    if not a.run:p.print_help();return
    if not hasattr(os,'geteuid') or os.geteuid()!=0:raise RuntimeError('Linux root is required')
    host=f'prm-smoke-{os.getpid()}-h';guest=f'prm-smoke-{os.getpid()}-g';created=[]
    existing=run(['/usr/sbin/ip','netns','list'],capture_output=True,text=True).stdout
    if host in existing or guest in existing:raise RuntimeError('Test namespace name collision')
    try:
        for name in (host,guest):run(['/usr/sbin/ip','netns','add',name]);created.append(name)
        ip=['/usr/sbin/ip','-n',host]
        run(ip+['link','add','tap999999i31','type','veth','peer','name','prmguest'])
        run(ip+['link','set','prmguest','netns',guest])
        for ns,dev,addr in [(host,'tap999999i31','192.0.2.1/30'),(guest,'prmguest','192.0.2.2/30')]:
            run(['/usr/sbin/ip','-n',ns,'addr','add',addr,'dev',dev])
            run(['/usr/sbin/ip','-n',ns,'link','set',dev,'up'])
            run(['/usr/sbin/ip','-n',ns,'link','set','lo','up'])
        run(['/usr/sbin/ip','netns','exec',host,sys.executable,__file__,'--worker',host,guest])
    finally:
        for name in reversed(created):subprocess.run(['/usr/sbin/ip','netns','del',name],check=False)


if __name__=='__main__':main()
