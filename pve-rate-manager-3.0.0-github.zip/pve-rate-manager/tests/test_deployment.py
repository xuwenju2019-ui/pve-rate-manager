import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

spec=importlib.util.spec_from_file_location('deployment',Path(__file__).resolve().parents[1]/'deployment.py')
d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)


class DeploymentTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.a=self.root/'present.py';self.a.write_text('old',encoding='utf-8')
        self.b=self.root/'absent.py'
        self.patch1=patch.object(d,'BACKUPS',self.root/'backups');self.patch1.start();self.addCleanup(self.patch1.stop)
        self.patch2=patch.object(d,'TARGETS',[self.a,self.b]);self.patch2.start();self.addCleanup(self.patch2.stop)
        self.patch3=patch.object(d,'RULES',self.root/'rules.json');self.patch3.start();self.addCleanup(self.patch3.stop)

    def test_restore_existing_and_remove_new(self):
        folder=d.snapshot()
        self.a.write_text('new',encoding='utf-8');self.b.write_text('installed',encoding='utf-8')
        d.restore(folder)
        self.assertEqual(self.a.read_text(),'old');self.assertFalse(self.b.exists())

    def test_incomplete_snapshot_refused_before_changes(self):
        folder=d.snapshot();(folder/'0.bin').unlink()
        self.a.write_text('unchanged',encoding='utf-8')
        with self.assertRaises(ValueError):d.restore(folder)
        self.assertEqual(self.a.read_text(),'unchanged')

    def test_outside_backup_refused(self):
        with self.assertRaises(ValueError):d.restore(self.root)

    def test_target_substitution_refused(self):
        folder=d.snapshot();manifest=folder/'manifest.json'
        entries=json.loads(manifest.read_text());entries[0]['path']='/etc/shadow'
        manifest.write_text(json.dumps(entries),encoding='utf-8')
        with self.assertRaises(ValueError):d.restore(folder)
        self.assertEqual(self.a.read_text(),'old')


if __name__=='__main__':unittest.main()
