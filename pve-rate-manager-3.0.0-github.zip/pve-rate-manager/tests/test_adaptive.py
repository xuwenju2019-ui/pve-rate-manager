from datetime import datetime,date,timedelta
import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch
from test_manager import m
from adaptive import phase,Controller,Shaper
from traffic import TrafficStore,split_interval


def adaptive():
    return m.validate_rule({'id':'a'*32,'name':'上行自适应','vmid':100,'nic':'net1','enabled':True,'mode':'adaptive',
        'ranges':{'off_am':{'min':'1','max':'3'},'off_pm':{'min':'2','max':'5'}}})


class AdaptiveTests(unittest.TestCase):
    def test_boundaries(self):
        for t,p in [('00:00','off_am'),('11:29','off_am'),('11:30','lunch'),('13:59','lunch'),('14:00','off_pm'),('16:59','off_pm'),('17:00','evening'),('23:59','evening')]:
            self.assertEqual(phase(datetime.fromisoformat('2026-11-08T'+t)),p)

    def test_free_ranges_validated(self):
        r=adaptive();self.assertEqual(r['ranges']['off_pm']['max'],'5')
        for val in ('0','-1','NaN','Infinity'):
            r=adaptive();r['ranges']['off_am']['min']=val
            with self.assertRaises(ValueError):m.validate_rule(r)
        r=adaptive();r['ranges']['off_am']['min']='4'
        with self.assertRaises(ValueError):m.validate_rule(r)

    def test_controller_bounds_cooldown_and_recovery(self):
        c=Controller();cap,_=c.choose('nic','1','3',1,100,0);self.assertEqual(cap,1)
        for t in (5,10,15,20):cap,_=c.choose('nic','1','3',3,100,t)
        self.assertEqual(cap,1)
        cap,_=c.choose('nic','1','3',3,100,30);self.assertGreater(cap,1)
        for t in range(60,1200,30):cap,_=c.choose('nic','1','3',3,100,t)
        self.assertEqual(cap,3)
        for t in range(1200,2400,30):cap,_=c.choose('nic','1','3',0,0,t)
        self.assertGreaterEqual(cap,1);self.assertLess(cap,3)

    def test_peaks_release_and_downstream_native_rate_removed(self):
        with tempfile.TemporaryDirectory() as folder:
            manager=m.Manager(Path(folder),True)
            try:
                r=manager.put({'revision':0,'rule':adaptive()})
                manager.tick(datetime.fromisoformat('2026-11-08T10:00'))
                self.assertEqual(manager.shaper.rates[r['id']],1)
                self.assertNotIn('rate=',manager.backend.configs[100]['net1'])
                manager.tick(datetime.fromisoformat('2026-11-08T11:30'))
                self.assertNotIn(r['id'],manager.shaper.rates)
                manager.tick(datetime.fromisoformat('2026-11-08T14:00'))
                self.assertEqual(manager.shaper.rates[r['id']],2)
                manager.tick(datetime.fromisoformat('2026-11-08T17:00'))
                self.assertNotIn(r['id'],manager.shaper.rates)
                manager.tick(datetime.fromisoformat('2026-11-09T00:00'))
                self.assertEqual(manager.shaper.rates[r['id']],1)
            finally:manager.traffic.close()

    def test_fixed_rule_migration_and_pause(self):
        with tempfile.TemporaryDirectory() as folder:
            manager=m.Manager(Path(folder),True)
            try:
                r=manager.put({'revision':0,'rule':adaptive()});manager.tick(datetime.fromisoformat('2026-11-08T10:00'))
                manager.toggle({'revision':1,'enabled':False});manager.tick(datetime.fromisoformat('2026-11-08T10:00'))
                self.assertNotIn(r['id'],manager.shaper.rates)
                manager.sample_traffic();self.assertIn(r['id'],manager.traffic.baselines)
            finally:manager.traffic.close()

    def test_filter_ownership_is_strict(self):
        s=Shaper();good={'pref':49152,'kind':'matchall','handle':1,'options':{'actions':[{'kind':'mirred','mirred_action':'redirect','direction':'egress','to_dev':'prm100i1'}]}}
        self.assertTrue(s.is_ours(good,'prm100i1'))
        self.assertFalse(s.is_ours(good,'foreign'))
        good['pref']=50;self.assertFalse(s.is_ours(good,'prm100i1'))

    def test_refuse_foreign_filter_or_ifb(self):
        s=Shaper(lambda cmd:'[]');r=adaptive()
        with patch.object(s,'links',side_effect=[{'ifname':'tap100i1'},None]),patch.object(s,'filters',return_value=[{'pref':1,'kind':'u32'}]):
            with self.assertRaises(RuntimeError):s.inspect(r)
        with patch.object(s,'links',side_effect=[{'ifname':'tap100i1'},{'ifalias':'someone-else'}]):
            with self.assertRaises(RuntimeError):s.inspect(r)

    def test_release_never_touches_tap_egress(self):
        commands=[];s=Shaper(lambda c:commands.append(c) or '[]');r=adaptive()
        with patch.object(s,'links',return_value=None):s.release(r)
        self.assertEqual(commands,[])


class TrafficTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.store=TrafficStore(Path(self.tmp.name)/'stats.sqlite3');self.addCleanup(self.store.close)
        self.r=adaptive()

    def test_split_midnight_conserves_bytes(self):
        a=datetime(2026,11,8,23,59,55).timestamp();b=a+10
        parts=split_interval(a,b,1001)
        self.assertEqual(sum(x[2] for x in parts),1001)
        self.assertEqual([x[0] for x in parts],['2026-11-08','2026-11-09'])
        self.assertEqual([x[1] for x in parts],['evening','off_am'])

    def test_peak_subtotals_and_reset(self):
        a=datetime(2026,11,8,11,29,55).timestamp()
        self.store.sample(self.r,'instance',100,a);self.store.sample(self.r,'instance',1100,a+10)
        row=self.store.report(date(2026,11,8))['rows'][0]
        self.assertEqual(row['total'],1000);self.assertEqual(row['lunch'],500);self.assertEqual(row['offpeak'],500)
        self.store.sample(self.r,'new-instance',10,a+15)
        self.assertEqual(self.store.report(date(2026,11,8))['rows'][0]['total'],1000)

    def test_seven_calendar_days(self):
        for i in range(9):
            a=datetime(2026,11,1+i,1).timestamp()
            self.store.sample(self.r,'instance',i*1000,a);self.store.sample(self.r,'instance',i*1000+500,a+5)
        self.store.flush(date(2026,11,9))
        rows=self.store.report(date(2026,11,9))['rows']
        self.assertEqual(len(rows),7);self.assertEqual(min(r['day'] for r in rows),'2026-11-03')
        self.assertEqual(self.store.db.execute('SELECT MIN(day) FROM daily').fetchone()[0],'2026-11-03')

    def test_restart_recovers_continuous_counter(self):
        a=datetime.now().timestamp();self.store.sample(self.r,'instance',100,a);self.store.sample(self.r,'instance',300,a+5);self.store.flush()
        other=TrafficStore(self.store.path)
        try:
            other.sample(self.r,'instance',500,a+10)
            self.assertEqual(other.report()['rows'][0]['total'],400)
        finally:other.close()
