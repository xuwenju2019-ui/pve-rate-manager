import json
import unittest
from adaptive import Shaper
from test_adaptive import adaptive


class Kernel:
    def __init__(self):
        self.commands=[];self.devices={'tap100i1':{'ifname':'tap100i1'}};self.q={};self.f=[];self.classes=[]
    def run(self,c):
        self.commands.append(c)
        if c[0].endswith('/modprobe'):return ''
        if c[0].endswith('/ip'):
            if '-j' in c:return json.dumps(list(self.devices.values()))
            if c[1:3]==['link','add']:
                self.devices[c[3]]={'ifname':c[3],'linkinfo':{'info_kind':'ifb'}}
            elif c[1:3]==['link','delete']:self.devices.pop(c[-1],None)
            elif 'alias' in c:self.devices[c[c.index('dev')+1]]['ifalias']=c[-1]
            return ''
        if '-j' in c:
            dev=c[c.index('dev')+1]
            if 'qdisc' in c:return json.dumps(self.q.get(dev,[]))
            if 'filter' in c:return json.dumps(self.f)
            if 'class' in c:return json.dumps(self.classes)
        dev=c[c.index('dev')+1]
        if c[1:3]==['qdisc','add']:
            if 'clsact' in c:self.q.setdefault(dev,[]).append({'kind':'clsact'})
            elif 'htb' in c:self.q[dev]=[{'kind':'htb'}]
        elif c[1:3]==['class','replace']:self.classes=[{'class':'htb','handle':'1:1'}]
        elif c[1:3]==['filter','add']:
            self.f=[{'pref':49152,'kind':'matchall','options':{'handle':1,'actions':[{'kind':'mirred','mirred_action':'redirect','direction':'egress','to_dev':c[-1]}]}}]
        elif c[1:3]==['filter','del']:self.f=[]
        return ''


class CommandTests(unittest.TestCase):
    def test_real_tc_nested_handle_and_summary(self):
        k=Kernel();s=Shaper(k.run);r=adaptive();s.apply(r,1)
        leaf=k.f[0]
        self.assertNotIn('handle',leaf)
        self.assertEqual(leaf['options']['handle'],1)
        k.f=[{'pref':49152,'kind':'matchall','chain':0},leaf]
        self.assertEqual(s.filters('tap100i1'),[leaf])
        s.release(r)
        self.assertEqual(k.f,[])

    def test_build_update_release(self):
        k=Kernel();s=Shaper(k.run);r=adaptive()
        s.apply(r,1.5)
        self.assertIn('prm100i1',k.devices)
        classes=[c for c in k.commands if c[1:3]==['class','replace']]
        self.assertIn('1572864bps',classes[-1])
        self.assertTrue(any(c[1:3]==['filter','add'] and 'ingress' in c for c in k.commands))
        self.assertFalse(any('tap100i1' in c and 'root' in c for c in k.commands))
        s.apply(r,2)
        self.assertEqual(len([c for c in k.commands if c[1:3]==['filter','add']]),1)
        s.release(r)
        self.assertNotIn('prm100i1',k.devices);self.assertEqual(k.f,[])
        self.assertIn({'kind':'clsact'},k.q['tap100i1'])

    def test_rollback_partial_setup(self):
        k=Kernel()
        def runner(c):
            if 'fq_codel' in c:raise RuntimeError('unsupported qdisc')
            return k.run(c)
        s=Shaper(runner)
        with self.assertRaises(RuntimeError):s.apply(adaptive(),1)
        self.assertNotIn('prm100i1',k.devices)

    def test_foreign_egress_untouched(self):
        k=Kernel();k.q['tap100i1']=[{'kind':'clsact'},{'kind':'fq_codel','root':True}]
        s=Shaper(k.run);s.apply(adaptive(),1);s.release(adaptive())
        self.assertEqual(k.q['tap100i1'],[{'kind':'clsact'},{'kind':'fq_codel','root':True}])


if __name__=='__main__':unittest.main()
