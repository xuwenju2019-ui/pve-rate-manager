from pathlib import Path
import tempfile
import unittest
from storage import prune_files,prune_installs,prune_integration


class RetentionTests(unittest.TestCase):
    def test_only_owned_files_are_pruned_and_budget_holds(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)
            (p/'unrelated.json').write_text('keep')
            for i in range(5):(p/f'{i}-100-net1.json').write_bytes(b'x'*10)
            prune_files(p,keep=2,budget=20)
            self.assertEqual(len(list(p.glob('*-100-net1.json'))),2)
            self.assertTrue((p/'unrelated.json').exists())

    def test_snapshot_cleanup_stays_in_owned_numeric_directories(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)
            for name in ['100','200','300','manual']:
                (p/name).mkdir();(p/name/'file').write_bytes(b'x'*10)
            prune_installs(p,keep=2,budget=20)
            self.assertEqual(set(x.name for x in p.iterdir()),{'200','300','manual'})

    def test_integration_cleanup_preserves_manual_backups(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder);(p/'entry-fix-old').mkdir()
            for i in range(5):(p/f'{i}-API2.pm').write_bytes(b'x'*10)
            prune_integration(p,keep=2,budget=20)
            self.assertEqual(len(list(p.glob('*-API2.pm'))),2)
            self.assertTrue((p/'entry-fix-old').is_dir())
