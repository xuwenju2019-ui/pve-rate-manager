#!/usr/bin/perl
use strict;
use warnings;
use FindBin;
use JSON;
use Test::More;
require "$FindBin::Bin/../RateManager.pm";

my $name = chr(0x591c) . chr(0x95f4) . chr(0x4e0b) . chr(0x8f7d);
my $wide = '{"rule":{"name":"' . $name . '","enabled":true,"days":[0,6]}}';
my $body = PVE::API2::RateManager::decode_payload($wide);
is($body->{rule}->{name}, $name, 'PVE character string accepts Chinese rule name');
ok($body->{rule}->{enabled}, 'boolean preserved');
is_deeply($body->{rule}->{days}, [0,6], 'weekly selection preserved');
my $wire = encode_json($body);
ok(!utf8::is_utf8($wire), 'forwarded request is UTF-8 bytes');
is(decode_json($wire)->{rule}->{name}, $name, 'Chinese survives request round trip');
my $escaped = '{"rule":{"name":"\u591c\u95f4\u4e0b\u8f7d"}}';
is(PVE::API2::RateManager::decode_payload($escaped)->{rule}->{name}, $name, 'escaped Unicode accepted');
eval { PVE::API2::RateManager::decode_payload('[]'); };
like($@, qr/Expected JSON object/, 'non-object rejected');
done_testing();
