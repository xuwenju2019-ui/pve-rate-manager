"""Size/count retention for files exclusively owned by this application."""
from pathlib import Path
import re
import shutil


def prune_files(folder,keep=100,budget=10*1024*1024,reserve=0):
    folder=Path(folder)
    if not folder.exists():return
    files=sorted((p for p in folder.iterdir() if p.is_file() and not p.is_symlink()
                  and re.fullmatch(r'\d+-\d+-net\d+\.json',p.name)),key=lambda p:p.stat().st_mtime,reverse=True)
    used=reserve
    for i,p in enumerate(files):
        size=p.stat().st_size
        if i>=keep or used+size>budget:p.unlink()
        else:used+=size


def prune_installs(folder,keep=3,budget=128*1024*1024):
    folder=Path(folder)
    if not folder.exists():return
    dirs=sorted((p for p in folder.iterdir() if p.is_dir() and not p.is_symlink() and p.name.isdigit()),reverse=True)
    used=0
    for i,p in enumerate(dirs):
        size=sum(x.stat().st_size for x in p.rglob('*') if x.is_file() and not x.is_symlink())
        if i>=keep or used+size>budget:
            if p.resolve().parent!=folder.resolve():raise ValueError('Unexpected cleanup path')
            shutil.rmtree(p)
        else:used+=size


def prune_integration(folder,keep=20,budget=64*1024*1024):
    folder=Path(folder)
    if not folder.exists():return
    files=sorted((p for p in folder.iterdir() if p.is_file() and not p.is_symlink()
                  and re.fullmatch(r'\d+-(API2\.pm|pvemanagerlib\.js|index\.html\.tpl)',p.name)),reverse=True)
    used=0
    for i,p in enumerate(files):
        n=p.stat().st_size
        if i>=keep or used+n>budget:p.unlink()
        else:used+=n
