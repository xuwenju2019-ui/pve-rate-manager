'use strict';
const $ = s => document.querySelector(s);
const days = ['周一','周二','周三','周四','周五','周六','周日'];
let state = null, csrf = '', editing = null, busy = false, timer;
function el(tag, text, cls) { const n=document.createElement(tag); if(text!==undefined)n.textContent=text; if(cls)n.className=cls; return n; }
function toast(text) { $('#toast').textContent=text; $('#toast').hidden=false; clearTimeout(timer); timer=setTimeout(()=>$('#toast').hidden=true,5000); }
function pveToken() {
 try { return window.parent.Proxmox?.CSRFPreventionToken || ''; } catch(e) { return ''; }
}
function showLogin(){
 $('#login').hidden=false; $('#dashboard').hidden=true;
 if($('#editor').open)$('#editor').close(); state=null;
}
async function api(path, body) {
 const options = body===undefined ? {} : {method:'POST',headers:{'Content-Type':'application/json','CSRFPreventionToken':pveToken()},body:JSON.stringify({payload:JSON.stringify(body)})};
 const res=await fetch('/api2/json/rate-manager/'+path,{...options,credentials:'same-origin',cache:'no-store'});
 const envelope=await res.json();
 if(!res.ok){
   if(res.status===401||res.status===403)showLogin();
   throw Error(envelope.message||envelope.error||'PVE 请求失败');
 }
 return typeof envelope.data==='string' ? JSON.parse(envelope.data) : envelope.data;
}
async function refresh(){
 try {const s=await api('status');state=s;$('#login').hidden=true;$('#dashboard').hidden=false;render();}
 catch(e){if(state){$('#connection').textContent='连接中断 · 状态未更新';$('#connection').className='badge error';}else if($('#login').hidden)showLogin();}
}
function render(){
 $('#connection').textContent='程序运行中';$('#connection').className='badge';
 $('#node').textContent='本地节点 / '+state.node;$('#clock').textContent=state.time.replace('T',' ');$('#timezone').textContent=[...new Set(state.zone)].join(' / ');
 $('#demo-banner').hidden=!state.demo;$('#scheduler-state').textContent=state.enabled?'已开启':'已暂停';
 $('#global-toggle').setAttribute('aria-checked',String(state.enabled));$('#global-toggle b').textContent=state.enabled?'开启':'暂停';
 const vals=Object.values(state.runtime);const active=vals.filter(x=>x.ok&&x.target!==null).length; const errors=vals.filter(x=>!x.ok).length;
 $('#summary').textContent=active+' 张限速中'+(errors?' / '+errors+' 项异常':'');$('#count').textContent=state.rules.length;
 $('#last-tick').textContent=state.last_tick?'最近检查 '+state.last_tick.split('T')[1]:'等待首次检查';
 $('#empty').hidden=state.rules.length>0;$('#rules').replaceChildren();
 for(const r of state.rules){
  const info=state.runtime[r.id];const card=el('article',undefined,'rule');const top=el('div',undefined,'rule-top');
  top.append(el('div','VM '+r.vmid+' / '+r.nic,'rule-id'));const name=el('div',undefined,'rule-name');name.append(el('h3',r.name),el('small',r.policy==='daily'?'每天':r.policy==='weekly'?'每周 '+r.days.map(d=>days[d]).join('、'):'仅一次'));top.append(name);
  let label='等待执行',cls='wait';if(info){if(!info.ok){label='执行失败';cls='error';}else{label=info.target===null?'未限速':'正在限速';cls=info.target===null?'wait':'';}}
  if(!r.enabled&&info?.ok)label='规则已关闭 · 未限速';
  top.append(el('span',label,'badge '+cls));const speed=el('div',undefined,'rule-speed');
  const adaptive=r.mode==='adaptive';
  speed.append(document.createTextNode(adaptive?(info?.ok?(info.target===null?'上行放开':info.target+' '):'待核验'):r.rate+' '),el('small',adaptive&&info?.target==null?'':'MB/s'));top.append(speed);card.append(top);
  const bottom=el('div',undefined,'rule-bottom');const times=el('div');
  times.append(el('span','限速时段','label'));
  if(adaptive){times.append(el('div','午高峰 11:30–14:00 · 晚高峰 17:00–00:00','hint'),el('div','非高峰 '+r.ranges.off_am.min+'–'+r.ranges.off_am.max+' / '+r.ranges.off_pm.min+'–'+r.ranges.off_pm.max+' MB/s','hint'),el('div','下行不限速 · '+(info?.reason||'按宿主机时间执行'),'hint'));}
  else if(r.policy==='once'){times.append(el('div',r.once_start.replace('T',' ')+' → '+r.once_end.replace('T',' '),'hint'));}
  else {times.append(el('div',r.start+' → '+r.end+(r.end<r.start?' 次日':''),'time-window'));const rail=el('div',undefined,'rail');
   const mins=v=>{const [h,m]=v.split(':').map(Number);return h*60+m;};let a=mins(r.start)/14.4,b=mins(r.end)/14.4;
   // SVG uses attributes instead of inline styles under strict CSP.
   const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 100 6');svg.setAttribute('preserveAspectRatio','none');svg.setAttribute('width','100%');svg.setAttribute('height','6');
   const rect=(x,w)=>{const n=document.createElementNS(svg.namespaceURI,'rect');n.setAttribute('x',x);n.setAttribute('width',w);n.setAttribute('height','6');n.setAttribute('fill','#c75d18');svg.append(n);};
   if(b>a)rect(a,b-a);else{rect(a,100-a);rect(0,b);}rail.append(svg);times.append(rail);
  }
  bottom.append(times);const next=el('div');next.append(el('div','下一次切换','label'),el('p',state.next[r.id]?.replace('T',' ')||(!state.enabled?'调度已暂停':!r.enabled?'规则已关闭':'已结束'),'hint'));bottom.append(next);
  const actions=el('div',undefined,'rule-actions');const toggle=el('button',r.enabled?'关闭规则':'开启规则','quiet');toggle.addEventListener('click',()=>toggleRule(r));
  const edit=el('button','编辑','quiet');edit.addEventListener('click',()=>openEditor(r));const del=el('button','删除','quiet danger');del.addEventListener('click',()=>deleteRule(r));actions.append(toggle,edit,del);bottom.append(actions);card.append(bottom);
  if(info&&!info.ok)card.append(el('p',info.error,'rule-error'));$('#rules').append(card);
  const today=state.time.slice(0,10);const total=(state.traffic?.rows||[]).filter(x=>x.key===r.id&&x.day===today).reduce((n,x)=>n+x.total,0);
  card.append(el('p','今日上行 '+bytes(total)+' · 当前上传 '+(state.traffic?.speeds?.[r.id]?.toFixed(2)??'暂无采样')+' MB/s','rule-stat'));
 }
 $('#events').replaceChildren();if(!state.events.length)$('#events').append(el('p','暂无执行记录。添加规则后，这里会显示限速变更和异常。','hint'));
 for(const event of state.events){const row=el('div',undefined,'event'+(event.error?' error':''));row.append(el('time',event.time.replace('T',' ')),el('span',event.text));$('#events').append(row);}
 renderStats();
}
async function action(fn){if(busy)return;busy=true;try{await fn();await refresh();}catch(e){toast(e.message);}finally{busy=false;}}
async function toggleRule(r){if(r.enabled&&!confirm('关闭此规则并完全解除该网卡限速？'))return;await action(async()=>{await api('rule',{revision:state.revision,rule:{...r,enabled:!r.enabled}});toast('已保存，正在应用');});}
async function deleteRule(r){if(!confirm('解除 VM '+r.vmid+' '+r.nic+' 的限速并删除此规则？'))return;await action(async()=>{await api('delete',{revision:state.revision,id:r.id});toast('已解除限速并删除');});}
const form=$('#rule-form');
for(let i=0;i<7;i++){const label=el('label');const input=el('input');input.type='checkbox';input.value=i;input.name='day';label.append(input,el('span',days[i]));$('#weekdays').append(label);}
function policyFields(){const adaptive=form.elements.mode.value==='adaptive';$('#adaptive-fields').hidden=!adaptive;$('#fixed-fields').hidden=adaptive;for(const x of $('#fixed-fields').querySelectorAll('input,select'))x.disabled=adaptive;for(const x of $('#adaptive-fields').querySelectorAll('input')){x.disabled=!adaptive;x.required=adaptive;}const p=form.elements.policy.value;$('#weekly-fields').hidden=p!=='weekly';$('#once-fields').hidden=p!=='once';$('#recurring-fields').hidden=p==='once';for(const k of ['start','end'])form.elements[k].required=!adaptive&&p!=='once';for(const k of ['once_start','once_end'])form.elements[k].required=!adaptive&&p==='once';$('#time-hint').textContent=p==='once'?'仅在所选日期执行一次；结束后完全解除限速。':'关闭时间早于开启时间时，自动延续至次日。';}
form.elements.policy.addEventListener('change',policyFields);
form.elements.mode.addEventListener('change',policyFields);
async function loadNics(selected){const vmid=form.elements.vmid.value;const select=form.elements.nic;select.replaceChildren(new Option('读取网卡…',''));$('#nic-detail').textContent='读取中…';if(!vmid)return;const data=await api('nics?vmid='+encodeURIComponent(vmid));select.replaceChildren(new Option('请选择网卡',''));for(const n of data){const opt=new Option(n.nic,n.nic);opt.dataset.config=n.config;select.append(opt);}if(selected)select.value=selected;select.disabled=!!editing;nicDetail();}
function nicDetail(){$('#nic-detail').textContent=form.elements.nic.selectedOptions[0]?.dataset.config||'请选择一张现有网卡。';}
form.elements.nic.addEventListener('change',nicDetail);form.elements.vmid.addEventListener('change',()=>loadNics().catch(e=>$('#form-error').textContent=e.message));
async function openEditor(r=null){
 editing=r;form.reset();$('#preview').hidden=true;$('#form-error').textContent='';$('#save-button').disabled=true;$('#editor-title').textContent=r?'编辑规则':'添加规则';
 form.elements.vmid.disabled=!!r;form.elements.nic.disabled=!!r;
 for(const k of ['name','rate','policy','start','end','once_start','once_end'])if(r&&r[k]!=null)form.elements[k].value=r[k];
 form.elements.enabled.checked=r?r.enabled:true;
 form.elements.mode.value=r?(r.mode||'fixed'):'adaptive';
 if(r?.mode==='adaptive'){form.elements.am_min.value=r.ranges.off_am.min;form.elements.am_max.value=r.ranges.off_am.max;form.elements.pm_min.value=r.ranges.off_pm.min;form.elements.pm_max.value=r.ranges.off_pm.max;}
 for(const input of document.querySelectorAll('[name=day]'))input.checked=r?r.days?.includes(Number(input.value)):Number(input.value)<5;
 policyFields();$('#editor').showModal();
 try{const vms=await api('vms');const select=form.elements.vmid;select.replaceChildren(new Option('请选择虚拟机',''));for(const vm of vms){if(!vm.template)select.append(new Option(vm.vmid+' · '+(vm.name||'未命名')+' · '+(vm.status==='running'?'运行中':'已停止'),vm.vmid));}
  if(r){if(!vms.some(vm=>vm.vmid===r.vmid))throw Error('此虚拟机已不在当前节点，请先检查迁移状态');select.value=r.vmid;await loadNics(r.nic);}else{select.value=vms.some(vm=>vm.vmid===100)?'100':select.options[1]?.value||'';await loadNics();}
  $('#save-button').disabled=false;
 }catch(e){$('#form-error').textContent=e.message;}
}
function formRule(){const r={id:editing?.id||null,mode:form.elements.mode.value};for(const k of ['name','rate','policy','start','end','once_start','once_end','nic'])r[k]=form.elements[k].value;r.vmid=Number(form.elements.vmid.value);r.enabled=form.elements.enabled.checked;r.days=[...document.querySelectorAll('[name=day]:checked')].map(x=>Number(x.value));if(r.mode==='adaptive')r.ranges={off_am:{min:form.elements.am_min.value,max:form.elements.am_max.value},off_pm:{min:form.elements.pm_min.value,max:form.elements.pm_max.value}};return r;}
$('#preview-button').addEventListener('click',async()=>{if(!form.reportValidity())return;try{const p=await api('preview',{rule:formRule()});$('#preview').textContent='当前效果：'+(p.mode==='adaptive'?(p.limited?'上行自适应 '+p.range.min+'–'+p.range.max+' MB/s；下行不限速':'上行放开；下行不限速'):(p.limited?'双向限速 '+form.elements.rate.value+' MB/s':'完全解除限速'))+'\n修改前：'+p.before+'\n修改后：'+p.after+'\n下一次切换：'+(p.next?.replace('T',' ')||'无')+'\n预览未修改网卡配置。';$('#preview').hidden=false;$('#form-error').textContent='';}catch(e){$('#form-error').textContent=e.message;}});
form.addEventListener('submit',async e=>{e.preventDefault();$('#save-button').disabled=true;try{await api('rule',{revision:state.revision,rule:formRule()});$('#editor').close();toast('规则已保存，正在按当前时间应用');await refresh();}catch(e){$('#form-error').textContent=e.message;}finally{$('#save-button').disabled=false;}});
$('#close-editor').addEventListener('click',()=>$('#editor').close());$('#add').addEventListener('click',()=>openEditor());$('#empty-add').addEventListener('click',()=>openEditor());$('#refresh').addEventListener('click',refresh);
$('#global-toggle').addEventListener('click',()=>{if(state.enabled&&!confirm('暂停全部自动调度，并解除全部已管理网卡的限速？'))return;action(async()=>{await api('toggle',{revision:state.revision,enabled:!state.enabled});toast('已保存，正在应用');});});
function bytes(n){return (Number(n)/1e9).toFixed(3)+' GB';}
function filteredStats(){const day=$('#stats-day').value,nic=$('#stats-nic').value;return (state?.traffic?.rows||[]).filter(r=>(!day||r.day===day)&&(!nic||r.key===nic));}
function renderStats(){
 const oldDay=$('#stats-day').value,oldNic=$('#stats-nic').value;const today=state.time.slice(0,10);const dates=[];for(let i=0;i<7;i++){const d=new Date(today+'T12:00:00Z');d.setUTCDate(d.getUTCDate()-i);dates.push(d.toISOString().slice(0,10));}
 $('#stats-day').replaceChildren(new Option('最近 7 天',''),...dates.map(d=>new Option(d,d)));$('#stats-day').value=dates.includes(oldDay)?oldDay:(oldDay===''&&$('#stats-day').dataset.loaded?'':today);$('#stats-day').dataset.loaded='1';
 const items=new Map((state.traffic?.rows||[]).map(r=>[r.key,'VM '+r.vmid+' / '+r.nic+' · '+r.name]));$('#stats-nic').replaceChildren(new Option('全部网卡',''),...[...items].map(([k,v])=>new Option(v,k)));$('#stats-nic').value=items.has(oldNic)?oldNic:'';
 const rows=filteredStats();$('#stats-total').textContent=bytes(rows.reduce((n,r)=>n+r.total,0));$('#stats-error').textContent=[state.traffic?.error,...Object.entries(state.traffic?.unavailable||{}).map(([k,v])=>(state.rules.find(r=>r.id===k)?.name||k)+'：采样暂停，'+v)].filter(Boolean).join('；');$('#stats-body').replaceChildren();
 for(const r of rows){const tr=el('tr');tr.append(el('td',r.day+' / VM '+r.vmid+' '+r.nic),el('td',bytes(r.total)),el('td',bytes(r.lunch)),el('td',bytes(r.evening)),el('td',bytes(r.offpeak)),el('td',(r.gaps?'起点或间断 · ':'')+Math.round(r.seconds/60)+' 分钟'));$('#stats-body').append(tr);}
 if(!rows.length){const tr=el('tr'),td=el('td','暂无数据；从启用规则后开始统计。');td.colSpan=6;tr.append(td);$('#stats-body').append(tr);}
}
$('#stats-day').addEventListener('change',renderStats);$('#stats-nic').addEventListener('change',renderStats);
$('#export-stats').addEventListener('click',()=>{const lines=[['日期','VM','网卡','名称','总上行字节','午高峰字节','晚高峰字节','非高峰字节','采样秒','起点或间断次数'],...filteredStats().map(r=>[r.day,r.vmid,r.nic,r.name,r.total,r.lunch,r.evening,r.offpeak,r.seconds,r.gaps])];const csv='\uFEFF'+lines.map(row=>row.map(v=>'"'+String(v).replace(/^[=+@\-\t\r]/, m=>"'"+m).replaceAll('"','""')+'"').join(',')).join('\r\n');const url=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));const a=el('a');a.href=url;a.download='pve-upload-7days.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
refresh();setInterval(()=>{if(state&&!$('#editor').open&&!busy)refresh();},5000);
