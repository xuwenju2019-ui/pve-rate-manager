#!/usr/bin/python3
"""PVE Rate Manager. Standard library only. Local node, QEMU VMs only."""
import argparse
import copy
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import re
import socket
import socketserver
import struct
import subprocess
import threading
import time
from urllib.parse import urlsplit, parse_qs
import uuid
from adaptive import Controller, Shaper, DemoShaper, phase, next_boundary, nic_mac
from traffic import TrafficStore
from storage import prune_files

ROOT = Path(__file__).resolve().parent
VERSION = '3.0.0'
LOG = logging.getLogger('pve-rate-manager')


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temp = path.with_name(path.name + '.tmp')
    with temp.open('w', encoding='utf-8') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(temp, path)


def props(value):
    result = {}
    for part in value.split(','):
        k, sep, v = part.partition('=')
        if not sep or not k or not v or k in result:
            raise ValueError('网卡参数格式异常或存在重复字段，已拒绝修改')
        result[k] = v
    return result


def rate_value(value):
    try:
        d = Decimal(str(value))
        if not d.is_finite() or d <= 0 or d > 1000000 or d.as_tuple().exponent < -3:
            raise ValueError('限速应为 0.001 至 1000000 MB/s，最多三位小数')
        return format(d.normalize(), 'f')
    except InvalidOperation:
        raise ValueError('限速值无效')


def new_net(value, rate):
    props(value)
    parts = [p for p in value.split(',') if p.partition('=')[0] != 'rate']
    return ','.join(parts + ([] if rate is None else ['rate=' + rate_value(rate)]))


def same_net(a, b):
    x, y = props(a), props(b)
    ra, rb = x.pop('rate', None), y.pop('rate', None)
    # PVE rate=0 also represents unlimited; deleting it is preferable on a write.
    def rate(r):
        return Decimal(r) if r is not None else Decimal(0)
    return x == y and rate(ra) == rate(rb)


def validate_rule(data):
    r = {k: data.get(k) for k in ('id', 'name', 'vmid', 'nic', 'rate', 'enabled',
                                  'policy', 'start', 'end', 'days', 'once_start', 'once_end')}
    r['id'] = r['id'] or uuid.uuid4().hex
    if not isinstance(r['id'], str) or not re.fullmatch(r'[a-f0-9]{32}', r['id']):
        raise ValueError('规则 ID 无效')
    if not isinstance(r['name'], str) or not 1 <= len(r['name'].strip()) <= 80:
        raise ValueError('请输入 1 至 80 字的规则名称')
    r['name'] = r['name'].strip()
    if isinstance(r['vmid'], bool) or not re.fullmatch(r'[0-9]{3,9}', str(r['vmid'])):
        raise ValueError('VM ID 无效')
    r['vmid'] = int(r['vmid'])
    if not 100 <= r['vmid'] <= 999999999:
        raise ValueError('VM ID 超出范围')
    if not isinstance(r['nic'], str) or not re.fullmatch(r'net(?:[0-9]|[12][0-9]|3[01])', r['nic']):
        raise ValueError('网卡编号无效')
    if type(r['enabled']) is not bool:
        raise ValueError('启用状态无效')
    r['mode']=data.get('mode','fixed')
    r['mac']=data.get('mac')
    if r['mac'] is not None and (not isinstance(r['mac'],str) or not re.fullmatch(r'(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}',r['mac'])):
        raise ValueError('网卡 MAC 无效')
    if r['mode']=='adaptive':
        ranges=data.get('ranges')
        if not isinstance(ranges,dict):raise ValueError('请填写两个非高峰时段的速度范围')
        r['ranges']={}
        for key in ('off_am','off_pm'):
            limits=ranges.get(key,{})
            if not isinstance(limits,dict):raise ValueError('速度范围格式无效')
            lo,hi=rate_value(limits.get('min')),rate_value(limits.get('max'))
            if Decimal(lo)>Decimal(hi):raise ValueError('最高速度不能小于最低速度')
            r['ranges'][key]={'min':lo,'max':hi}
        r.update(policy='daily',days=list(range(7)),rate=None)
        return r
    if r['mode']!='fixed':raise ValueError('未知规则模式')
    r['rate'] = rate_value(r['rate'])
    if r['policy'] not in ('daily', 'weekly', 'once'):
        raise ValueError('请选择每天、每周或仅一次')
    if r['policy'] == 'once':
        for key in ('once_start', 'once_end'):
            if not isinstance(r[key], str) or not re.fullmatch(r'\d{4}-\d\d-\d\dT\d\d:\d\d', r[key]):
                raise ValueError('请选择完整的单次开始和结束日期时间')
        a, b = datetime.fromisoformat(r['once_start']), datetime.fromisoformat(r['once_end'])
        if b <= a:
            raise ValueError('结束日期时间必须晚于开始时间')
    else:
        for key in ('start', 'end'):
            if not isinstance(r[key], str) or not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d', r[key]):
                raise ValueError('时间必须为 HH:MM')
        if r['start'] == r['end']:
            raise ValueError('开启和关闭时间不能相同')
        if r['policy'] == 'weekly':
            if not isinstance(r['days'], list) or not r['days'] or any(type(d) is not int or d not in range(7) for d in r['days']):
                raise ValueError('每周至少选择一天')
            r['days'] = sorted(set(r['days']))
        else:
            r['days'] = list(range(7))
    return r


def window(r, day):
    a = datetime.combine(day, datetime.strptime(r['start'], '%H:%M').time())
    b = datetime.combine(day, datetime.strptime(r['end'], '%H:%M').time())
    if b <= a:
        b += timedelta(days=1)
    return a, b


def limited(r, now):
    if not r['enabled']:
        return False
    if r.get('mode')=='adaptive':return phase(now) in ('off_am','off_pm')
    if r['policy'] == 'once':
        return datetime.fromisoformat(r['once_start']) <= now < datetime.fromisoformat(r['once_end'])
    for offset in (-1, 0):
        day = now.date() + timedelta(days=offset)
        if day.weekday() in r['days']:
            a, b = window(r, day)
            if a <= now < b:
                return True
    return False


def next_change(r, now):
    if not r['enabled']:
        return None
    if r.get('mode')=='adaptive':return next_boundary(now)
    if r['policy'] == 'once':
        points = [datetime.fromisoformat(r[k]) for k in ('once_start', 'once_end')]
    else:
        points = []
        for i in range(-1, 9):
            day = now.date() + timedelta(days=i)
            if day.weekday() in r['days']:
                points.extend(window(r, day))
    future = sorted(p for p in points if p > now)
    # Overlapping consecutive overnight windows have no false transitions.
    for p in future:
        if limited(r, p - timedelta(microseconds=1)) != limited(r, p):
            return p.isoformat(timespec='minutes')
    return None


class PVE:
    def __init__(self, state):
        self.node = socket.gethostname().split('.')[0]
        self.state = state

    def run(self, argv):
        p = subprocess.run(argv, capture_output=True, text=True, timeout=25)
        if p.returncode:
            raise RuntimeError((p.stderr or p.stdout or 'PVE 命令执行失败').strip()[:1000])
        return p.stdout

    def get(self, path, *args):
        return json.loads(self.run(['/usr/bin/pvesh', 'get', path, '--output-format', 'json', *args]))

    def inventory(self):
        return self.get(f'/nodes/{self.node}/qemu')

    def snapshot(self, vmid, nic=None):
        path = f'/nodes/{self.node}/qemu/{int(vmid)}'
        config = self.get(path + '/config')
        current = self.get(path + '/config', '--current', '1')
        if not config.get('digest') or config['digest'] != current.get('digest'):
            raise RuntimeError('配置在读取时变化，请稍后重试')
        if config.get('lock'):
            raise RuntimeError('虚拟机被锁定，未修改')
        if nic and config.get('template'):
            raise RuntimeError('不管理虚拟机模板的限速')
        pending = self.get(path + '/pending')
        if nic:
            if nic not in config or nic not in current:
                raise RuntimeError('网卡不存在或等待删除，未修改')
            for item in pending:
                if 'pending' in item or item.get('delete'):
                    raise RuntimeError('虚拟机有待生效变更（' + str(item.get('key', '?')) + '），请先在 PVE 中处理')
            if not same_net(config[nic], current[nic]):
                raise RuntimeError('网卡有待生效变更，未修改')
        return config

    def nics(self, vmid):
        c = self.snapshot(vmid)
        return [{'nic': k, 'config': v} for k, v in sorted(c.items()) if re.fullmatch(r'net\d+', k)]

    def apply(self, vmid, nic, rate, dry=False):
        before = self.snapshot(vmid, nic)
        old = before[nic]
        new = new_net(old, rate)
        result = {'before': old, 'after': new, 'changed': not same_net(old, new)}
        if dry or not result['changed']:
            return result
        backup = self.state / 'backups' / f'{time.time_ns()}-{vmid}-{nic}.json'
        prune_files(backup.parent,keep=99,reserve=8192)
        atomic_json(backup, {'time': datetime.now().isoformat(), 'vmid': vmid, 'nic': nic,
                             'before': old, 'after': new, 'digest': before['digest']})
        self.run(['/usr/sbin/qm', 'set', str(vmid), '--digest', before['digest'], '--' + nic, new])
        after = self.snapshot(vmid, nic)
        if not same_net(after[nic], new):
            raise RuntimeError('写后校验失败，请检查 PVE 当前及待生效配置')
        for k in before.keys() | after.keys():
            if re.fullmatch(r'net\d+', k) and k != nic and before.get(k) != after.get(k):
                raise RuntimeError('另一网卡被并发修改，请检查 PVE 配置')
        LOG.info('VM %s %s: %s -> %s backup=%s', vmid, nic, old, new, backup)
        return result


class DemoPVE(PVE):
    def __init__(self, state):
        self.node, self.state = 'pve-demo', state
        self.configs = {100: {'net0': 'virtio=BC:24:11:00:00:01,bridge=vmbr0',
                              'net1': 'virtio=BC:24:11:D6:63:7D,bridge=vmbr1,rate=5'},
                        101: {'net0': 'virtio=BC:24:11:00:00:02,bridge=vmbr0'}}

    def inventory(self):
        return [{'vmid': k, 'name': n, 'status': 'running'} for k, n in ((100, '主路由'), (101, '下载服务'))]

    def snapshot(self, vmid, nic=None):
        c = copy.deepcopy(self.configs[int(vmid)])
        c['digest'] = 'demo'
        if nic and nic not in c:
            raise ValueError('网卡不存在')
        return c

    def apply(self, vmid, nic, rate, dry=False):
        old = self.snapshot(vmid, nic)[nic]
        new = new_net(old, rate)
        if not dry:
            self.configs[int(vmid)][nic] = new
        return {'before': old, 'after': new, 'changed': not same_net(old, new)}


class Manager:
    def __init__(self, state, demo=False):
        self.state = state
        self.lock = threading.RLock()
        self.backend = DemoPVE(state) if demo else PVE(state)
        self.demo = demo
        self.config = {'revision': 0, 'enabled': True, 'rules': []}
        if (state / 'rules.json').exists():
            self.config = json.loads((state / 'rules.json').read_text(encoding='utf-8'))
            self.config['rules'] = [validate_rule(r) for r in self.config['rules']]
        self.runtime = {}
        self.events = []
        self.last_tick = None
        self.wake = threading.Event()
        self.shaper=DemoShaper() if demo else Shaper()
        self.controller=Controller()
        self.traffic=TrafficStore(state/'traffic.sqlite3')
        self.traffic.flush()
        self.last_errors={}

    def save(self):
        self.config['revision'] += 1
        atomic_json(self.state / 'rules.json', self.config)

    def check_revision(self, body):
        if body.get('revision') != self.config['revision']:
            raise ValueError('页面版本已过期，请刷新后重试，未覆盖其它修改')

    def event(self, text, error=False):
        if error:
            now=time.monotonic()
            if now-self.last_errors.get(text,-100000)<900:return
            self.last_errors[text]=now
            if len(self.last_errors)>256:self.last_errors={text:now}
        self.events.insert(0, {'time': datetime.now().isoformat(timespec='seconds'), 'text': text, 'error': error})
        self.events = self.events[:100]
        (LOG.error if error else LOG.info)(text)

    def put(self, body):
        with self.lock:
            self.check_revision(body)
            r = validate_rule(body['rule'])
            existing = next((x for x in self.config['rules'] if x['id'] == r['id']), None)
            if existing and (existing['vmid'], existing['nic']) != (r['vmid'], r['nic']):
                raise ValueError('编辑时不能更换目标，请删除后新建')
            if any(x['id'] != r['id'] and (x['vmid'], x['nic']) == (r['vmid'], r['nic']) for x in self.config['rules']):
                raise ValueError('同一虚拟机网卡只能有一条规则，避免相互覆盖')
            if len(self.config['rules']) >= 128 and not existing:
                raise ValueError('单节点最多 128 条规则')
            # Fail before saving if the local VM/NIC cannot be read safely.
            config=self.backend.snapshot(r['vmid'], r['nic'])
            mac=nic_mac(config[r['nic']])
            if existing and existing.get('mac') and existing['mac']!=mac:
                raise ValueError('网卡 MAC 已变化，请删除旧规则后重新添加')
            r['mac']=mac
            if existing and existing.get('mode')=='adaptive' and r['mode']!='adaptive':self.shaper.release(existing)
            previous = copy.deepcopy(self.config)
            self.config['rules'] = [x for x in self.config['rules'] if x['id'] != r['id']] + [r]
            try:
                self.save()
            except Exception:
                self.config = previous
                raise
            self.runtime.pop(r['id'], None)
            self.event(f'保存规则：{r["name"]}')
            self.wake.set()
            return r

    def delete(self, body):
        with self.lock:
            self.check_revision(body)
            r = next((x for x in self.config['rules'] if x['id'] == body.get('id')), None)
            if not r:
                raise ValueError('规则不存在')
            # Deletion is allowed only after unlimited was verified.
            if r.get('mode')=='adaptive':self.shaper.release(r)
            self.backend.apply(r['vmid'], r['nic'], None)
            previous = copy.deepcopy(self.config)
            self.config['rules'] = [x for x in self.config['rules'] if x['id'] != r['id']]
            try:
                self.save()
            except Exception:
                self.config = previous
                raise
            self.runtime.pop(r['id'], None)
            self.event(f'已解除限速并删除规则：{r["name"]}')
            for key in list(self.controller.data):
                if key.startswith(r['id']+':'):self.controller.data.pop(key,None)

    def toggle(self, body):
        with self.lock:
            self.check_revision(body)
            if type(body.get('enabled')) is not bool:
                raise ValueError('启用状态无效')
            previous = copy.deepcopy(self.config)
            self.config['enabled'] = body['enabled']
            try:
                self.save()
            except Exception:
                self.config = previous
                raise
            self.runtime.clear()
            self.event('自动调度已开启' if body['enabled'] else '自动调度已暂停，正在解除所管理网卡的限速')
            self.wake.set()

    def tick(self, now=None):
        now = now or datetime.now()
        with self.lock:
            self.last_tick = now.isoformat(timespec='seconds')
            for r in self.config['rules']:
                if r.get('mode')=='adaptive':
                    self.tick_adaptive(r,now)
                    continue
                active = self.config['enabled'] and limited(r, now)
                target = r['rate'] if active else None
                last = self.runtime.get(r['id'], {})
                # Recheck actual configuration every minute, immediately at boundaries.
                if last.get('target') == target and time.monotonic() - last.get('monotonic', 0) < 60:
                    continue
                info = {'target': target, 'monotonic': time.monotonic(), 'checked': now.isoformat(timespec='seconds')}
                try:
                    result = self.backend.apply(r['vmid'], r['nic'], target)
                    info.update({'ok': True, 'current': result['after']})
                    if result['changed'] or not last or not last.get('ok'):
                        self.event(f'{r["name"]}：' + (f'已限速 {target} MB/s' if active else '已解除限速'))
                except Exception as e:
                    info.update({'ok': False, 'error': str(e)[:1000]})
                    self.event(f'{r["name"]}：{e}', True)
                self.runtime[r['id']] = info

    def tick_adaptive(self,r,now):
        key=r['id'];last=self.runtime.get(key,{})
        p=phase(now);active=self.config['enabled'] and r['enabled'] and p in ('off_am','off_pm')
        target=None;reason='高峰期上行完全放开' if p in ('lunch','evening') else '规则或自动调度已关闭'
        info={'target':None,'monotonic':time.monotonic(),'checked':now.isoformat(timespec='seconds'),'phase':p,'mode':'adaptive'}
        try:
            # Own runtime filters can always be released, even if the VM has stopped.
            if not active:self.shaper.release(r)
            if not last or last.get('phase')!=p or time.monotonic()-last.get('native_checked',0)>=30:
                config=self.backend.snapshot(r['vmid'],r['nic'])
                if r.get('mac') and nic_mac(config[r['nic']])!=r['mac']:
                    self.shaper.release(r)
                    raise RuntimeError('MAC 已改变，已解除本程序流控并停止调整')
                result=self.backend.apply(r['vmid'],r['nic'],None)
                info['native_checked']=time.monotonic();info['current']=result['after']
            else:
                info['native_checked']=last['native_checked'];info['current']=last.get('current','')
            if active:
                limits=r['ranges'][p]
                target,reason=self.controller.choose(key+':'+p,limits['min'],limits['max'],self.traffic.speeds.get(key),self.shaper.backlog(r))
                if target!=last.get('target') or time.monotonic()-last.get('shaped_checked',0)>=30:
                    self.shaper.apply(r,target)
                    info['shaped_checked']=time.monotonic()
                else:info['shaped_checked']=last.get('shaped_checked',0)
            info.update(ok=True,target=target,reason=reason)
            if target!=last.get('target') or not last or not last.get('ok'):
                self.event(r['name']+'：'+reason+(f'，当前上限 {target} MB/s' if target is not None else ''))
        except Exception as e:
            info.update(ok=False,error=str(e)[:1000],target=last.get('target'))
            self.event(r['name']+'：'+str(e),True)
        self.runtime[key]=info

    def sample_traffic(self):
        with self.lock:rules=copy.deepcopy(self.config['rules'])
        for r in rules:
            try:
                identity,counter=self.shaper.sample(r)
                self.traffic.sample(r,identity,counter)
            except Exception as e:self.traffic.missing(r,str(e))
        # Retention also runs with no rules, including after long downtime.
        if time.monotonic()-self.traffic.last_flush>=60:self.traffic.flush()

    def traffic_loop(self):
        while True:
            try:self.sample_traffic()
            except Exception as e:self.event('流量采集：'+str(e),True)
            time.sleep(5)

    def loop(self):
        while True:
            try:
                self.tick()
            except Exception:
                LOG.exception('调度循环异常')
            self.wake.wait(5)
            self.wake.clear()

    def status(self):
        with self.lock:
            now = datetime.now()
            return {**copy.deepcopy(self.config), 'version': VERSION, 'direction': 'per-rule',
                    'runtime': copy.deepcopy(self.runtime),
                    'events': self.events[:40], 'node': self.backend.node, 'demo': self.demo,
                    'time': now.isoformat(timespec='seconds'), 'zone': time.tzname,
                    'service': 'online', 'last_tick': self.last_tick,
                    'traffic':self.traffic.report(),
                    'next': {r['id']: next_change(r, now) if self.config['enabled'] else None for r in self.config['rules']}}


class AppServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    """Private Linux Unix socket. Only uid 0 (PVE protected API) may connect."""
    address_family = getattr(socket, 'AF_UNIX', 1)
    daemon_threads = True

    def get_request(self):
        sock, addr = self.socket.accept()
        sock.settimeout(120)
        return sock, addr

    def verify_request(self, request, client_address):
        try:
            _, uid, _ = struct.unpack('3i', request.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12))
            return uid == 0 and self.slots.acquire(blocking=False)
        except Exception:
            return False

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.slots.release()


class Handler(BaseHTTPRequestHandler):
    # Never exposed over TCP. PVE performs ticket/CSRF/root checks before forwarding.
    server_version = 'PVERateManager/3.0.0'

    def log_message(self, fmt, *args):
        pass # Routine five-second polling is deliberately not logged.

    def send(self, code, data):
        raw = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(raw)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        try:
            path = urlsplit(self.path).path
            if path == '/api/status':
                return self.send(200, self.server.manager.status())
            if path == '/api/stats':return self.send(200,self.server.manager.traffic.report())
            if path == '/api/vms':
                return self.send(200, self.server.manager.backend.inventory())
            if path == '/api/nics':
                vmid = parse_qs(urlsplit(self.path).query).get('vmid', [''])[0]
                if not re.fullmatch(r'[0-9]{3,9}', vmid):
                    raise ValueError('VM ID 无效')
                return self.send(200, self.server.manager.backend.nics(int(vmid)))
            self.send(404, {'error': '接口不存在'})
        except Exception as e:
            self.send(400, {'error': str(e)[:1000]})

    def do_POST(self):
        try:
            if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
                return self.send(415, {'error': '需要 JSON 请求'})
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 32768:
                return self.send(413, {'error': '请求大小无效'})
            body = json.loads(self.rfile.read(length))
            if not isinstance(body, dict):
                raise ValueError('请求格式无效')
            path = urlsplit(self.path).path
            m = self.server.manager
            if path == '/api/rule':
                return self.send(200, m.put(body))
            if path == '/api/delete':
                m.delete(body)
            elif path == '/api/toggle':
                m.toggle(body)
            elif path == '/api/preview':
                r = validate_rule(body['rule'])
                now = datetime.now()
                active = m.config['enabled'] and limited(r, now)
                if r.get('mode')=='adaptive':
                    old=m.backend.snapshot(r['vmid'],r['nic'])[r['nic']]
                    return self.send(200,{'before':old,'after':new_net(old,None),'limited':active,
                        'next':next_change(r,now),'mode':'adaptive','phase':phase(now),
                        'range':r['ranges'].get(phase(now)),'note':'只预览：高峰放开上行；非高峰范围内自适应；下行不设本程序上限。保存后会解除 PVE 原有双向 rate。'})
                return self.send(200, {**m.backend.apply(r['vmid'], r['nic'], r['rate'] if active else None, True),
                                       'limited': active, 'next': next_change(r, now)})
            else:
                return self.send(404, {'error': '接口不存在'})
            self.send(200, {'ok': True})
        except (ValueError, KeyError, TypeError) as e:
            self.send(400, {'error': str(e)[:1000]})
        except Exception as e:
            LOG.exception('请求执行失败')
            self.send(503, {'error': str(e)[:1000]})


def serve(args):
    if os.geteuid() != 0:
        raise RuntimeError('必须以 root 在 PVE 节点运行')
    import fcntl
    lock = open('/run/pve-rate-manager.lock', 'a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    m = Manager(args.state, args.demo)
    location = Path('/run/pve-rate-manager/api.sock')
    location.parent.mkdir(mode=0o700, exist_ok=True)
    os.chmod(location.parent, 0o700)
    if location.exists():
        location.unlink()  # process lock proves this is our stale socket
    server = AppServer(str(location), Handler)
    os.chmod(location, 0o600)
    server.slots = threading.BoundedSemaphore(24)
    server.manager = m
    threading.Thread(target=m.loop, daemon=True).start()
    threading.Thread(target=m.traffic_loop, daemon=True).start()
    LOG.info('Started private socket; node=%s', m.backend.node)
    try:
        server.serve_forever()
    finally:
        server.server_close()
        location.unlink(missing_ok=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=['serve', 'release-all','cleanup'])
    p.add_argument('--state', type=Path, default=Path('/var/lib/pve-rate-manager'))
    p.add_argument('--demo', action='store_true')
    args = p.parse_args()
    os.umask(0o077)
    logdir=Path('/var/log/pve-rate-manager') if not args.demo else args.state/'logs'
    logdir.mkdir(parents=True,exist_ok=True,mode=0o700)
    handler=RotatingFileHandler(logdir/'manager.log',maxBytes=5*1024*1024,backupCount=4,encoding='utf-8')
    handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
    logging.basicConfig(level=logging.INFO,handlers=[handler])
    if args.command in ('release-all','cleanup'):
        if not args.demo and os.geteuid() != 0:
            raise RuntimeError('请以 root 执行')
        # Caller must stop service first. Use the same lock to enforce that.
        if not args.demo:
            import fcntl
            lock = open('/run/pve-rate-manager.lock', 'a')
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        m = Manager(args.state, args.demo)
        failures = []
        for r in m.config['rules']:
            try:
                if r.get('mode')=='adaptive':m.shaper.release(r)
                if args.command=='release-all':m.backend.apply(r['vmid'], r['nic'], None)
            except Exception as e:
                failures.append(f'{r["name"]}: {e}')
        if failures:
            raise RuntimeError('\n'.join(failures))
        m.traffic.close()
        print('所有规则对应网卡均已解除限速' if args.command=='release-all' else '本程序的上行流控已清理')
    else:
        serve(args)


if __name__ == '__main__':
    main()
