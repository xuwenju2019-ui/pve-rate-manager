"""Per-rule circular daily peak windows, host-local wall clock."""
from datetime import datetime,timedelta
import copy
import re

DEFAULT={'preset':'default','lunch':{'start':'11:30','end':'14:00'},'evening':{'start':'17:00','end':'00:00'}}


def minutes(value):
    if not isinstance(value,str) or not re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d',value):
        raise ValueError('高峰时间必须为 HH:MM')
    h,m=map(int,value.split(':'));return h*60+m


def validate(value=None):
    if value is None:return copy.deepcopy(DEFAULT)
    if not isinstance(value,dict):raise ValueError('高峰策略格式无效')
    result={'preset':'custom'}
    for key in ('lunch','evening'):
        part=value.get(key)
        if not isinstance(part,dict):raise ValueError('请填写两个高峰时段')
        result[key]={k:part.get(k) for k in ('start','end')}
        for v in result[key].values():minutes(v)
    a,b,c,d=[minutes(result[k][v]) for k,v in [('lunch','start'),('lunch','end'),('evening','start'),('evening','end')]]
    offsets=[(t-a)%1440 for t in (b,c,d)]
    if not 0<offsets[0]<offsets[1]<offsets[2]<1440:
        raise ValueError('两个高峰不能重叠或首尾相接，请分别保留非高峰时段')
    if all(result[k]==DEFAULT[k] for k in ('lunch','evening')):result['preset']='default'
    return result


def phase(now,rule=None):
    s=(rule or {}).get('schedule') or DEFAULT
    m=now.hour*60+now.minute
    a=minutes(s['lunch']['start']);x=(m-a)%1440
    b,c,d=[(minutes(s[k][v])-a)%1440 for k,v in [('lunch','end'),('evening','start'),('evening','end')]]
    if x<b:return 'lunch'
    if x<c:return 'off_pm'
    if x<d:return 'evening'
    return 'off_am'


def next_boundary(now,rule=None):
    s=(rule or {}).get('schedule') or DEFAULT
    times=[minutes(s[k][v]) for k in ('lunch','evening') for v in ('start','end')]
    for offset in (0,1):
        day=now+timedelta(days=offset)
        for m in sorted(times):
            point=day.replace(hour=m//60,minute=m%60,second=0,microsecond=0)
            if point>now:return point.isoformat(timespec='minutes')
