"""Best-effort, bounded cleanup independent of Manager/SQLite/GeoDB startup."""
from concurrent.futures import ThreadPoolExecutor,as_completed
from datetime import datetime
import json,subprocess,time
from pathlib import Path
from adaptive import Shaper
from manager import PVE,validate_rule,atomic_json

def cleanup(state=Path('/var/lib/pve-rate-manager')):
    report={'time':datetime.now().isoformat(timespec='seconds'),'ok':False,'pending':True,'errors':[]}
    file=state/'cleanup-status.json';atomic_json(file,report)
    rulesfile=state/'rules.json'
    if not rulesfile.exists():rules=[]
    else:
        if rulesfile.stat().st_size>1024*1024:raise ValueError('规则文件大小异常')
        rules=json.loads(rulesfile.read_text(encoding='utf-8'))['rules']
        if len(rules)>128:raise ValueError('规则数量异常')
        rules=[validate_rule(r) for r in rules]
    deadline=time.monotonic()+60
    def release(r):
        def run(args):
            remaining=deadline-time.monotonic()
            if remaining<=0:raise RuntimeError('清理预算到期，请手动检查该网卡')
            p=subprocess.run(args,capture_output=True,text=True,timeout=min(5,remaining))
            if p.returncode:raise RuntimeError((p.stderr or '清理命令失败')[:300])
            return p.stdout
        errors=[]
        if r.get('mode')=='adaptive':
            try:Shaper(run).release(r)
            except Exception as e:errors.append('上行流控：'+str(e))
        try:
            backend=PVE(state);backend.run=run
            config=backend.snapshot(r['vmid'],r['nic'])
            from adaptive import nic_mac
            if r.get('mac') and nic_mac(config[r['nic']])!=r['mac']:raise ValueError('MAC变化，未修改PVE配置')
            backend.apply(r['vmid'],r['nic'],None,before=config)
        except Exception as e:errors.append('PVE rate：'+str(e))
        return [str(r['vmid'])+'/'+r['nic']+': '+e for e in errors]
    with ThreadPoolExecutor(max_workers=2) as pool:
        for future in as_completed([pool.submit(release,r) for r in rules]):
            try:report['errors'].extend(future.result())
            except Exception as e:report['errors'].append(str(e)[:400])
            atomic_json(file,report)
    report.update(pending=False,ok=not report['errors']);atomic_json(file,report)
    if report['errors']:raise RuntimeError('部分限速未能核验解除，查看控制台停止结果')
    return report
if __name__=='__main__':cleanup()
