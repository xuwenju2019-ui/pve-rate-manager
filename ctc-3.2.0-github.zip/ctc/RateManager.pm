package PVE::API2::RateManager;

use strict;
use warnings;
use IO::Socket::UNIX;
use Socket qw(SOCK_STREAM);
use HTTP::Request;
use HTTP::Response;
use JSON;
use Encode qw(decode);
use PVE::RPCEnvironment;
use PVE::Tools qw(run_command);
use PVE::Exception qw(raise_perm_exc);
use base qw(PVE::RESTHandler);

sub decode_payload {
    my ($payload) = @_;
    # PVE has already decoded the outer JSON request into Perl characters.
    my $body = JSON->new->utf8(0)->decode($payload);
    die "Expected JSON object\n" if ref($body) ne 'HASH';
    return $body;
}

sub forward {
    my ($method, $endpoint, $param) = @_;
    my $user = PVE::RPCEnvironment->get()->get_user();
    # Defense in depth: no token, role mapping, or UI visibility can bypass this.
    raise_perm_exc('Only root@pam may manage persistent rate schedules')
        if !defined($user) || $user ne 'root@pam';

    if ($endpoint eq 'program-status' || $endpoint eq 'program-start' || $endpoint eq 'program-stop') {
        my $action = $endpoint eq 'program-status' ? 'status' : $endpoint eq 'program-start' ? 'start' : 'stop';
        my $output = '';
        run_command(['/usr/bin/python3', '/opt/pve-rate-manager/program_control.py', $action],
            timeout => 15, outfunc => sub { $output .= $_[0] . "\n"; });
        decode_json($output); # validate helper output
        return decode('UTF-8', $output);
    }
    my $path = '/api/' . $endpoint;
    $path .= '?vmid=' . int($param->{vmid}) if $endpoint eq 'nics';
    my $request = HTTP::Request->new($method, $path);
    $request->protocol('HTTP/1.0');
    $request->header('Host' => 'localhost', 'Connection' => 'close');
    if ($method eq 'POST') {
        my $payload = $param->{payload};
        die "Payload too large\n" if length($payload) > 32768;
        my $body = decode_payload($payload);
        $request->header('Content-Type' => 'application/json');
        $request->content(encode_json($body));
    }
    my $reply;
    eval {
        local $SIG{ALRM} = sub { die "Rate manager request timeout\n"; };
        alarm(120);
        my $sock = IO::Socket::UNIX->new(
            Type => SOCK_STREAM,
            Peer => '/run/pve-rate-manager/api.sock',
        ) or die "Rate manager is stopped; check ctc.service\n";
        $sock->autoflush(1);
        my $wire = $request->as_string("\r\n");
        # Ensure Content-Length is present for the private HTTP handler.
        if ($method eq 'POST') {
            $request->header('Content-Length' => length($request->content));
            $wire = $request->as_string("\r\n");
        }
        print {$sock} $wire or die "Could not send rate request\n";
        shutdown($sock, 1);
        $reply = '';
        while (1) {
            my $n = sysread($sock, my $buffer, 16384);
            die "Could not read rate response\n" if !defined($n);
            last if !$n;
            $reply .= $buffer;
            die "Rate response too large\n" if length($reply) > 2 * 1024 * 1024;
        }
        close($sock);
        alarm(0);
    };
    my $err = $@;
    alarm(0);
    die $err if $err;
    my $response = HTTP::Response->parse($reply);
    my $data = decode_json($response->content);
    die (($data->{error} // 'Rate manager failed') . "\n") if !$response->is_success;
    # Return JSON as a string to keep one schema for status, arrays and previews.
    return decode('UTF-8', $response->content);
}

for my $endpoint (qw(program-status program-start program-stop status stats vms nics rule delete toggle preview history capture-status capture-start capture-cancel capture-report geo-status geo-begin geo-chunk geo-commit geo-lookup)) {
    my $name = $endpoint;
    my $method = $name =~ /^(program-status|status|stats|vms|nics|capture-status|geo-status)$/ ? 'GET' : 'POST';
    my $properties = {};
    if ($name eq 'nics') {
        $properties->{vmid} = { type => 'integer', minimum => 100, maximum => 999999999 };
    } elsif ($method eq 'POST') {
        $properties->{payload} = { type => 'string', maxLength => 32768,
            description => 'JSON schedule request.' };
    }
    __PACKAGE__->register_method({
        name => $name,
        path => $name,
        method => $method,
        protected => 1,
        allowtoken => 0,
        permissions => {}, # PVE default: root@pam only
        description => 'Manage local node network rate schedules (root only).',
        parameters => { additionalProperties => 0, properties => $properties },
        returns => { type => 'string', description => 'JSON response from local scheduler.' },
        code => sub { return forward($method, $name, $_[0]); },
    });
}

1;
