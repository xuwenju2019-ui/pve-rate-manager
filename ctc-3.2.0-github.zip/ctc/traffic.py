"""Daily upload accounting, seven local calendar days; raw bytes never packets."""
from datetime import datetime,timedelta
from pathlib import Path
import json
import sqlite3
import threading
import time
from schedule import phase,DEFAULT,minutes


def split_interval(start,end,total,rule=None):
    if end<=start:return []
    schedule=(rule or {}).get("schedule") or DEFAULT
    boundaries={0,*[minutes(schedule[k][v]) for k in ("lunch","evening") for v in ("start","end")]}
    points=[start,end]
    day=datetime.fromtimestamp(start).date()
    while day<=datetime.fromtimestamp(end).date():
        for minute in boundaries:
            h,m=divmod(minute,60)
            t=datetime.combine(day,datetime.min.time()).replace(hour=h,minute=m).timestamp()
            if start<t<end:points.append(t)
        day+=timedelta(days=1)
    points=sorted(set(points));out=[];left=total
    for index,(a,b) in enumerate(zip(points,points[1:])):
        count=left if index==len(points)-2 else int(total*(b-a)/(end-start))
        left-=count;now=datetime.fromtimestamp((a+b)/2)
        out.append((now.date().isoformat(),phase(now,rule),count,b-a))
    return out


class TrafficStore:
    def __init__(self,path):
        self.lock=threading.RLock();self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
        self.db=sqlite3.connect(str(path),check_same_thread=False)
        self.db.execute('PRAGMA journal_mode=DELETE')
        self.db.execute('PRAGMA max_page_count=8192') # normally 32 MiB at 4096-byte pages
        self.db.execute('CREATE TABLE IF NOT EXISTS daily(day TEXT, key TEXT, vmid INTEGER, nic TEXT, name TEXT, total INTEGER, lunch INTEGER, evening INTEGER, offpeak INTEGER, seconds REAL, gaps INTEGER, PRIMARY KEY(day,key))')
        self.db.execute('CREATE TABLE IF NOT EXISTS baseline(key TEXT PRIMARY KEY, identity TEXT, counter INTEGER, stamp REAL)')
        columns={r[1] for r in self.db.execute('PRAGMA table_info(daily)')}
        for name,kind in [('download','INTEGER DEFAULT 0'),('download_seconds','REAL DEFAULT 0')]:
            if name not in columns:self.db.execute(f'ALTER TABLE daily ADD COLUMN {name} {kind}')
        if 'down_counter' not in {r[1] for r in self.db.execute('PRAGMA table_info(baseline)')}:
            self.db.execute('ALTER TABLE baseline ADD COLUMN down_counter INTEGER')
        self.db.execute('CREATE TABLE IF NOT EXISTS curve(day TEXT,key TEXT,bucket INTEGER,up INTEGER,down INTEGER,seconds REAL,down_seconds REAL,PRIMARY KEY(key,bucket))')
        self.db.commit();self.pending={};self.curves={};self.baselines={row[0]:row[1:] for row in self.db.execute('SELECT key,identity,counter,stamp,down_counter FROM baseline')}
        self.speeds={};self.download_speeds={};self.unavailable={};self.error=None;self.last_flush=time.monotonic()

    def row(self,day,r):
        key=(day,r['id'])
        if key not in self.pending:
            old=self.db.execute('SELECT * FROM daily WHERE day=? AND key=?',key).fetchone()
            self.pending[key]=list(old) if old else [day,r['id'],r['vmid'],r['nic'],r['name'],0,0,0,0,0.,0,0,0.]
        self.pending[key][4]=r['name']
        return self.pending[key]

    def sample(self,r,identity,counter,stamp=None,download=None):
        stamp=time.time() if stamp is None else stamp
        with self.lock:
            key=r['id'];old=self.baselines.get(key);today=datetime.fromtimestamp(stamp).date().isoformat()
            self.unavailable.pop(key,None)
            self.row(today,r)
            if old:
                oldid,previous,start,previous_down=old;duration=stamp-start
                if oldid==identity and counter>=previous and 0<duration<=86400*7:
                    count=counter-previous;self.speeds[key]=count/duration/1024/1024
                    down=(download-previous_down) if download is not None and previous_down is not None and download>=previous_down else None
                    if down is not None:self.download_speeds[key]=down/duration/1024**2
                    else:self.download_speeds.pop(key,None)
                    for day,p,n,seconds in split_interval(start,stamp,count,r):
                        row=self.row(day,r);row[5]+=n;row[6 if p=='lunch' else 7 if p=='evening' else 8]+=n;row[9]+=seconds
                        if duration>20:row[10]+=1
                    if down is not None:
                        for day,p,n,seconds in split_interval(start,stamp,down,r):
                            row=self.row(day,r);row[11]+=n;row[12]+=seconds
                    self.add_curve(r,start,stamp,count,down)
                else:self.row(today,r)[10]+=1;self.speeds.pop(key,None);self.download_speeds.pop(key,None)
            else:self.row(today,r)[10]+=1
            self.baselines[key]=(identity,counter,stamp,download)
            if time.monotonic()-self.last_flush>=60:self.flush()

    def invalidate(self,r,reason):
        with self.lock:
            self.baselines.pop(r['id'],None)
            self.db.execute('DELETE FROM baseline WHERE key=?',(r['id'],));self.db.commit()
            self.missing(r,reason)

    def missing(self,r,reason='网卡不可用'):
        with self.lock:
            self.speeds.pop(r['id'],None);self.download_speeds.pop(r['id'],None)
            self.unavailable[r['id']]=str(reason)[:300]
            if len(self.unavailable)>128:self.unavailable={r['id']:str(reason)[:300]}

    def flush(self,today=None):
        with self.lock:
            cutoff=((today or datetime.now().date())-timedelta(days=6)).isoformat()
            try:
                with self.db:
                    self.db.execute('DELETE FROM daily WHERE day<?',(cutoff,))
                    self.db.execute('DELETE FROM curve WHERE day<?',(cutoff,))
                    for row in self.pending.values():
                        if row[0]>=cutoff:self.db.execute('INSERT OR REPLACE INTO daily VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',row)
                    for row in self.curves.values():
                        if row[0]>=cutoff:self.db.execute('INSERT OR REPLACE INTO curve VALUES(?,?,?,?,?,?,?)',row)
                    for key,values in self.baselines.items():
                        self.db.execute('INSERT OR REPLACE INTO baseline(key,identity,counter,stamp,down_counter) VALUES(?,?,?,?,?)',(key,*values))
                    self.db.execute('DELETE FROM baseline WHERE key NOT IN (SELECT DISTINCT key FROM daily)')
                self.pending={k:v for k,v in self.pending.items() if k[0]>=cutoff}
                self.curves.clear()
                retained={r[0] for r in self.db.execute('SELECT DISTINCT key FROM daily')}
                self.baselines={k:v for k,v in self.baselines.items() if k in retained}
                self.error=None;self.last_flush=time.monotonic()
            except sqlite3.Error as e:
                self.error='流量统计保存失败：'+str(e)
                # Bound RAM if disk is full; discarded samples are explicitly flagged.
                if len(self.pending)>1024:self.pending.clear()
                if len(self.curves)>100000:self.curves.clear()
                self.last_flush=time.monotonic()

    def report(self,today=None):
        with self.lock:
            day=today or datetime.now().date();cutoff=(day-timedelta(days=6)).isoformat()
            rows={(r[0],r[1]):list(r) for r in self.db.execute('SELECT * FROM daily WHERE day>=? AND day<=? ORDER BY day DESC',(cutoff,day.isoformat()))}
            rows.update({k:v for k,v in self.pending.items() if cutoff<=k[0]<=day.isoformat()})
            keys=['day','key','vmid','nic','name','total','lunch','evening','offpeak','seconds','gaps','download','download_seconds']
            return {'days':7,'unit':'bytes','rows':[dict(zip(keys,v)) for k,v in sorted(rows.items(),reverse=True)],
                    'download_speeds':dict(self.download_speeds),'speeds':dict(self.speeds),'error':self.error,
                    'unavailable':dict(self.unavailable),
                    'definition':'所选虚拟网卡流控前发送的字节；包含协议、重传及可能被流控丢弃的数据，不等同平台有效流量或出口账单'}

    def add_curve(self,r,start,end,up,down):
        points=sorted(set([start,*range((int(start)//900+1)*900,int(end)+1,900),end]));left_up=up;left_down=down or 0
        for i,(a,b) in enumerate(zip(points,points[1:])):
            duration=b-a
            u=left_up if i==len(points)-2 else int(up*duration/(end-start));left_up-=u
            d=left_down if i==len(points)-2 else int((down or 0)*duration/(end-start));left_down-=d
            bucket=int(a)//900*900;key=(r['id'],bucket)
            if key not in self.curves:
                old=self.db.execute('SELECT * FROM curve WHERE key=? AND bucket=?',key).fetchone()
                self.curves[key]=list(old) if old else [datetime.fromtimestamp(a).date().isoformat(),r['id'],bucket,0,0,0.,0.]
            row=self.curves[key];row[3]+=u;row[4]+=d;row[5]+=duration
            if down is not None:row[6]+=duration

    def history(self,day=None,key=None):
        with self.lock:
            today=datetime.now().date();cutoff=(today-timedelta(days=6)).isoformat()
            sql='SELECT * FROM curve WHERE day>=? AND day<=?';args=[cutoff,today.isoformat()]
            if day:sql+=' AND day=?';args.append(day)
            if key:sql+=' AND key=?';args.append(key)
            rows={(r[1],r[2]):list(r) for r in self.db.execute(sql,args)}
            rows.update({k:v for k,v in self.curves.items() if cutoff<=v[0]<=today.isoformat() and (not day or v[0]==day) and (not key or v[1]==key)})
            grouped={}
            for row in rows.values():
                b=grouped.setdefault(row[2],[0,0,0.,0.]);b[0]+=row[3];b[1]+=row[4]
                b[2]+=row[3]/row[5] if row[5] else 0;b[3]+=row[4]/row[6] if row[6] else 0
            return {'interval_seconds':900,'points':[{'time':stamp,'label':datetime.fromtimestamp(stamp).strftime('%m-%d %H:%M'),'up':v[2]/1024**2,'down':v[3]/1024**2,'up_bytes':v[0],'down_bytes':v[1]} for stamp,v in sorted(grouped.items())]}

    def reset_sampling(self):
        """Manual start begins new baselines; never charge stopped intervals as live sampling."""
        with self.lock:
            self.baselines.clear();self.speeds.clear();self.download_speeds.clear()
            with self.db:self.db.execute('DELETE FROM baseline')

    def close(self):
        self.flush();self.db.close()
