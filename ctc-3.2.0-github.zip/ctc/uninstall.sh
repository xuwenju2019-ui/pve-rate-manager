#!/bin/bash
set -euo pipefail
[[ $EUID -eq 0 ]] || { echo '请在 PVE 宿主机以 root 执行。'; exit 1; }

CTC_DIR=/opt/pve-rate-manager
if [[ ! -f "$CTC_DIR/safe_cleanup.py" || ! -f "$CTC_DIR/integration.py" ]]; then
  echo '找不到完整的 CTC 卸载组件，请先检查当前安装。' >&2
  exit 1
fi

systemctl stop ctc.service
systemctl disable ctc.service
exec 9>/run/pve-rate-manager.lock
if ! flock -n 9; then
  echo '流控进程仍在运行，卸载已中止。' >&2
  exit 1
fi

if ! /usr/bin/python3 "$CTC_DIR/safe_cleanup.py"; then
  echo '限速清理未完成，程序文件已保留。请查看 /var/lib/pve-rate-manager/cleanup-status.json 后重试。' >&2
  exit 1
fi

/usr/bin/python3 "$CTC_DIR/integration.py" remove
echo '正在重启 PVE 管理服务，网页连接可能短暂断开。'
systemctl restart pvedaemon.service pveproxy.service
rm -f -- /etc/systemd/system/ctc.service /usr/share/perl5/PVE/API2/RateManager.pm
rm -f -- /usr/share/pve-manager/js/rate-manager/{index.html,pcap-worker.js,app.js,style.css}
systemctl daemon-reload
rm -f -- "$CTC_DIR"/{schedule.py,capture.py,capture_runner.py,pcap_analyze.py,resources.py,program_control.py,safe_cleanup.py,adaptive.py,traffic.py,storage.py,manager.py,integration.py,deployment.py,pve-hook.js,uninstall.sh}
rm -f -- /usr/local/bin/ctc
echo 'CTC 已卸载，所管理的限速已清理。请刷新 PVE 页面。'
echo '规则、统计数据和备份保留在 /var/lib/pve-rate-manager。'
