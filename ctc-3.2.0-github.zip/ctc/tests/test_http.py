"""Private handler tests without sockets. PVE auth needs real-host acceptance."""
from email.message import Message
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from test_manager import m, rule


class HTTPTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.manager=m.Manager(Path(self.tmp.name),True)
        self.addCleanup(self.manager.traffic.close)

    def req(self,path,body=None,headers=None):
        handler=m.Handler.__new__(m.Handler)
        handler.server=SimpleNamespace(manager=self.manager);handler.path=path
        handler.client_address=('local',0);handler.request_version='HTTP/1.1'
        handler.command='POST' if body is not None else 'GET'
        handler.requestline=handler.command+' '+path+' HTTP/1.1'
        raw=json.dumps(body).encode() if body is not None else b''
        handler.rfile=io.BytesIO(raw);handler.wfile=io.BytesIO();handler.headers=Message()
        handler.headers['Content-Length']=str(len(raw))
        for k,v in ({'Content-Type':'application/json',**(headers or {})}).items():handler.headers[k]=v
        if body is None:handler.do_GET()
        else:handler.do_POST()
        head,data=handler.wfile.getvalue().split(b'\r\n\r\n',1)
        return int(head.split()[1]),json.loads(data)

    def test_full_flow(self):
        self.assertEqual(self.req('/api/status')[0],200)
        self.assertEqual(self.req('/api/vms')[0],200)
        self.assertEqual(len(self.req('/api/nics?vmid=100')[1]),2)
        self.assertEqual(self.req('/api/preview',{'rule':rule()})[0],200)
        status,r=self.req('/api/rule',{'revision':0,'rule':rule()});self.assertEqual(status,200)
        self.assertEqual(self.req('/api/rule',{'revision':0,'rule':r})[0],400)
        self.assertEqual(self.req('/api/delete',{'revision':1,'id':r['id']})[0],200)

    def test_old_login_disabled(self):
        self.assertEqual(self.req('/api/login',{'username':'admin','password':'anything'})[0],404)
        self.assertEqual(self.req('/api/logout',{})[0],404)

    def test_adaptive_preview_is_read_only_and_stats_available(self):
        from test_adaptive import adaptive
        before=self.manager.backend.snapshot(100,'net1')['net1']
        status,result=self.req('/api/preview',{'rule':adaptive()})
        self.assertEqual(status,200)
        self.assertEqual(result['mode'],'adaptive')
        self.assertNotIn('rate=',result['after'])
        self.assertEqual(before,self.manager.backend.snapshot(100,'net1')['net1'])
        self.assertEqual(self.req('/api/stats')[1]['days'],7)

    def test_content_type_and_paths(self):
        self.assertEqual(self.req('/api/toggle',{}, {'Content-Type':'text/plain'})[0],415)
        self.assertEqual(self.req('/api/nics?vmid=100%3Bbad')[0],400)
        self.assertEqual(self.req('/../../manager.py')[0],404)

    def test_31_history_and_capture_endpoints(self):
        self.assertEqual(self.req('/api/history',{'day':'2026-11-08','key':''})[0],200)
        self.assertEqual(self.req('/api/history',{'day':'not-a-date'})[0],400)
        self.assertFalse(self.req('/api/geo-status')[1]['available'])
        self.assertEqual(self.req('/api/capture-status')[1]['jobs'],[])
        self.assertEqual(self.req('/api/capture-report',{'id':'../../etc/passwd'})[0],400)


if __name__=='__main__':unittest.main()
