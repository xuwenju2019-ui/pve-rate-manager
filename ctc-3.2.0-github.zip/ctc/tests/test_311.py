"""Regression tests for manual startup, bounded memory work and release priority."""
from datetime import datetime
import json,tempfile,threading,time
from pathlib import Path
import unittest
from unittest.mock import patch
from test_manager import m
from test_adaptive import adaptive
from capture import CaptureService
from pcap_analyze import GeoDB
from adaptive import Shaper
import program_control
import safe_cleanup
from resources import require_memory
ROOT=Path(__file__).resolve().parents[1]

class Stability311(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.manager=m.Manager(Path(self.tmp.name),True)
        self.addCleanup(self.manager.traffic.close)
        self.addCleanup(self.manager.pool.shutdown)
        self.r=self.manager.put({'revision':0,'rule':adaptive()})

    def test_slow_query_does_not_block_stats_status_or_peak_release(self):
        manager=self.manager;manager.tick(datetime(2026,11,8,10))
        entered=threading.Event();unblock=threading.Event();sampled=threading.Event()
        original=manager.backend.snapshot
        def slow(*args):entered.set();unblock.wait(3);return original(*args)
        with patch.object(manager.backend,'snapshot',side_effect=slow):
            worker=threading.Thread(target=lambda:manager.tick(datetime(2026,11,8,14)));worker.start()
            try:
                self.assertTrue(entered.wait(1))
                sampler=threading.Thread(target=lambda:(manager.sample_traffic(),sampled.set()));sampler.start()
                self.assertTrue(sampled.wait(1),'statistics blocked by native PVE query')
                self.assertEqual(manager.status()['version'],'3.2.0')
                manager.release_peaks(datetime(2026,11,8,17))
                self.assertNotIn(self.r['id'],manager.shaper.rates)
            finally:unblock.set();worker.join();sampler.join()

    def test_late_native_reply_cannot_reapply_cap_after_peak_boundary(self):
        clock=[100.0];original=self.manager.backend.snapshot
        def slow(*args):clock[0]=102.;return original(*args)
        with patch.object(m.time,'monotonic',side_effect=lambda:clock[0]),patch.object(self.manager.backend,'snapshot',side_effect=slow):
            self.manager.tick(datetime(2026,11,8,11,29,59))
        self.assertNotIn(self.r['id'],self.manager.shaper.rates)
        self.assertEqual(self.manager.runtime[self.r['id']]['release_state'],'verified')

    def test_native_failure_is_not_reported_as_verified_unlimited(self):
        with patch.object(self.manager.backend,'snapshot',side_effect=RuntimeError('timeout')):
            self.manager.tick(datetime(2026,11,8,17))
        self.manager.release_peaks(datetime(2026,11,8,17))
        self.assertEqual(self.manager.runtime[self.r['id']]['release_state'],'native_pending')
        self.assertFalse(self.manager.runtime[self.r['id']]['ok'])
        self.assertIn(self.r['id'],self.manager.retry)

    def test_foreign_filter_causes_release_warning(self):
        with patch.object(self.manager.shaper,'verify_released',side_effect=RuntimeError('foreign')):
            self.manager.release_peaks(datetime(2026,11,8,17))
        self.assertEqual(self.manager.runtime[self.r['id']]['release_state'],'failed')

    def test_maintenance_has_independent_clock_even_if_sample_flushed(self):
        self.manager.traffic.last_flush=time.monotonic()-61;self.manager.last_maintenance=0
        with patch.object(self.manager.captures,'maintenance') as run:
            self.manager.sample_traffic();self.assertEqual(run.call_count,1)
            self.manager.sample_traffic();self.assertEqual(run.call_count,1)

    def test_geo_cache_is_shared_under_concurrent_lookup_and_reloaded_on_change(self):
        service=CaptureService(Path(self.tmp.name)/'geo',None,True);service.prepare()
        file=service.cache/'geo.csv';file.write_text('network,country,region,isp\n8.8.8.0/24,CN,Sichuan,Telecom\n')
        errors=[]
        def lookup():
            try:service.geo_lookup({'ips':['8.8.8.8']})
            except Exception as e:errors.append(e)
        with patch('capture.GeoDB',wraps=GeoDB) as build:
            threads=[threading.Thread(target=lookup) for _ in range(12)]
            for t in threads:t.start()
            for t in threads:t.join()
            self.assertFalse(errors);self.assertEqual(build.call_count,1)
            file.write_text('network,country,region,isp\n8.8.8.0/24,CN,Shanghai,Telecom\n')
            self.assertEqual(service.geo_lookup({'ips':['8.8.8.8']})['results']['8.8.8.8']['region'],'Shanghai')
            self.assertEqual(build.call_count,2)

    def test_low_available_memory_rejects_new_capture_work(self):
        with patch('resources.available_bytes',return_value=100*1024**2):
            with self.assertRaises(ValueError):require_memory()

    def test_strict_release_verify_does_not_delete_foreign_filters(self):
        shaper=Shaper()
        with patch.object(shaper,'links',side_effect=[{'ifname':'tap100i1'},None]),patch.object(shaper,'filters',return_value=[{'kind':'u32'}]),patch.object(shaper,'tc') as tc:
            with self.assertRaises(RuntimeError):shaper.verify_released(self.r)
            tc.assert_not_called()

    def test_manual_restart_does_not_bill_stopped_interval(self):
        store=self.manager.traffic;r=self.r;now=time.time()
        store.sample(r,'tap',100,now,download=100)
        store.sample(r,'tap',200,now+5,download=200);store.flush()
        store.reset_sampling()
        store.sample(r,'tap',100000,now+3600,download=200000)
        self.assertEqual(store.report()['rows'][0]['total'],100)
        self.assertNotIn(r['id'],store.speeds)

    def test_service_is_manual_and_resource_bounded(self):
        service=(ROOT/'ctc.service').read_text()
        for line in ('Restart=no','MemoryHigh=256M','MemoryMax=512M','MemorySwapMax=128M','OOMPolicy=stop','TasksMax=48','CPUQuota=75%'):self.assertIn(line,service)
        self.assertNotIn('WantedBy=',service)
        install=(ROOT/'install.sh').read_text();self.assertNotIn('enable --now',install)
        self.assertIn('systemctl disable ctc.service',install)
        self.assertIn('program-status',install)

    def test_program_start_only_starts_current_session(self):
        with patch.object(program_control.os,'geteuid',return_value=0,create=True),patch.object(program_control.sys,'argv',['control','start']),patch.object(program_control,'command',return_value='') as cmd,patch.object(program_control,'status',return_value={'active':'activating'}),patch.object(program_control,'save_json'),patch.object(program_control.Path,'mkdir'),patch('builtins.print'):
            program_control.main()
        self.assertEqual(cmd.call_args_list[0].args,('reset-failed',program_control.UNIT))
        self.assertEqual(cmd.call_args_list[1].args,('start','--no-block',program_control.UNIT))
        self.assertFalse(any('enable' in call.args for call in cmd.call_args_list))

    def test_stop_cleanup_verifies_native_and_shaper_without_loading_manager(self):
        state=Path(self.tmp.name)/'stop';state.mkdir()
        (state/'rules.json').write_text(json.dumps({'rules':[self.r]}))
        with patch.object(safe_cleanup,'PVE') as backend,patch.object(safe_cleanup,'Shaper') as shaper:
            backend.return_value.snapshot.return_value={'digest':'ok','net1':'virtio='+self.r['mac']+',bridge=vmbr1,rate=5'}
            result=safe_cleanup.cleanup(state)
            self.assertTrue(result['ok']);self.assertFalse(result['pending'])
            shaper.return_value.release.assert_called_once()
            self.assertIsNone(backend.return_value.apply.call_args.args[2])
        self.assertTrue(json.loads((state/'cleanup-status.json').read_text())['ok'])

    def test_stop_cleanup_cannot_claim_success_if_mac_changed(self):
        state=Path(self.tmp.name)/'stop';state.mkdir()
        (state/'rules.json').write_text(json.dumps({'rules':[self.r]}))
        with patch.object(safe_cleanup,'PVE') as backend,patch.object(safe_cleanup,'Shaper'):
            backend.return_value.snapshot.return_value={'net1':'virtio=00:11:22:33:44:55,bridge=vmbr1'}
            with self.assertRaises(RuntimeError):safe_cleanup.cleanup(state)
            backend.return_value.apply.assert_not_called()
        result=json.loads((state/'cleanup-status.json').read_text())
        self.assertFalse(result['ok']);self.assertFalse(result['pending']);self.assertTrue(result['errors'])

    def test_uninstall_is_installed_and_cleans_before_removing_integration(self):
        command = (ROOT / 'ctc').read_text()
        install = (ROOT / 'install.sh').read_text()
        uninstall = (ROOT / 'uninstall.sh').read_text()
        self.assertIn('exec /bin/bash /opt/pve-rate-manager/uninstall.sh', command)
        self.assertIn('uninstall.sh /opt/pve-rate-manager/uninstall.sh', install)
        self.assertLess(uninstall.index('systemctl stop ctc.service'), uninstall.index('flock -n 9'))
        self.assertLess(uninstall.index('safe_cleanup.py"; then'), uninstall.index('integration.py" remove'))
        self.assertLess(uninstall.index('integration.py" remove'), uninstall.index('rm -f --'))

    def test_program_routes_keep_root_only_and_pve_protected(self):
        perl=(ROOT/'RateManager.pm').read_text()
        self.assertIn("$user ne 'root@pam'",perl);self.assertIn('protected => 1',perl);self.assertIn('allowtoken => 0',perl)
        self.assertIn('program-status program-start program-stop',perl)
        self.assertLess(perl.index("$user ne 'root@pam'"),perl.index("$endpoint eq 'program-status'"))

if __name__=='__main__':unittest.main()
