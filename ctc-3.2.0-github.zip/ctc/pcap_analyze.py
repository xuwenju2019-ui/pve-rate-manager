"""Bounded offline PCAP/PCAPNG uplink parser. Invoked as an unprivileged worker."""
import argparse
from collections import Counter
import csv
import io
import ipaddress
import json
from pathlib import Path
import struct

MAX_FILE=100*1024*1024
MAX_PEERS=10000


def region_name(s):
    s=str(s or '').strip()
    for a,b in [('广西壮族自治区','广西'),('宁夏回族自治区','宁夏'),('新疆维吾尔自治区','新疆'),('内蒙古自治区','内蒙古'),('西藏自治区','西藏'),('香港特别行政区','香港'),('澳门特别行政区','澳门')]:
        s=s.replace(a,b)
    return s.removesuffix('省').removesuffix('市')


def isp_name(s):
    s=str(s or '').strip()
    aliases={'中国电信':'电信','中国联通':'联通','中国移动':'移动','中国广电':'广电','China Telecom':'电信','China Unicom':'联通','China Mobile':'移动'}
    return aliases.get(s,s)


class GeoDB:
    def __init__(self,text=''):
        self.table={4:{},6:{}};self.count=0
        if text:
            reader=csv.DictReader(io.StringIO(text.lstrip('\ufeff')))
            if not {'network','country','region','isp'}<=set(reader.fieldnames or []):
                raise ValueError('CSV 必须包含 network,country,region,isp 四列')
            for row in reader:
                if self.count>=150000:raise ValueError('归属库超过 150000 条网段')
                n=ipaddress.ip_network(row['network'].strip(),strict=False)
                values={k:str(row.get(k) or '').strip() for k in ('country','region','isp')}
                if any(len(v)>80 or ',' in v or '\n' in v for v in values.values()):raise ValueError('归属库字段过长或含有不支持的字符')
                values['country']=values['country'].upper();values['region']=region_name(values['region']);values['isp']=isp_name(values['isp'])
                self.table[n.version].setdefault(n.prefixlen,{})[int(n.network_address)]=values;self.count+=1

    def lookup(self,address):
        ip=ipaddress.ip_address(address)
        if not ip.is_global:return {'country':'','region':'','isp':'','category':'内网 / 保留地址'}
        bits=ip.max_prefixlen;n=int(ip)
        for prefix,rows in sorted(self.table[ip.version].items(),reverse=True):
            network=n>>(bits-prefix)<<(bits-prefix) if prefix else 0
            if network in rows:return {**rows[network],'category':''}
        return {'country':'','region':'','isp':'','category':'未知'}


def records(raw,allow_truncated_tail=False):
    if len(raw)>MAX_FILE:raise ValueError('抓包文件超过 100 MiB')
    if len(raw)<24:raise ValueError('抓包文件不完整')
    formats={b'\xd4\xc3\xb2\xa1':('<',1e6),b'\xa1\xb2\xc3\xd4':('>',1e6),b'\x4d\x3c\xb2\xa1':('<',1e9),b'\xa1\xb2\x3c\x4d':('>',1e9)}
    if raw[:4] in formats:
        endian,resolution=formats[raw[:4]]
        major,minor=struct.unpack_from(endian+'HH',raw,4)
        if (major,minor)!=(2,4):raise ValueError('仅支持 PCAP 2.4')
        link=struct.unpack_from(endian+'I',raw,20)[0]&0xffff;offset=24
        while offset<len(raw):
            if len(raw)-offset<16:
                if allow_truncated_tail:break
                raise ValueError('PCAP 报文头被截断')
            sec,frac,cap,wire=struct.unpack_from(endian+'IIII',raw,offset);offset+=16
            if cap>wire or cap>MAX_FILE:raise ValueError('PCAP 报文长度异常')
            if offset+cap>len(raw):
                if allow_truncated_tail:break
                raise ValueError('PCAP 文件截断')
            yield sec+frac/resolution,raw[offset:offset+cap],wire,link
            offset+=cap
        return
    if raw[:4]!=b'\x0a\x0d\x0d\x0a':raise ValueError('不是受支持的 PCAP / PCAPNG 文件')
    offset=0;endian=None;interfaces=[];seen=set();section=0
    while offset<len(raw):
        if len(raw)-offset<12:raise ValueError('PCAPNG 块被截断')
        if raw[offset:offset+4]==b'\x0a\x0d\x0d\x0a':
            bom=raw[offset+8:offset+12]
            endian='<' if bom==b'\x4d\x3c\x2b\x1a' else '>' if bom==b'\x1a\x2b\x3c\x4d' else None
            if endian is None:raise ValueError('PCAPNG 字节顺序无效')
            interfaces=[];section+=1
        if endian is None:raise ValueError('PCAPNG 缺少 section')
        kind,size=struct.unpack_from(endian+'II',raw,offset)
        if size<12 or size%4 or offset+size>len(raw) or struct.unpack_from(endian+'I',raw,offset+size-4)[0]!=size:
            raise ValueError('PCAPNG 块长度无效')
        block=raw[offset:offset+size]
        if kind==1:
            if size<20:raise ValueError('PCAPNG 接口块不完整')
            link=struct.unpack_from(endian+'H',block,8)[0];resolution=1e-6;at=16
            while at+4<=size-4:
                code,length=struct.unpack_from(endian+'HH',block,at);at+=4
                if at+length>size-4:raise ValueError('PCAPNG 选项长度异常')
                if code==9 and length==1:
                    x=block[at];resolution=(2 if x&128 else 10)**-(x&127)
                if code==14:raise ValueError('暂不支持含 if_tsoffset 的 PCAPNG，请导出标准 PCAP')
                if code==0:break
                at+=(length+3)//4*4
            interfaces.append((link,resolution))
        elif kind==6:
            if size<32:raise ValueError('PCAPNG 数据块不完整')
            interface,hi,lo,cap,wire=struct.unpack_from(endian+'IIIII',block,8)
            if interface>=len(interfaces) or cap>wire or 28+(cap+3)//4*4>size-4:raise ValueError('PCAPNG 报文长度或接口无效')
            seen.add((section,interface))
            if len(seen)>1:raise ValueError('为避免重复计量，请导出单一接口的抓包文件')
            link,resolution=interfaces[interface]
            yield ((hi<<32)+lo)*resolution,block[28:28+cap],wire,link
        elif kind in (2,3):raise ValueError('暂不支持旧式或无时间戳数据块，请导出标准 PCAP')
        offset+=size


def packet(frame,link):
    mac=None
    if link==1:
        if len(frame)<14:raise ValueError('以太网报文头不完整')
        mac=frame[6:12].hex(':').upper();proto=int.from_bytes(frame[12:14],'big');offset=14
        for _ in range(4):
            if proto not in (0x8100,0x88a8,0x9100):break
            if len(frame)<offset+4:raise ValueError('VLAN 报文头不完整')
            proto=int.from_bytes(frame[offset+2:offset+4],'big');offset+=4
    elif link==113:
        if len(frame)<16:raise ValueError('SLL 报文头不完整')
        offset=16;proto=int.from_bytes(frame[14:16],'big')
    elif link==276:
        if len(frame)<20:raise ValueError('SLL2 报文头不完整')
        offset=20;proto=int.from_bytes(frame[:2],'big')
    elif link in (101,228,229):
        offset=0;proto=0x800 if frame and frame[0]>>4==4 else 0x86dd
    else:raise ValueError('不支持的链路封装：'+str(link))
    data=frame[offset:]
    if proto==0x800:
        if len(data)<20 or data[0]>>4!=4 or (data[0]&15)<5:raise ValueError('IPv4 报文头不完整')
        return mac,str(ipaddress.ip_address(data[12:16])),str(ipaddress.ip_address(data[16:20])),data[9]
    if proto==0x86dd:
        if len(data)<40 or data[0]>>4!=6:raise ValueError('IPv6 报文头不完整')
        # Protocol here is the immediate next header; extension headers remain separately labelled.
        return mac,str(ipaddress.ip_address(data[8:24])),str(ipaddress.ip_address(data[24:40])),data[6]
    return None


def summarize(peers,curve,province,isp,geo,total,duration,packets,untracked=0):
    regions=Counter();isps=Counter();protocols=Counter();region_known=isp_known=outside=cross=0;result=[]
    province=region_name(province);isp=isp_name(isp)
    for address,values in peers.items():
        info=geo.lookup(address);count=values['bytes'];country=info.get('country','');region=info.get('region','');operator=info.get('isp','')
        category=info.get('category') or ('境外' if country and country!='CN' else '未知')
        regions[region if country=='CN' and region else category]+=count
        isps[operator if country=='CN' and operator else category]+=count
        if country=='CN' and region:
            region_known+=count
            if region!=province:outside+=count
        if country=='CN' and operator:
            isp_known+=count
            if operator!=isp:cross+=count
        result.append({'ip':address,'bytes':count,**info})
        protocols.update(values.get('protocols',{}))
    if untracked:regions['超出对端上限，未识别']+=untracked;isps['超出对端上限，未识别']+=untracked
    def order(counter):
        entries=counter.most_common()
        return [{'name':k,'bytes':v} for k,v in entries[:63]]+([{'name':'其他','bytes':sum(v for k,v in entries[63:])}] if len(entries)>63 else [])
    if untracked:protocols['超出对端上限，未分类']+=untracked
    return {'bytes':total,'duration':duration,'packets':packets,'province':province,'isp':isp,
            'out_province_percent':outside/region_known*100 if region_known else None,
            'cross_isp_percent':cross/isp_known*100 if isp_known else None,
            'region_coverage':region_known/total*100 if total else 0,'isp_coverage':isp_known/total*100 if total else 0,
            'regions':order(regions),'isps':order(isps),'protocols':dict(protocols),
            'peers':sorted(result,key=lambda x:x['bytes'],reverse=True)[:100],
            'curve':[{'time':t,'up':n/1024**2} for t,n in sorted(curve.items())],
            'warning':('对端超过 10000 个，超出部分按未知计入。' if untracked else '')+('归属库未配置。' if not geo.count else '')}


def analyze(raw,province,isp,geo=None,mac=None,ips=None,uplink_only=False,allow_truncated_tail=False):
    geo=geo or GeoDB();addresses={str(ipaddress.ip_address(x)) for x in (ips or [])}
    if not uplink_only and not mac and not addresses:raise ValueError('必须确认服务器 IP 或目标网卡 MAC，以区分上行方向')
    peers={};curve=Counter();total=packets=untracked=0;first=last=None;skipped=0;truncated=0
    for stamp,frame,wire,link in records(raw,allow_truncated_tail):
        item=packet(frame,link)
        if not item:continue
        source_mac,source,destination,protocol=item
        if not uplink_only and ((mac and source_mac!=mac.upper()) or (not mac and source not in addresses)):continue
        if first is None:first=last=stamp
        first=min(first,stamp);last=max(last,stamp)
        if last-first>300:raise ValueError('仅分析不超过 5 分钟的短时样本，请先裁剪文件')
        total+=wire;packets+=1;curve[int(stamp)]+=wire
        if len(frame)<wire:truncated+=1
        if destination not in peers:
            if len(peers)>=MAX_PEERS:untracked+=wire;continue
            peers[destination]={'bytes':0,'protocols':Counter()}
        peer=peers[destination];peer['bytes']+=wire
        peer['protocols'][{6:'TCP',17:'UDP',1:'ICMP',58:'ICMPv6'}.get(protocol,'其他 / 扩展头')]+=wire
    duration=(last-first+1) if first is not None else 0
    result=summarize(peers,curve,province,isp,geo,total,duration,packets,untracked)
    result['truncated_packets']=truncated
    if not packets:result['warning']+=' 未匹配到指定方向的 IP 报文，请检查服务器地址、网卡或采集时段。'
    return result


def main():
    p=argparse.ArgumentParser();p.add_argument('--uid',type=int);p.add_argument('--gid',type=int);p.add_argument('input');p.add_argument('config');p.add_argument('output');a=p.parse_args()
    if a.uid is not None:
        import os,resource
        if a.uid==0 or a.gid is None:raise ValueError('解析任务必须使用非 root 用户')
        resource.setrlimit(resource.RLIMIT_AS,(384*1024*1024,384*1024*1024));resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_FSIZE,(2*1024*1024,2*1024*1024));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
        os.setgroups([]);os.setgid(a.gid);os.setuid(a.uid)
    cfg=json.loads(Path(a.config).read_text(encoding='utf-8'))
    geo_file=Path(cfg['geo']) if cfg.get('geo') else None
    geo=GeoDB(geo_file.read_text(encoding='utf-8') if geo_file and geo_file.exists() else '')
    result=analyze(Path(a.input).read_bytes(),cfg['province'],cfg['isp'],geo,mac=cfg.get('mac'),ips=cfg.get('ips'),uplink_only=cfg.get('uplink_only',False),allow_truncated_tail=cfg.get('allow_truncated_tail',False))
    Path(a.output).write_text(json.dumps(result,ensure_ascii=False),encoding='utf-8')


if __name__=='__main__':main()
