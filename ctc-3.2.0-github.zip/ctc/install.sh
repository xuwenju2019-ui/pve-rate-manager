#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
[[ $EUID -eq 0 ]] || { echo '请在 PVE 宿主机以 root 执行。'; exit 1; }
[[ -x /usr/bin/pvesh && -x /usr/sbin/qm && -f /usr/share/perl5/PVE/API2.pm && -f /usr/share/pve-manager/index.html.tpl && -f /usr/share/pve-manager/js/pvemanagerlib.js ]] || { echo '未检测到兼容的 PVE 安装，未修改。'; exit 1; }
if [[ -e /usr/share/perl5/PVE/API2/RateManager.pm ]] && ! grep -q 'PVE-RATE-MANAGER-BEGIN-v1' /usr/share/perl5/PVE/API2.pm; then
  echo '发现无安装标记的同名 API 模块，请先检查，未覆盖。'; exit 1
fi
if [[ -L /usr/local/bin/ctc ]] || { [[ -e /usr/local/bin/ctc ]] && ! grep -Fq '# Managed by CDN Traffic Controller (CTC)' /usr/local/bin/ctc; }; then
  echo '发现同名 ctc 命令，安装中止。'; exit 1
fi
if systemctl cat ctc.service >/dev/null 2>&1 && ! grep -Fxq 'Description=CTC - CDN Traffic Controller' /etc/systemd/system/ctc.service 2>/dev/null; then
  echo '发现同名 ctc.service，安装中止。'; exit 1
fi
sha256sum -c MANIFEST.sha256
/usr/bin/python3 -m unittest discover -s tests -p 'test_*.py' -q
/usr/bin/perl tests/test_unicode.pl
/usr/bin/perl -c /usr/share/perl5/PVE/API2.pm
PRM_BACKUP=$(/usr/bin/python3 deployment.py snapshot)
echo "安装/升级至 3.2.0；安装前备份：$PRM_BACKUP"
recover() {
  local rc=$?
  trap - ERR
  echo '安装失败，正在还原本次安装前的程序及 PVE 入口。规则文件保留当前内容。'
  systemctl stop ctc.service 2>/dev/null || true
  systemctl stop pve-rate-manager.service 2>/dev/null || true
  if ! /usr/bin/python3 deployment.py restore "$PRM_BACKUP"; then
    echo "自动还原未完成，请保留错误日志。备份：$PRM_BACKUP"
    exit "$rc"
  fi
  systemctl daemon-reload
  systemctl disable ctc.service 2>/dev/null || true
  systemctl disable pve-rate-manager.service 2>/dev/null || true
  echo "已保持后台停止且禁用开机启动；排查后再手动启动。"
  systemctl restart pvedaemon.service pveproxy.service || true
  echo "已还原程序文件；如有报错请检查服务状态。备份：$PRM_BACKUP"
  exit "$rc"
}
trap recover ERR
if systemctl cat pve-net1-rate.timer >/dev/null 2>&1; then
  systemctl disable --now pve-net1-rate.timer
  systemctl stop pve-net1-rate.service || true
fi
if systemctl cat ctc.service >/dev/null 2>&1; then systemctl stop ctc.service; fi
if systemctl cat pve-rate-manager.service >/dev/null 2>&1; then
  systemctl disable --now pve-rate-manager.service
  rm -f -- /etc/systemd/system/pve-rate-manager.service
fi
install -d -o root -g root -m 0755 /opt/pve-rate-manager /usr/share/pve-manager/js/rate-manager
install -d -o root -g root -m 0700 /var/lib/pve-rate-manager
install -o root -g root -m 0644 manager.py adaptive.py traffic.py storage.py schedule.py capture.py capture_runner.py pcap_analyze.py resources.py program_control.py safe_cleanup.py integration.py deployment.py pve-hook.js /opt/pve-rate-manager/
install -o root -g root -m 0644 web/index.html web/app.js web/style.css web/pcap-worker.js /usr/share/pve-manager/js/rate-manager/
install -o root -g root -m 0644 RateManager.pm /usr/share/perl5/PVE/API2/RateManager.pm
install -o root -g root -m 0700 uninstall.sh /opt/pve-rate-manager/uninstall.sh
install -D -o root -g root -m 0755 ctc /usr/local/bin/ctc
install -o root -g root -m 0644 ctc.service /etc/systemd/system/ctc.service
/usr/bin/python3 /opt/pve-rate-manager/integration.py install
systemctl daemon-reload
systemd-analyze verify /etc/systemd/system/ctc.service
systemctl disable ctc.service 2>/dev/null || true
# Clear prior managed limits without starting the scheduler or resuming saved rules.
/usr/bin/python3 /opt/pve-rate-manager/safe_cleanup.py
if systemctl is-active --quiet ctc.service; then
  echo '后台仍在运行，安装中止。'; false
fi
if systemctl is-enabled --quiet ctc.service 2>/dev/null; then
  echo '未能关闭开机启动，安装中止。'; false
fi
/usr/bin/perl -c /usr/share/perl5/PVE/API2/RateManager.pm
echo '正在重启 PVE 管理服务；管理连接可能短暂断开，虚拟机不会重启。'
systemctl restart pvedaemon.service pveproxy.service
systemctl is-active --quiet pvedaemon.service
systemctl is-active --quiet pveproxy.service
/usr/bin/pvesh get /rate-manager/program-status --output-format json | /usr/bin/python3 -c 'import json,sys; s=json.load(sys.stdin); s=json.loads(s) if isinstance(s,str) else s; assert s["active"]!="active"; assert s["boot"] not in ("enabled","enabled-runtime"); print("手动启动模式校验通过")'
trap - ERR
/usr/bin/python3 -c "from storage import prune_installs; prune_installs('/var/lib/pve-rate-manager/install-backups')"
echo 'CTC · CDN流控程序 3.2 安装完成。用原 PVE 地址登录 root@pam，按 Ctrl+F5，点击蓝色“网卡限速”。'
echo '后台当前关闭，不会开机自动启动。升级保留规则；需要在页面点击“开启程序”后才会恢复执行。'
