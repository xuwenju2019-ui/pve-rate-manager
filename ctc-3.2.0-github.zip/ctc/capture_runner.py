"""Apply capture limits in a fresh interpreter; never use preexec_fn in threaded daemon."""
import os
import resource
import sys

if __name__=='__main__':
    resource.setrlimit(resource.RLIMIT_FSIZE,(100*1024*1024,100*1024*1024))
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    os.execv(sys.argv[1],sys.argv[1:])
