"""Fixed service controls invoked only by protected PVE API, independent of daemon."""
import json,os,subprocess,sys
from datetime import datetime
from capture import save_json
from pathlib import Path
UNIT='ctc.service'

def command(*args):
    result=subprocess.run(['/usr/bin/systemctl',*args],capture_output=True,text=True,timeout=5)
    if result.returncode:raise RuntimeError((result.stderr or '服务控制失败')[:300])
    return result.stdout

def status():
    raw=command('show',UNIT,'--property=ActiveState,SubState,UnitFileState,MemoryCurrent,MemoryPeak,MemoryMax,Result')
    data=dict(line.split('=',1) for line in raw.splitlines() if '=' in line)
    cleanup=None;file=Path('/var/lib/pve-rate-manager/cleanup-status.json')
    if file.exists() and file.stat().st_size<=65536:cleanup=json.loads(file.read_text())
    return {'active':data.get('ActiveState'),'sub':data.get('SubState'),'boot':data.get('UnitFileState'),'result':data.get('Result'),'memory_bytes':data.get('MemoryCurrent'),'peak_bytes':data.get('MemoryPeak'),'limit_bytes':data.get('MemoryMax'),'cleanup':cleanup,'manual_start':True}

def main():
    if os.geteuid()!=0:raise RuntimeError('仅限 PVE root 管理员')
    if len(sys.argv)!=2 or sys.argv[1] not in ('status','start','stop'):raise ValueError('服务操作无效')
    if sys.argv[1] in ('start','stop'):
        folder=Path('/var/lib/pve-rate-manager');folder.mkdir(mode=0o700,exist_ok=True)
        save_json(folder/'cleanup-status.json',{'time':datetime.now().isoformat(timespec='seconds'),'ok':False,'pending':True,'errors':[]})
    if sys.argv[1]=='start':
        command('reset-failed',UNIT)
        command('start','--no-block',UNIT)
    elif sys.argv[1]=='stop':command('stop','--no-block',UNIT)
    print(json.dumps(status(),ensure_ascii=True))
if __name__=='__main__':main()
