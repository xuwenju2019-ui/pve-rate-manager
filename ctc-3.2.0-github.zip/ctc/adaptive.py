"""Upstream-only IFB shaping. Never modify tap egress or foreign filters."""
from datetime import datetime
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

PREF = '49152'


from schedule import phase, next_boundary


def nic_mac(value):
    for part in value.split(','):
        k,sep,v=part.partition('=')
        if sep and re.fullmatch(r'(?:[0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}',v):return v.upper()
    raise ValueError('网卡没有可验证的 MAC 地址')


class Shaper:
    def __init__(self,runner=None):self.run=runner or self._run

    def _run(self,args):
        p=subprocess.run(args,text=True,capture_output=True,timeout=3)
        if p.returncode:raise RuntimeError((p.stderr or p.stdout).strip()[:800])
        return p.stdout

    def names(self,r):return f'tap{r["vmid"]}i{int(r["nic"][3:])}',f'prm{r["vmid"]}i{int(r["nic"][3:])}'

    def links(self,name):
        data=json.loads(self.run(['/usr/sbin/ip','-j','-d','link','show']))
        return next((x for x in data if x['ifname']==name),None)

    def tc(self,*args):return self.run(['/usr/sbin/tc',*map(str,args)])

    def filters(self,tap):
        kinds={q.get('kind') for q in json.loads(self.tc('-j','qdisc','show','dev',tap))}
        if not kinds.intersection({'ingress','clsact'}):return []
        raw=json.loads(self.tc('-j','filter','show','dev',tap,'ingress'))
        # tc may emit a classifier summary followed by the actual handle entry.
        return [f for f in raw if f.get('options') or f.get('handle') is not None
                or not any(g.get('options') and g.get('pref')==f.get('pref') and g.get('kind')==f.get('kind') for g in raw)]

    def is_ours(self,f,ifb):
        actions=f.get('options',{}).get('actions',[])
        return (str(f.get('pref'))==PREF and f.get('kind')=='matchall'
                and str(f.get('options',{}).get('handle',f.get('handle'))) in ('1','0x1')
                and len(actions)==1 and actions[0].get('kind')=='mirred'
                and actions[0].get('mirred_action')=='redirect' and actions[0].get('direction')=='egress'
                and actions[0].get('to_dev')==ifb)

    def inspect(self,r):
        tap,ifb=self.names(r);link=self.links(tap)
        if not link:raise RuntimeError('VM 未运行或 TAP 网卡不存在；暂不调整')
        device=self.links(ifb)
        alias='pve-rate-manager:'+r['id']
        if device and (device.get('ifalias')!=alias or device.get('linkinfo',{}).get('info_kind')!='ifb'):
            raise RuntimeError('同名 IFB 不属于此规则，拒绝接管')
        filters=self.filters(tap)
        if any(not self.is_ours(f,ifb) for f in filters):
            raise RuntimeError('网卡已有其它 ingress 流控，拒绝覆盖')
        return tap,ifb,device,filters

    def release(self,r):
        tap,ifb=self.names(r);device=self.links(ifb)
        if device and device.get('ifalias')!='pve-rate-manager:'+r['id']:
            raise RuntimeError('IFB 所有权不匹配，未删除')
        if self.links(tap):
            for f in self.filters(tap):
                if self.is_ours(f,ifb):self.tc('filter','del','dev',tap,'ingress','pref',PREF,'protocol','all','handle','1','matchall')
        if device:self.run(['/usr/sbin/ip','link','delete','dev',ifb])
        # An empty clsact is deliberately retained; foreign egress filters are untouched.
        if self.links(tap) and any(self.is_ours(f,ifb) for f in self.filters(tap)):
            raise RuntimeError('解除流控后校验失败')

    def verify_released(self,r):
        tap,ifb=self.names(r)
        if not self.links(tap):raise RuntimeError('TAP不存在，无法核验网卡运行状态')
        if self.links(ifb):raise RuntimeError('本程序IFB仍存在，未确认解除')
        if self.filters(tap):raise RuntimeError('发现其它上行入口流控；已保留，无法确认完全放开')

    def apply(self,r,rate):
        if rate is None:self.release(r);return
        tap,ifb,device,filters=self.inspect(r)
        created=False
        try:
            if not device:
                self.run(['/usr/sbin/modprobe','ifb'])
                self.run(['/usr/sbin/ip','link','add',ifb,'type','ifb']);created=True
                self.run(['/usr/sbin/ip','link','set','dev',ifb,'alias','pve-rate-manager:'+r['id']])
                self.run(['/usr/sbin/ip','link','set','dev',ifb,'up'])
                self.tc('qdisc','add','dev',ifb,'root','handle','1:','htb','default','1')
            bps=max(1,int(Decimal(str(rate))*1024*1024))
            self.tc('class','replace','dev',ifb,'parent','1:','classid','1:1','htb',
                    'rate',str(bps)+'bps','ceil',str(bps)+'bps','burst','64kb','quantum','1514')
            if created:self.tc('qdisc','add','dev',ifb,'parent','1:1','handle','10:','fq_codel','limit','256','memory_limit','1048576')
            if not filters:
                qs=json.loads(self.tc('-j','qdisc','show','dev',tap))
                kinds={q.get('kind') for q in qs}
                if 'ingress' in kinds:raise RuntimeError('已有其它 ingress 队列，拒绝覆盖')
                if 'clsact' not in kinds:self.tc('qdisc','add','dev',tap,'clsact')
                self.tc('filter','add','dev',tap,'ingress','protocol','all','pref',PREF,'handle','1',
                        'matchall','action','mirred','egress','redirect','dev',ifb)
            if not any(self.is_ours(f,ifb) for f in self.filters(tap)):
                raise RuntimeError('上行流控未生效')
            classes=json.loads(self.tc('-j','class','show','dev',ifb))
            if not any(c.get('handle',c.get('classid'))=='1:1' and c.get('class',c.get('kind'))=='htb' for c in classes):raise RuntimeError('上行限速类校验失败')
        except Exception:
            if created:
                # Best effort removes only this rule's own redirect and IFB.
                try:self.release(r)
                except Exception:pass
            raise

    def sample(self,r):
        tap,_=self.names(r);base=Path('/sys/class/net')/tap
        identity=(Path('/proc/sys/kernel/random/boot_id').read_text().strip()+':'+
                  (base/'ifindex').read_text().strip()+':'+str(r.get('mac','')))
        return identity,int((base/'statistics/rx_bytes').read_text()),int((base/'statistics/tx_bytes').read_text())


class DemoShaper:
    def __init__(self):self.rates={};self.counters={}
    def apply(self,r,rate):self.rates[r['id']]=rate
    def release(self,r):self.rates.pop(r['id'],None)
    def verify_released(self,r):
        if r['id'] in self.rates:raise RuntimeError('demo flow remains')
    def sample(self,r):
        key=r['id'];self.counters[key]=self.counters.get(key,0)+1024*1024
        return 'demo:'+key,self.counters[key],self.counters[key]//4
