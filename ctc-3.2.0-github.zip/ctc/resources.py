"""Read host availability; no network calls or changes to host memory configuration."""
from pathlib import Path

def available_bytes(path=Path('/proc/meminfo')):
    for line in path.read_text().splitlines():
        if line.startswith('MemAvailable:'):return int(line.split()[1])*1024
    raise RuntimeError('无法读取宿主机可用内存，未开始新任务')

def require_memory(minimum=768*1024*1024):
    if available_bytes()<minimum:raise ValueError('宿主机可用内存不足，暂不允许新的抓包或归属库加载任务；基础调度继续')
