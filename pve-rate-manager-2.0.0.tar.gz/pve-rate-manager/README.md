# PVE 网卡限速 2.0.0

在 Proxmox VE 页面管理虚拟网卡的限速时段。顶部入口为 **“网卡限速”**，使用 PVE 原生蓝底白字按钮，沿用 `root@pam` 登录，无独立管理密码、无额外对外管理端口。

面向 **Proxmox VE 9.2.2、Linux bridge、QEMU 虚拟机**。这是第三方本地扩展，不是 Proxmox 官方插件。

## 功能

| 项目 | 支持情况 |
|---|---|
| 目标选择 | 当前节点的虚拟机 ID、已有网卡 |
| 限速值 | 0.001–1000000 MB/s，最多三位小数 |
| 方向 | **上行、下行分别限速，两个方向使用相同值** |
| 循环 | 每天、每周指定日期、仅一次（完整日期时间） |
| 跨午夜 | 支持，星期按开启当天计算 |
| 开关 | 单条规则开关、全部自动调度开关 |
| 关闭行为 | 完全解除该网卡的限速 |
| 多目标 | 不同虚拟机、不同网卡分别配置 |
| 配置保护 | 保留 MAC、bridge、VLAN、firewall、queues 等属性 |
| 操作记录 | 页面近期记录、systemd 日志、写前备份 |

例如 `5 MB/s` 表示虚拟机发送、接收方向**各自**按此速度限制，不是上下行合计 5 MB/s。沿用 PVE 的 `rate` 参数，不支持仅限上行或仅限下行；经过所选网卡的内网流量同样受影响。

## 安装或从 1.x 升级

将 `pve-rate-manager-2.0.0.tar.gz` 上传到宿主机 `/root`，以 root 打开宿主机 Shell：

```bash
cd /root
mkdir -p pve-rate-manager-v2-install
tar -xzf pve-rate-manager-2.0.0.tar.gz -C pve-rate-manager-v2-install
cd pve-rate-manager-v2-install/pve-rate-manager
bash install.sh
```

新安装不创建默认规则，不自动修改 VM 100 或其他网卡。**升级保留现有规则，并按当前时间继续运行**。安装会短暂重启 PVE 管理服务，网页和 Shell 连接可能断开；不重启虚拟机。不要在安装期间同时编辑规则。

安装器会依次核验文件清单、运行离线测试、在实际 PVE 上运行 Perl 中文参数测试、保存安装前快照、注册入口、启动后台，并核验运行版本为 `2.0.0`。失败时尝试恢复本次安装前的程序文件、PVE 入口和原后台启用/运行状态；规则文件保留当前内容，不用历史备份覆盖管理员的修改。

安装完成后，用原 PVE 地址登录 `root@pam`，按 **Ctrl+F5**，点击顶部蓝色 **“网卡限速”**。普通用户和 API token 不能使用管理接口。无需独立密码，也不使用 8443。

## URL 下载安装

以下地址只有在你将发布文件上传到仓库根目录后才生效。当前仓库：

<https://github.com/xuwenju2019-ui/pve-rate-manager>

请以 root 在宿主机 Shell 中执行：

```bash
(
set -e
cd "$(mktemp -d /root/pve-rate-v2.XXXXXX)"
curl -fL --retry 3 -o pve-rate-manager-2.0.0.tar.gz \
  https://raw.githubusercontent.com/xuwenju2019-ui/pve-rate-manager/main/pve-rate-manager-2.0.0.tar.gz
curl -fL --retry 3 -o SHA256SUMS \
  https://raw.githubusercontent.com/xuwenju2019-ui/pve-rate-manager/main/SHA256SUMS
sha256sum -c SHA256SUMS
tar -xzf pve-rate-manager-2.0.0.tar.gz
cd pve-rate-manager
bash install.sh
)
```

`SHA256SUMS` 核验包的完整性，来源仍需信任你的 GitHub 仓库和 HTTPS。安装器另外核验包内源码清单。PVE 存储的“导入 → 从 URL 下载”用于镜像导入，不能替代宿主机程序安装。

## 使用方法

1. 添加规则，选择虚拟机 ID 和已有网卡。VM ID 不是宿主机编号。
2. 填写规则名称和限速值，选择每天、每周或仅一次。
3. 选择开启、关闭时间，点击“预览当前效果”。
4. 确认参数后保存，观察规则实际状态和执行记录。

每天 `00:20 → 08:00`：每天 00:20 开始限速，08:00 完全解除。

每周一 `22:00 → 06:00`：周一晚开始，周二早上解除。单次规则则使用完整日期时间。

**保存即接管该网卡的 rate。** 保存时不在限速时段，会解除当前已有的限速，包括手动设置的限速。管理期间手动改变 rate，通常会在一分钟内被当前规则重新对齐。需要回到手动管理时，先删除规则。

一张网卡只允许一条规则，避免冲突；不同网卡可使用不同时间和速度。关闭单条规则或暂停总调度，会解除相应网卡限速；页面显示失败时，应先处理错误，不能视为已经解除。

程序在线、自动调度开启、规则启用、实际正在限速是不同状态。直接停止程序不会自动解除已经设置的 rate。若要停机并解除，先暂停调度，确认每条规则未限速，再停服务。

## 时间与异常

- 使用**宿主机本地时区**，页面显示宿主机时间。用 `timedatectl status` 检查。
- 开始时间包含在时段内，结束时间不包含；开始和结束相同不允许保存。
- 通常每 5 秒检查一次，实际处理耗时取决于 PVE 和规则数量，不是硬实时保证。
- 每分钟重新核对真实网卡配置；单条规则失败不阻断后续规则，约一分钟后重试。
- 断电、停机后恢复时直接对齐当前时段，不逐个回放错过的切换；已过期的单次规则会解除限速，不补开。
- 夏令时跳变按当前本地时钟判断；多节点请保持时间和时区一致。

VM 锁定、网卡不存在、模板、任何待生效配置、并发摘要冲突、备份失败等情况拒绝写入。程序不强制解锁、不清空 pending、不重启 VM。

写入使用 `qm set VMID --digest 摘要 --netN 完整属性`。失败可能已经留下待生效配置，请检查 `qm pending VMID` 和 `qm config VMID --current 1`。程序不自动回滚网卡配置，以免覆盖管理员并发修改；实际生效方向及吞吐应在部署主机测试。

## 多节点及迁移

每个 PVE 节点分别安装。**登录哪个节点地址，就管理那个节点**；在左侧树里点击另一个节点不会切换此后台。没有跨节点集中管理、HA 迁移跟随或远程 root 密码存储。

迁移前，先在原节点删除对应规则并确认解除限速，再迁移并在目标节点添加规则。若已迁移导致旧规则无法删除，请先处理目标归属，不要让两个程序同时控制同一网卡。

## 检查、日志和备份

```bash
systemctl status pve-rate-manager --no-pager
pvesh get /rate-manager/status --output-format json
journalctl -u pve-rate-manager -n 100 --no-pager
python3 /opt/pve-rate-manager/integration.py check
```

程序停止后，需通过宿主机 `systemctl start pve-rate-manager` 启动，不能通过已经断开的网页启动自己。PVE 登录过期时，请在主界面重新登录并重新打开管理窗口。退出 PVE 不会停止已保存的后台调度。

| 内容 | 位置 |
|---|---|
| 规则 | `/var/lib/pve-rate-manager/rules.json` |
| 每次网卡写入前备份 | `/var/lib/pve-rate-manager/backups/` |
| PVE 入口文件备份 | `/var/lib/pve-rate-manager/integration-backups/` |
| 安装/升级前快照 | `/var/lib/pve-rate-manager/install-backups/` |
| 私有后台 socket | `/run/pve-rate-manager/api.sock` |

备份不自动清理，请定期检查磁盘空间。不要公开上传规则、密码文件、安装前快照或实际 VM 配置。

## PVE 升级与撤销

本地集成会在 `PVE/API2.pm` 和 `pvemanagerlib.js` 追加标记块，在 `index.html.tpl` 添加自己的缓存版本参数，另装受保护的 API 模块和静态页面。PVE 原有票据、CSRF 和 root 权限校验继续生效。后台使用 root 专用 Unix socket，不监听公网 TCP 端口。

PVE 更新可能覆盖入口。更新后运行上面的 `integration.py check`；入口消失或接口 404 时，使用兼容的安装包重新执行安装并刷新。**不要用旧版本的完整 PVE 文件覆盖更新后的文件**。正常撤销仅移除自己的标记及缓存参数，保留 PVE 当前内容。

在解压目录卸载：

```bash
bash uninstall.sh
```

卸载先停服务、解除全部规则网卡限速，再撤销入口和移除本程序文件。如果某个目标无法解除，脚本中止并保留文件；服务此时已停止，请处理错误后重试，或重新启动后台。规则和备份保留，重新安装会读取旧规则。希望重装后为空规则时，先在页面删除规则再卸载。

只撤销 PVE 界面入口（后台仍继续调度）：

```bash
python3 /opt/pve-rate-manager/integration.py remove
systemctl restart pvedaemon pveproxy
```

临时停服并解除限速：

```bash
systemctl stop pve-rate-manager
python3 /opt/pve-rate-manager/manager.py release-all
```

如确需从安装快照恢复程序文件，应先停后台，再使用与快照对应版本的 `deployment.py restore 完整快照目录`；然后 daemon-reload 并恢复服务。快照针对当次安装前的 PVE 版本，不要在后续 PVE 软件包升级后盲目回退。

## 测试与验收范围

```bash
python3 -m unittest discover -s tests -p 'test_*.py' -v
# 以下需要开发机 Node.js，PVE 安装不依赖它：
node tests/test_frontend.cjs
# 以下必须在实际 PVE 上运行，安装器会自动执行：
perl tests/test_unicode.pl
```

Python 测试使用模拟 PVE 和内存 HTTP 处理器，不会修改真实 VM。前端测试检查入口样式、打开窗口、登录状态、CSRF 和请求结构，不代替真实浏览器测试。Perl 测试检查中文参数解析及转发字节编码，需要 PVE 自身模块。

1.x 在本会话的 PVE 9.2.2 上已反馈安装、窗口打开、虚拟机列表及中文报错修复成功。**2.0 完整包仍需在你的主机完成升级和时段切换验收**：测试未来几分钟开启/关闭、实际双向吞吐、暂停、重启对齐、其它网卡参数不变。不要将模拟测试通过等同于全部实机测试通过。

## 上传 GitHub

解压 `pve-rate-manager-2.0.0-github.zip`，进入其中的 `pve-rate-manager` 目录，将**目录里面的内容**上传到现有仓库根目录并提交，不要再套一层外部目录。

该上传包包含源码、README、更新说明、测试、GitHub Actions，以及可直接下载的 `pve-rate-manager-2.0.0.tar.gz` 和 `SHA256SUMS`。保留旧 1.1 安装包也不会影响新版下载。

也可以创建 GitHub Release，标签 `v2.0.0`，上传安装包和 `SHA256SUMS` 作为附件；发布说明见 `RELEASE_NOTES.md`。本次只生成文件，不会替你向 GitHub 发布。

## 参考

- [PVE 原生双向流控实现](https://github.com/proxmox/pve-common/blob/master/src/PVE/Network.pm)
- [PVE 原有认证与 CSRF](https://github.com/proxmox/pve-manager/blob/master/PVE/HTTPServer.pm)
- [PVE 前端工具栏](https://github.com/proxmox/pve-manager/blob/master/www/manager6/Workspace.js)
- [qm 参数、当前配置和 digest](https://github.com/proxmox/pve-docs/blob/master/generated/qm.1-synopsis.adoc)

MIT License。部署主机实际 API、软件版本和网卡状态为最终兼容性依据。
