#!/usr/bin/python3
"""Reversible, marker-based integration into the local PVE installation."""
import argparse
import re
import os
from pathlib import Path
import shutil
import subprocess
import time

BASE = Path('/usr/share/perl5/PVE/API2.pm')
JS = Path('/usr/share/pve-manager/js/pvemanagerlib.js')
TEMPLATE = Path('/usr/share/pve-manager/index.html.tpl')
STATE = Path('/var/lib/pve-rate-manager/integration-backups')
ROOT = Path(__file__).resolve().parent
PERL_START = b'\n# PVE-RATE-MANAGER-BEGIN-v1\n'
PERL_END = b'# PVE-RATE-MANAGER-END-v1\n'
JS_START = b'\n/* PVE-RATE-MANAGER-BEGIN-v1 */\n'
JS_END = b'/* PVE-RATE-MANAGER-END-v1 */\n'


def remove_block(data, start, end):
    if start not in data and end not in data:
        return data
    if data.count(start) != 1 or data.count(end) != 1:
        raise ValueError('Integration marker is incomplete or duplicated; refusing to overwrite')
    a, b = data.index(start), data.index(end)
    if b < a:
        raise ValueError('Integration markers out of order')
    return data[:a] + data[b + len(end):]


def write_file(path, data):
    previous = path.read_bytes()
    if data == previous:
        return
    STATE.mkdir(parents=True, exist_ok=True, mode=0o700)
    backup = STATE / (str(time.time_ns()) + '-' + path.name)
    shutil.copy2(path, backup)
    mode = path.stat().st_mode & 0o777
    tmp = path.with_name(path.name + '.rate-manager.tmp')
    try:
        with tmp.open('xb') as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.chmod(tmp, mode)
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=['install', 'remove', 'check'])
    args = p.parse_args()
    if os.geteuid() != 0:
        raise RuntimeError('Run as root on PVE')
    original = {BASE: BASE.read_bytes(), JS: JS.read_bytes(), TEMPLATE: TEMPLATE.read_bytes()}
    if args.action == 'check':
        if (PERL_START not in original[BASE] or JS_START not in original[JS]
                or b'prm-entry=2.0.0&' not in original[TEMPLATE]):
            raise RuntimeError('PVE integration is missing; rerun the installer after a PVE update')
        print('PVE integration markers present')
        return
    perl = remove_block(original[BASE], PERL_START, PERL_END)
    js = remove_block(original[JS], JS_START, JS_END)
    page = re.sub(rb'prm-entry=[^&"\s]+&', b'', original[TEMPLATE])
    if args.action == 'install':
        if b'package PVE::API2;' not in perl or b'PVE.StdWorkspace' not in js:
            raise RuntimeError('Unrecognized PVE files; no changes made')
        perl += PERL_START + b"require PVE::API2::RateManager;\nPVE::API2->register_method({ subclass => 'PVE::API2::RateManager', path => 'rate-manager' });\n1;\n" + PERL_END
        js += JS_START + (ROOT/'pve-hook.js').read_bytes() + b'\n' + JS_END
        needle = b'/pve2/js/pvemanagerlib.js?'
        if page.count(needle) != 1:
            raise RuntimeError('Unrecognized PVE page template; no changes made')
        page = page.replace(needle, needle + b'prm-entry=2.0.0&', 1)
    try:
        write_file(BASE, perl)
        write_file(JS, js)
        write_file(TEMPLATE, page)
        subprocess.run(['/usr/bin/perl', '-c', str(BASE)], check=True)
        subprocess.run(['/usr/bin/perl', '-MPVE::API2', '-e',
                        'PVE::JSONSchema::validate_method_info($_) for @{PVE::API2::RateManager->method_attributes()};'
                        if args.action == 'install' else '1'], check=True)
    except Exception:
        # Restore precisely the files read during this invocation, not an old package version.
        for file, data in original.items():
            write_file(file, data)
        raise
    print('PVE integration ' + args.action + ' completed; backups: ' + str(STATE))


if __name__ == '__main__':
    main()
