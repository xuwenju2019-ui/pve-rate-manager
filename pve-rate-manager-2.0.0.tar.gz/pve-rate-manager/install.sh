#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
[[ $EUID -eq 0 ]] || { echo '请在 PVE 宿主机以 root 执行。'; exit 1; }
[[ -x /usr/bin/pvesh && -x /usr/sbin/qm && -f /usr/share/perl5/PVE/API2.pm && -f /usr/share/pve-manager/index.html.tpl && -f /usr/share/pve-manager/js/pvemanagerlib.js ]] || { echo '未检测到兼容的 PVE 安装，未修改。'; exit 1; }
if [[ -e /usr/share/perl5/PVE/API2/RateManager.pm ]] && ! grep -q 'PVE-RATE-MANAGER-BEGIN-v1' /usr/share/perl5/PVE/API2.pm; then
  echo '发现无安装标记的同名 API 模块，请先检查，未覆盖。'; exit 1
fi
sha256sum -c MANIFEST.sha256
/usr/bin/python3 -m unittest discover -s tests -p 'test_*.py' -q
/usr/bin/perl tests/test_unicode.pl
/usr/bin/perl -c /usr/share/perl5/PVE/API2.pm
PRM_WAS_ACTIVE=false
PRM_WAS_ENABLED=false
if systemctl is-active --quiet pve-rate-manager.service; then PRM_WAS_ACTIVE=true; fi
if systemctl is-enabled --quiet pve-rate-manager.service 2>/dev/null; then PRM_WAS_ENABLED=true; fi
PRM_BACKUP=$(/usr/bin/python3 deployment.py snapshot)
echo "安装/升级至 2.0.0；安装前备份：$PRM_BACKUP"
recover() {
  local rc=$?
  trap - ERR
  echo '安装失败，正在还原本次安装前的程序及 PVE 入口。规则文件保留当前内容。'
  systemctl stop pve-rate-manager.service 2>/dev/null || true
  if ! /usr/bin/python3 deployment.py restore "$PRM_BACKUP"; then
    echo "自动还原未完成，请保留错误日志。备份：$PRM_BACKUP"
    exit "$rc"
  fi
  systemctl daemon-reload
  if [[ $PRM_WAS_ENABLED == true ]]; then systemctl enable pve-rate-manager.service || true
  else systemctl disable pve-rate-manager.service 2>/dev/null || true; fi
  if [[ $PRM_WAS_ACTIVE == true ]]; then systemctl start pve-rate-manager.service || true; fi
  systemctl restart pvedaemon.service pveproxy.service || true
  echo "已还原程序文件；如有报错请检查服务状态。备份：$PRM_BACKUP"
  exit "$rc"
}
trap recover ERR
if systemctl cat pve-rate-manager.service >/dev/null 2>&1; then systemctl stop pve-rate-manager.service; fi
install -d -o root -g root -m 0755 /opt/pve-rate-manager /usr/share/pve-manager/js/rate-manager
install -d -o root -g root -m 0700 /var/lib/pve-rate-manager
install -o root -g root -m 0644 manager.py integration.py deployment.py pve-hook.js /opt/pve-rate-manager/
install -o root -g root -m 0644 web/index.html web/app.js web/style.css /usr/share/pve-manager/js/rate-manager/
install -o root -g root -m 0644 RateManager.pm /usr/share/perl5/PVE/API2/RateManager.pm
install -o root -g root -m 0644 pve-rate-manager.service /etc/systemd/system/pve-rate-manager.service
/usr/bin/python3 /opt/pve-rate-manager/integration.py install
systemctl daemon-reload
systemd-analyze verify /etc/systemd/system/pve-rate-manager.service
systemctl enable --now pve-rate-manager.service
for attempt in {1..10}; do
  if [[ -S /run/pve-rate-manager/api.sock ]] && systemctl is-active --quiet pve-rate-manager.service; then break; fi
  sleep 1
done
[[ -S /run/pve-rate-manager/api.sock ]]
systemctl is-active --quiet pve-rate-manager.service
echo '正在重启 PVE 管理服务；管理连接可能短暂断开，虚拟机不会重启。'
systemctl restart pvedaemon.service pveproxy.service
systemctl is-active --quiet pvedaemon.service
systemctl is-active --quiet pveproxy.service
/usr/bin/pvesh get /rate-manager/status --output-format json | /usr/bin/python3 -c 'import json,sys; s=json.load(sys.stdin); s=json.loads(s) if isinstance(s,str) else s; assert s["version"]=="2.0.0", "Unexpected running version"; print("后台版本校验通过："+s["version"])'
trap - ERR
if systemctl cat pve-net1-rate.timer >/dev/null 2>&1; then
  systemctl disable --now pve-net1-rate.timer
  systemctl stop pve-net1-rate.service || true
fi
echo 'PVE 网卡限速 2.0.0 安装完成。用原 PVE 地址登录 root@pam，按 Ctrl+F5，点击蓝色“网卡限速”。'
echo '新安装规则为空；升级保留规则并按宿主机当前时间继续运行。上下行分别限速，关闭后完全解除。'
