/* PVE Rate Manager: v2.0.0: native blue button, existing PVE authentication. */
(function () {
    'use strict';
    if (typeof Ext === 'undefined') return;
    function openManager() {
        if (!window.Proxmox || Proxmox.UserName !== 'root@pam') {
            Ext.Msg.alert('网卡定时限速', '请先使用 root@pam 登录 PVE。');
            return;
        }
        const existing = Ext.getCmp('pve-rate-manager-window');
        if (existing) { existing.show(); existing.toFront(); return; }
        Ext.create('Ext.window.Window', {
            id: 'pve-rate-manager-window',
            title: '网卡定时限速 · 当前登录节点',
            width: Math.min(1280, window.innerWidth - 32),
            height: Math.max(320, window.innerHeight - 64),
            modal: true,
            maximizable: true,
            layout: 'fit',
            items: [{
                xtype: 'component',
                autoEl: {
                    tag: 'iframe',
                    title: '网卡定时限速管理器',
                    src: '/pve2/js/rate-manager/index.html?v=2.0.0',
                    frameborder: '0',
                },
            }],
        }).show();
    }
    Ext.onReady(function () {
        let tries = 0;
        const timer = window.setInterval(function () {
            if (++tries > 300) { window.clearInterval(timer); return; }
            const user = Ext.getCmp('userinfo') || Ext.ComponentQuery.query('#userinfo')[0];
            if (!user || !user.ownerCt || !user.ownerCt.add) return;
            window.clearInterval(timer);
            if (Ext.getCmp('pve-rate-manager-button')) return;
            const button = user.ownerCt.insert(user.ownerCt.items.indexOf(user), {
                xtype: 'button',
                id: 'pve-rate-manager-button',
                text: '网卡限速',
                iconCls: 'fa fa-clock-o',
                baseCls: 'x-btn', ui: 'default',
                margin: '0 8 0 0',
                handler: openManager,
            });
            // Login/logout changes are reflected without persisting any credentials.
            const monitor = window.setInterval(function () {
                if (button.destroyed) { window.clearInterval(monitor); return; }
                const authenticated = window.Proxmox && Proxmox.UserName === 'root@pam';
                button.setDisabled(!authenticated);
                const win = Ext.getCmp('pve-rate-manager-window');
                if (!authenticated && win) win.close();
            }, 1000);
        }, 250);
    });
}());
