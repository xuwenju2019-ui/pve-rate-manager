#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
[[ $EUID -eq 0 ]] || { echo '请在 PVE 宿主机以 root 执行。'; exit 1; }
[[ -x /usr/bin/pvesh && -x /usr/sbin/qm && -f /usr/share/perl5/PVE/API2.pm && -f /usr/share/pve-manager/js/pvemanagerlib.js ]] || { echo '未检测到兼容的 PVE 文件，安装已停止。'; exit 1; }
if [[ -e /usr/share/perl5/PVE/API2/RateManager.pm ]] && ! grep -q 'PVE-RATE-MANAGER-BEGIN-v1' /usr/share/perl5/PVE/API2.pm; then
  echo '发现无安装标记的同名 API 模块，请先检查，未覆盖。'; exit 1
fi
/usr/bin/python3 -m unittest discover -s tests -p 'test_*.py' -q
/usr/bin/perl -c /usr/share/perl5/PVE/API2.pm
echo '安装 PVE 集成版：不设置独立密码或开放 8443。稍后重启 PVE 管理服务，虚拟机不会重启。'
systemctl stop pve-rate-manager.service 2>/dev/null || true
install -d -o root -g root -m 0755 /opt/pve-rate-manager /usr/share/pve-manager/js/rate-manager
install -d -o root -g root -m 0700 /var/lib/pve-rate-manager
install -o root -g root -m 0644 manager.py integration.py pve-hook.js /opt/pve-rate-manager/
install -o root -g root -m 0644 web/index.html web/app.js web/style.css /usr/share/pve-manager/js/rate-manager/
install -o root -g root -m 0644 RateManager.pm /usr/share/perl5/PVE/API2/RateManager.pm
install -o root -g root -m 0644 pve-rate-manager.service /etc/systemd/system/pve-rate-manager.service
/usr/bin/perl -c /usr/share/perl5/PVE/API2/RateManager.pm
if systemctl cat pve-net1-rate.timer >/dev/null 2>&1; then
  systemctl disable --now pve-net1-rate.timer
  systemctl stop pve-net1-rate.service || true
fi
systemctl daemon-reload
systemd-analyze verify /etc/systemd/system/pve-rate-manager.service
systemctl enable --now pve-rate-manager.service
sleep 2
systemctl is-active --quiet pve-rate-manager.service || { journalctl -u pve-rate-manager.service -n 30 --no-pager; exit 1; }
recover() {
  local rc=$?
  trap - ERR
  echo '集成安装失败，正在撤销 PVE 入口并恢复管理服务；规则及备份保留。'
  /usr/bin/python3 /opt/pve-rate-manager/integration.py remove || true
  systemctl restart pvedaemon.service pveproxy.service || true
  exit "$rc"
}
trap recover ERR
/usr/bin/python3 /opt/pve-rate-manager/integration.py install
systemctl restart pvedaemon.service pveproxy.service
systemctl is-active --quiet pvedaemon.service
systemctl is-active --quiet pveproxy.service
trap - ERR
echo '安装完成。用原来的 PVE 地址登录 root@pam，强制刷新网页，点击顶部“网卡定时限速”。'
echo '沿用 PVE 登录，无独立管理密码。新安装规则为空；升级保留已有规则并按当前时间生效。'
