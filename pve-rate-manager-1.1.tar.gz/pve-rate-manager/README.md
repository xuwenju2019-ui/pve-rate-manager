# PVE 网卡定时限速 v1.1 · 沿用 PVE 登录

登录 PVE 后，从顶部“网卡定时限速”按钮打开管理窗口。**不设置独立密码，不开放 8443 端口。** 页面、接口均走当前 PVE 地址和原有登录，写操作使用 PVE 的 CSRF 校验。当前版本仅允许 `root@pam`，不接受 API token；普通用户不会获得额外权限。

面向 PVE 9.2.2 编写；完成调度、私有接口、入口撤销和本地连接权限等离线模拟测试，**尚未在真实 PVE 9.2.2 节点验证集成、浏览器交互或实际限速**。安装器会在宿主机运行测试和 Perl 语法检查。建议先用测试节点/测试虚拟机验收，不把离线通过视为已经实机验证。

## 安装 / 从 v1.0 升级

上传 `pve-rate-manager-1.1.tar.gz` 到宿主机 `/root`，以 root 执行：

```sh
cd /root
tar -xzf pve-rate-manager-1.1.tar.gz
cd pve-rate-manager
bash install.sh
```

若此目录已放过旧版本，请先将旧的解压目录改名，再解压新包，以免混用文件。安装器将停止旧版后台，换成只监听 root 私有 Unix socket 的后台；已保存的规则保留并按当前时间继续执行。旧 `auth.json` 或监听配置即使保留在磁盘，也不再被读取或用于认证。

安装会短暂重启 `pvedaemon` 和 `pveproxy` 管理服务，管理页面或控制台连接可能需要重连；不会重启运行中的虚拟机。新安装规则为空，不会自动修改任何网卡。

安装完成后：

1. 打开原来的 PVE 地址，例如 `https://宿主机IP:8006`。
2. 使用 `root@pam` 登录；已登录时不用再次输入密码。
3. 用 Ctrl+F5 强制刷新，点击顶部“网卡定时限速”。
4. 点击“添加规则”，选择虚拟机 ID 和网卡、限速值、时间、循环策略。
5. 先“预览当前效果”，确认只改变 rate，再保存。

如果使用反向代理访问 PVE，代理须支持 `/api2/json/rate-manager/` 和 `/pve2/js/rate-manager/` 两条同源路径。不要直接打开磁盘里的管理 HTML；它需要在已登录的 PVE 页面窗口内读取实时 CSRF 令牌。

## 界面功能和时间语义

- 程序在线状态、调度总开关、各规则启用状态、实际执行成功/失败及最近记录。
- 鼠标选择当前登录节点上的 QEMU 虚拟机和已有网卡；不管理 LXC 或模板。
- 每天：每日重复；每周：选择一个或多个开启日期；仅一次：选择完整的开始/结束日期时间。“某一天执行”选仅一次即可。
- 关闭限速时间到达、关闭单条规则或暂停总调度，均会**完全解除对应网卡限速**。
- 每张网卡一条规则，不同虚拟机、不同网卡可分别设置，也可使用相同时间。
- 跨午夜时，星期按开启当天计算。例如每周一 22:00 开启、06:00 关闭，表示周二早上解除。
- 时段采用“开始包含，结束不包含”，开启与关闭时间不能相同。
- 时间跟随宿主机本地时区。请用 `timedatectl status` 确认；多节点需同步时间和时区。夏令时跳变以当前本地时间对齐，不回放错过的切换。
- 正常约每 5 秒检查，实际执行依赖 PVE 响应和规则数；不是硬实时保证。每分钟重新核对真实配置，防止状态偏离。

VM 100 / net1 示例：限速值 5 MB/s，开启 00:20，关闭时间由你选择；界面默认 08:00 只是示例。当前配置 `virtio=BC:24:11:D6:63:7D,bridge=vmbr1,rate=5` 不会硬编码覆盖回去；每次读取真实配置，保留 MAC、bridge、VLAN、queues、firewall 等其它属性。

**保存即接管该网卡的 rate。** 保存时不在限速时段就立即解除原有限速，哪怕原本是手动设置的。管理期间手动改变 rate，通常会在一分钟内被规则重新对齐。删除规则会先解除限速，核验成功后才移交回手动管理。

程序在线、调度开启、规则启用、实际正在限速是不同状态。暂停调度后后台仍在线，以便解除限速和显示状态。若直接停止后台或宿主机关机，已设置的 rate 会保留；恢复后直接对齐当前应有状态，不逐个补放漏掉的事件。

## 集成方式、备份和 PVE 升级

这是第三方本地集成，**不是 Proxmox 官方插件**。为使 PVE 自身处理认证和 CSRF，安装器进行以下可撤销改动：

- 在 `/usr/share/perl5/PVE/API2.pm` 尾部追加标记包围的接口注册块；原有内容保留。
- 新建 `/usr/share/perl5/PVE/API2/RateManager.pm`，提供受保护的 root 专用接口；由 PVE 以其原有 protected 路由转给 pvedaemon。
- 在 `/usr/share/pve-manager/js/pvemanagerlib.js` 尾部追加标记包围的工具栏入口；管理页面放在 `/usr/share/pve-manager/js/rate-manager/`。
- `/opt/pve-rate-manager` 中的后台只监听 `/run/pve-rate-manager/api.sock`；目录 0700、socket 0600，并检查连接进程 uid 为 0。无对外 TCP 管理端口。

每次修改 PVE 文件前都备份到 `/var/lib/pve-rate-manager/integration-backups/`。重复安装先移除旧的标记块再插入新块，不重复添加按钮。标记不完整时拒绝覆盖。Perl 语法检查失败时还原本次修改；服务重启阶段失败时尝试撤掉集成并重启管理服务，保留规则和备份。

PVE 软件包更新可能覆盖接口注册、工具栏入口或静态页面。更新后检查：

```sh
python3 /opt/pve-rate-manager/integration.py check
```

若入口消失或接口 404，使用当前版本安装包重新执行 `bash install.sh`，然后强制刷新 PVE。**不要用旧的完整 API2.pm 或 JS 备份覆盖升级后的 PVE 文件**。脚本撤销时仅移除自己的标记块，保留当前版本和其它改动。新版 PVE 的接口若变化，安装可能拒绝或检查失败，应先在测试节点确认兼容性。

## 节点范围

每节点分别安装。在哪个节点地址登录，就管理哪个节点上的虚拟机；在 PVE 树中点击其它节点不会切换本程序后台。顶部窗口和页面会显示实际节点。

这版没有跨节点集中调度或 HA 迁移跟随。迁移 VM 前，先在原节点删除其规则并确认解除限速，再迁移并到新节点添加规则；各节点规则独立。若已经迁移，旧节点会报目标不存在，不会自动修改远程网卡。

## 写入保护和异常处理

- 仅执行 `qm set VMID --digest 摘要 --netN 当前完整属性`；不直接改 VM 配置文件，不重启 VM，不修改其它网卡。
- 每次实际写入前备份到 `/var/lib/pve-rate-manager/backups/`。已有相同 rate 时幂等跳过；解除限速删除 rate，已有 rate=0 也视为无限速。
- VM 锁定、模板、网卡不存在、任何待生效变更、摘要并发冲突、备份失败等情况拒绝修改。
- 命令超时、写后校验失败时显示错误，不自动回滚，避免覆盖管理员同时进行的修改。失败可能已经留下 pending，请在 PVE 中审查 `qm pending VMID` 和 `qm config VMID --current 1`。
- 一条规则失败不阻断后续规则，约一分钟后重试；不强制解锁、清空 pending 或重启虚拟机。
- 本程序只核验配置，不代表实际吞吐测试通过；是否热更新取决于部署主机。请不要让旧脚本、cron 或另一个程序同时控制同一网卡。安装器会禁用已知的旧版 `pve-net1-rate.timer`。

## 状态和日志

```sh
systemctl status pve-rate-manager --no-pager
journalctl -u pve-rate-manager -n 100 --no-pager
```

程序停机时页面不能启动自己，需在宿主机运行：

```sh
systemctl start pve-rate-manager
```

页面数据断开时显示连接中断。PVE 登录过期时回到提示页，请在 PVE 主界面重新登录并重新打开窗口。程序不会复制、存储或自行续期 PVE 登录凭据。退出 PVE 不会停止已经保存的后台调度规则。

规则保存在 `/var/lib/pve-rate-manager/rules.json`，调度日志在 systemd journal。备份不会自动清理，请定期检查空间。所有配置和备份仅 root 可访问。

## 卸载与紧急撤销入口

完整卸载：在解压目录执行：

```sh
bash uninstall.sh
```

它会停止后台、解除所有规则网卡限速、撤销 PVE 入口，再重启管理服务。若任一网卡无法解除，会中止，保留文件供处理；此时后台已经停止，请处理错误后再执行，或重新启动后台。规则和备份保留；再次安装会继续读取旧规则。希望重装后为空规则，请先在页面逐条删除规则再卸载。

若只需要恢复 PVE 原有管理界面、暂不解除当前限速，可从宿主机 Shell 撤销入口：

```sh
python3 /opt/pve-rate-manager/integration.py remove
systemctl restart pvedaemon pveproxy
```

这不会停止调度。若也要停止后台并解除全部限速：

```sh
systemctl stop pve-rate-manager
python3 /opt/pve-rate-manager/manager.py release-all
```

重新启动后台后仍按已保存规则运行。不要直接删除 `/etc/pve` 配置，也不要盲目还原其它 PVE 版本的完整文件。

## 测试与实际验收

离线测试不连接 PVE、不使用网络、不会改真实网卡：

```sh
python3 -m unittest discover -s tests -p 'test_*.py' -v
```

覆盖时间边界、跨午夜、每周、单次、多目标、关闭/暂停解除、持久化、摘要并发、pending、属性保留、写前备份、写后核验、私有处理器、root peer 检查和标记撤销。PVE 票据、CSRF、Perl 模块加载、systemd 和浏览器嵌入必须在 Linux/PVE 环境验收，不能由这些模拟测试证明通过。

安装后先使用测试 VM：

1. root@pam 登录后能打开窗口，确认节点和 VM/网卡列表正确。
2. 用未登录窗口或普通用户请求 `/api2/json/rate-manager/status`，应被拒绝。root 写操作缺少 CSRF 也应被 PVE 拒绝。
3. 预览确认 MAC、bridge、其它参数不变。
4. 设未来几分钟开启和关闭，检查当前配置及实际吞吐；关闭时 rate 删除，其他网卡不变。
5. 测试关闭规则、暂停全部调度、重启后台及卸载撤销。确认通过后再配置正式 VM 100。

参考官方源码：

- [PVE HTTP 认证、CSRF 与 protected 转发](https://github.com/proxmox/pve-manager/blob/master/PVE/HTTPServer.pm)
- [PVE API 注册](https://github.com/proxmox/pve-manager/blob/master/PVE/API2.pm)
- [PVE 工具栏](https://github.com/proxmox/pve-manager/blob/master/www/manager6/Workspace.js)
- [前端 CSRF 令牌处理](https://github.com/proxmox/proxmox-widget-toolkit/blob/master/src/Utils.js)
- [qm 配置和 digest](https://github.com/proxmox/pve-docs/blob/master/generated/qm.1-synopsis.adoc)

使用的是当前官方上游资料，部署主机的实际版本和 API 行为为最终兼容性依据。
