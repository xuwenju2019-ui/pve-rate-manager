import copy
from datetime import datetime
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('manager', Path(__file__).resolve().parents[1] / 'manager.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def rule(**kw):
    return m.validate_rule(dict(name='测试', vmid=100, nic='net1', rate='5', enabled=True,
                               policy='daily', start='00:20', end='08:00', days=[], **kw))


class ScheduleTests(unittest.TestCase):
    def test_daily_boundaries(self):
        r = rule()
        for t, expected in [('00:19',False),('00:20',True),('07:59',True),('08:00',False)]:
            self.assertEqual(m.limited(r, datetime.fromisoformat('2026-11-09T'+t)), expected)

    def test_weekly_overnight(self):
        r = rule();r.update(policy='weekly', days=[0], start='22:00', end='06:00')
        for s, expected in [('2026-11-09T21:59',False),('2026-11-09T22:00',True),
                            ('2026-11-10T05:59',True),('2026-11-10T06:00',False),('2026-11-10T23:00',False)]:
            self.assertEqual(m.limited(r, datetime.fromisoformat(s)), expected)
        self.assertEqual(m.next_change(r,datetime.fromisoformat('2026-11-10T01:00')),'2026-11-10T06:00')

    def test_once(self):
        r = rule();r.update(policy='once',once_start='2026-11-09T10:00',once_end='2026-11-10T10:00')
        r=m.validate_rule(r)
        self.assertTrue(m.limited(r,datetime.fromisoformat('2026-11-09T10:00')))
        self.assertFalse(m.limited(r,datetime.fromisoformat('2026-11-10T10:00')))
        self.assertIsNone(m.next_change(r,datetime.fromisoformat('2026-11-11T10:00')))

    def test_invalid_inputs(self):
        base=rule()
        for changes in ({'vmid':'100;reboot'},{'nic':'net1 --delete'},{'rate':'NaN'},
                        {'rate':'0'},{'rate':'-1'},{'start':'25:00'},{'end':'00:20'},
                        {'enabled':'true'},{'policy':'weekly','days':[]},
                        {'policy':'once','once_start':'2026-11-10T10:00','once_end':'2026-11-09T10:00'}):
            with self.subTest(changes=changes), self.assertRaises((ValueError,TypeError)):
                m.validate_rule({**base,**changes})

    def test_preserve_and_unlimited(self):
        old='virtio=BC:24:11:D6:63:7D,bridge=vmbr1,firewall=1,tag=10,trunks=2;3,rate=99,queues=4'
        self.assertEqual(m.new_net(old,None),'virtio=BC:24:11:D6:63:7D,bridge=vmbr1,firewall=1,tag=10,trunks=2;3,queues=4')
        self.assertEqual(m.props(m.new_net(old,'5'))['rate'],'5')
        self.assertTrue(m.same_net('virtio=AA,rate=5','rate=5.0,virtio=AA'))
        with self.assertRaises(ValueError):m.new_net(old+',rate=1','5')


class ManagerTests(unittest.TestCase):
    def setUp(self):
        # Test caller can choose TMPDIR/TEMP for a writable scratch location.
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.m=m.Manager(Path(self.tmp.name),True)

    def add(self, r=None):
        return self.m.put({'revision':self.m.config['revision'],'rule':r or rule()})

    def test_idempotent_and_release(self):
        r=self.add();now=datetime.fromisoformat('2026-11-09T01:00')
        self.m.tick(now)
        self.assertIn('rate=5',self.m.backend.configs[100]['net1'])
        with patch.object(self.m.backend,'apply',wraps=self.m.backend.apply) as apply:
            self.m.tick(now);apply.assert_not_called()
        self.m.tick(datetime.fromisoformat('2026-11-09T08:00'))
        self.assertNotIn('rate=',self.m.backend.configs[100]['net1'])
        self.assertEqual(self.m.backend.configs[100]['net0'],'virtio=BC:24:11:00:00:01,bridge=vmbr0')

    def test_pause_and_disable(self):
        r=self.add();now=datetime.fromisoformat('2026-11-09T01:00');self.m.tick(now)
        self.m.toggle({'revision':1,'enabled':False});self.m.tick(now)
        self.assertNotIn('rate=',self.m.backend.configs[100]['net1'])
        r['enabled']=False;self.add(r);self.m.toggle({'revision':3,'enabled':True});self.m.tick(now)
        self.assertNotIn('rate=',self.m.backend.configs[100]['net1'])

    def test_duplicate_and_revision(self):
        self.add()
        with self.assertRaises(ValueError):self.add()
        with self.assertRaises(ValueError):self.m.toggle({'revision':0,'enabled':False})

    def test_delete_releases(self):
        r=self.add();self.m.delete({'revision':1,'id':r['id']})
        self.assertEqual(self.m.config['rules'],[])
        self.assertNotIn('rate=',self.m.backend.configs[100]['net1'])

    def test_failed_delete_retains_rule(self):
        r=self.add()
        with patch.object(self.m.backend,'apply',side_effect=RuntimeError('locked')):
            with self.assertRaises(RuntimeError):self.m.delete({'revision':1,'id':r['id']})
        self.assertEqual(len(self.m.config['rules']),1)

    def test_one_error_does_not_stop_other_rules(self):
        self.add();second=rule();second.update(vmid=101,nic='net0');self.add(second)
        apply=self.m.backend.apply
        def fail_first(vmid,*args):
            if vmid==100:raise RuntimeError('locked')
            return apply(vmid,*args)
        with patch.object(self.m.backend,'apply',side_effect=fail_first):self.m.tick(datetime.fromisoformat('2026-11-09T01:00'))
        self.assertEqual([v['ok'] for v in self.m.runtime.values()],[False,True])

    def test_restart_reconciles(self):
        self.add();other=m.Manager(Path(self.tmp.name),True)
        other.tick(datetime.fromisoformat('2026-11-09T09:00'))
        self.assertNotIn('rate=',other.backend.configs[100]['net1'])

    def test_multiple_targets(self):
        self.add();other=rule();other.update(vmid=101,nic='net0',rate='3');self.add(other)
        self.m.tick(datetime.fromisoformat('2026-11-09T01:00'))
        self.assertIn('rate=3',self.m.backend.configs[101]['net0'])


class PVETests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.p=m.PVE(Path(self.tmp.name))
        self.base={'digest':'abc','net1':'virtio=AA,bridge=vmbr1,rate=20','net0':'virtio=BB,bridge=vmbr0'}

    def test_pending_and_digest(self):
        for pending in ([{'key':'net1','pending':'x'}],[{'key':'net1','delete':1}],
                        [{'key':'net0','pending':'x'}],[{'key':'memory','pending':2048}]):
            with patch.object(self.p,'get',side_effect=[self.base,self.base,pending]):
                with self.assertRaises(RuntimeError):self.p.snapshot(100,'net1')
        with patch.object(self.p,'get',side_effect=[self.base,{**self.base,'digest':'new'}]):
            with self.assertRaises(RuntimeError):self.p.snapshot(100,'net1')

    def test_write_digest_backup_verify(self):
        after={**self.base,'net1':'virtio=AA,bridge=vmbr1,rate=5'}
        with patch.object(self.p,'snapshot',side_effect=[self.base,after]),patch.object(self.p,'run') as run:
            self.p.apply(100,'net1','5')
            run.assert_called_once_with(['/usr/sbin/qm','set','100','--digest','abc','--net1',after['net1']])
        self.assertEqual(len(list((Path(self.tmp.name)/'backups').glob('*.json'))),1)

    def test_dry_run_no_write(self):
        with patch.object(self.p,'snapshot',return_value=self.base),patch.object(self.p,'run') as run:
            result=self.p.apply(100,'net1',None,True);run.assert_not_called()
        self.assertNotIn('rate=',result['after']);self.assertFalse((Path(self.tmp.name)/'backups').exists())

    def test_verify_failure(self):
        with patch.object(self.p,'snapshot',side_effect=[self.base,self.base]),patch.object(self.p,'run'):
            with self.assertRaises(RuntimeError):self.p.apply(100,'net1','5')

    def test_backup_failure_prevents_write(self):
        with patch.object(self.p,'snapshot',return_value=self.base),patch.object(m,'atomic_json',side_effect=OSError('disk full')),patch.object(self.p,'run') as run:
            with self.assertRaises(OSError):self.p.apply(100,'net1','5')
            run.assert_not_called()


if __name__=='__main__':unittest.main()
