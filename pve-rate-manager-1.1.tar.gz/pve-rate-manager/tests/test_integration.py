import importlib.util
from pathlib import Path
from types import SimpleNamespace
import subprocess
import tempfile
import unittest
from unittest.mock import patch
from test_manager import m

spec=importlib.util.spec_from_file_location('integration',Path(__file__).resolve().parents[1]/'integration.py')
i=importlib.util.module_from_spec(spec);spec.loader.exec_module(i)


class IntegrationTests(unittest.TestCase):
    def fixture(self, folder):
        base=Path(folder)
        api=base/'API2.pm'; js=base/'pvemanagerlib.js'
        api.write_bytes(b'package PVE::API2;\n1;\n')
        js.write_bytes(b'// PVE.StdWorkspace\n')
        (base/'pve-hook.js').write_bytes(b'// hook\n')
        return base,api,js

    def test_install_is_idempotent_then_remove(self):
        with tempfile.TemporaryDirectory() as folder:
            base,api,js=self.fixture(folder)
            originals=(api.read_bytes(),js.read_bytes())
            with patch.object(i,'BASE',api),patch.object(i,'JS',js),patch.object(i,'STATE',base/'backups'),patch.object(i,'ROOT',base),patch.object(i.os,'geteuid',return_value=0,create=True),patch.object(i.subprocess,'run'):
                with patch('sys.argv',['integration.py','install']):i.main()
                once=(api.read_bytes(),js.read_bytes())
                with patch('sys.argv',['integration.py','install']):i.main()
                self.assertEqual((api.read_bytes(),js.read_bytes()),once)
                with patch('sys.argv',['integration.py','remove']):i.main()
                self.assertEqual((api.read_bytes(),js.read_bytes()),originals)

    def test_failed_perl_check_restores_exact_files(self):
        with tempfile.TemporaryDirectory() as folder:
            base,api,js=self.fixture(folder)
            originals=(api.read_bytes(),js.read_bytes())
            with patch.object(i,'BASE',api),patch.object(i,'JS',js),patch.object(i,'STATE',base/'backups'),patch.object(i,'ROOT',base),patch.object(i.os,'geteuid',return_value=0,create=True),patch.object(i.subprocess,'run',side_effect=subprocess.CalledProcessError(1,['perl'])),patch('sys.argv',['integration.py','install']):
                with self.assertRaises(subprocess.CalledProcessError):i.main()
            self.assertEqual((api.read_bytes(),js.read_bytes()),originals)

    def test_marker_remove_preserves_surroundings(self):
        original=b'original\n'+i.PERL_START+b'our hook\n'+i.PERL_END+b'later edits\n'
        self.assertEqual(i.remove_block(original,i.PERL_START,i.PERL_END),b'original\nlater edits\n')

    def test_unmodified_and_duplicate(self):
        self.assertEqual(i.remove_block(b'original',i.PERL_START,i.PERL_END),b'original')
        for value in (i.PERL_START, i.PERL_END, i.PERL_START*2+i.PERL_END):
            with self.assertRaises(ValueError):i.remove_block(value,i.PERL_START,i.PERL_END)

    def test_peer_credentials(self):
        server=m.AppServer.__new__(m.AppServer)
        server.slots=SimpleNamespace(acquire=lambda **kw:True)
        class Client:
            def __init__(self,uid):self.uid=uid
            def getsockopt(self,*args):return m.struct.pack('3i',123,self.uid,0)
        with patch.object(m.socket,'SO_PEERCRED',17,create=True):
            self.assertTrue(server.verify_request(Client(0),None))
            self.assertFalse(server.verify_request(Client(1000),None))


if __name__=='__main__':unittest.main()
